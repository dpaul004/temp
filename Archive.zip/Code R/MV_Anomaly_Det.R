mva_det<-function(train,test) {
## The fol. is the training set - matrix of features x,.. In this case there are 5 features with 6 training rows.  
##  set.seed(2334)
##  x<-cbind(c(rnorm(30,1,.5)),c(rnorm(30,2,.5)),c(rnorm(30,3,.5)))
  
  m<-ncol(train)
  mu<-(colMeans(train))
##  sigma<-(1/m)*(t(rbind(apply(x,2,function(x) x - mean(x)))) %*% (rbind(apply(x,2,function(x) x - mean(x)))))
  sigma<-cov(train)
  sigma_det<-det(diag(diag(sigma)))
  sigma<-diag(diag(sigma^-1))

  prob_vec<-apply(test,1,function(x) prob(rbind(x),m,sigma,sigma_det,mu))
  return(round(prob_vec,4))

}

prob<-function(test_row,m,sigma,sigma_det,mu) {
  
  print(test_row)
  
##  return((1/(((2*pi)^(m/2))*(sqrt(sigma_det))))*(exp((-1/2)*(rbind(test_row-mu))%*%(sigma^-1)%*%t(rbind(test_row-mu)))))
    return((1/(((2*pi)^(m/2))*(sqrt(sigma_det))))*(exp((-1/2)*(rbind(test_row-mu))%*%(sigma)%*%t(rbind(test_row-mu)))))
}