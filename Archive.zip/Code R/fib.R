fib<-function(n) {
  h<-hash()
  fibcal(n,h)
  h
}

fibcal<-function(n,h) {
  if (n==0) {
    h["0"]<-0
    return(0)
  } else if (n==1) {
    h["1"]<-1
    return(1)
  } else {
    if (has.key(as.character(n),h)) {
      return(values(h[as.character(n)]))
    } else {
      x<-(fibcal(n-1,h) + fibcal(n-2,h))
      h[as.character(n)]<-x
      return(x)
    }
  }
}