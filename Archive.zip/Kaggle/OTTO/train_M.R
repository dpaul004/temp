setwd("~/Documents/Models/Kaggle/OTTO")

currentTrainPath = 'train.RData'
currentTestPath = 'test.RData'

training = F

if (training)
{
  trn = read.csv('train.csv',header=T)
} else {
  modFit<-readRDS(currentTrainPath)
  tst = read.csv('test.csv',header=T)
}

if (training) {
  data<-trn
} else {
  data<-tst
}

library(caret)

nam<-names(data)
## valCols<-c(which(nam=="accel_dumbbell_x"),which(nam=="magnet_dumbbell_x"),which(nam=="magnet_dumbbell_y"),which(nam=="magnet_dumbbell_z"),which(nam=="roll_forearm"),which(nam=="pitch_forearm"),which(nam=="yaw_forearm"),which(nam=="total_accel_forearm"),which(nam=="gyros_forearm_x"),which(nam=="gyros_forearm_y"),which(nam=="gyros_forearm_z"),which(nam=="accel_forearm_x"),which(nam=="accel_forearm_y"),which(nam=="accel_forearm_z"),which(nam=="magnet_forearm_x"),which(nam=="magnet_forearm_y"),which(nam=="magnet_forearm_z"),which(nam=="classe"))
rmcols<-c(1)

if (training) {
  data_b<-data[,-rmcols]
  values<-data_b$target
##  modFit<-train(classe~.,data<-data_b[,valCols],method="rf")
  modFit<-train(target~.,data=data_b,method="rf")
  prediction<-data$target
  saveRDS(modFit,currentTrainPath)
  error<-sum(values!=prediction)/length(values)
  paste("Training Set Error:",(error)," ")
  
} else {
  values<-data$target
  prediction<-predict(modFit,data[,-rmcols])
  error<-sum(values!=prediction)/length(values)
  paste("Test Set Error:",(error)," ")
}