__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import preprocessing
from numpy import *
import numpy as np

def trainModel(parm,forest):

    if (parm=='train'):
        data=(pd.read_csv('train.csv',header=0))
##        data=(pd.read_csv('train-2.csv',header=0))
        labels = data.target.values
        data = data.drop(["id","target"],axis=1)
    elif (parm=='cv'):
        data=(pd.read_csv('testcv.csv',header=0))
        labels = data.target.values
        id = data.id.values
        data = data.drop(["id","target"],axis=1)
    elif (parm=='test'):
##        data=(pd.read_csv('testcv.csv',header=0))
        data=(pd.read_csv('test-2.csv',header=0))
        id = data.id.values
        data = data.drop(["id"],axis=1)

##    tfdif = feature_extraction.text.TfdiF

##    data = data.drop(["id","target"],axis=1)

    transformer = TfidfTransformer()
    data = transformer.fit_transform(data).toarray()

    if (parm == "train"):
        forest = RandomForestClassifier(n_jobs=-1, n_estimators=400,max_features=15)
        forest = forest.fit(data,labels)
        return forest
    elif (parm == "cv"):
        output = forest.predict(data)
        cv_error = sum(map(lambda i:int(output[i]==labels[i]),range(len(output))))/float(len(labels))
        print 'Cross Validation Error %f' %cv_error
    elif (parm == "test"):
        output = forest.predict_proba(data)
        pred = pd.DataFrame(output,index=id,columns=forest.classes_)
        pred.to_csv("results.csv",index_label="id")

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('cv',forest)