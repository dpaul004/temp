__author__ = 'dipanjanpaul'

import pandas as pd
import graphlab as gl
from sklearn.feature_extraction.text import TfidfTransformer
from numpy import *

def trainModel(parm,forest):

    if (parm=='train'):
        data=(gl.SFrame.read_csv('train.csv',header=0))
##        data=(pd.read_csv('train-2.csv',header=0))
        labels = data.target.values
        data = data.drop(["id","target"],axis=1)
    elif (parm=='cv'):
        data=(pd.read_csv('testcv.csv',header=0))
        labels = data.target.values
        id = data.id.values
        data = data.drop(["id","target"],axis=1)
    elif (parm=='test'):
##        data=(pd.read_csv('testcv.csv',header=0))
        data=(pd.read_csv('test-2.csv',header=0))
        id = data.id.values
        data = data.drop(["id"],axis=1)

    transformer = TfidfTransformer()
    data = transformer.fit_transform(data).toarray()

    if (parm == "train"):
##        forest = RandomForestClassifier(n_jobs=-1, n_estimators=400,max_features=16,min_samples_split=1)
        forest = GradientBoostingClassifier(n_estimators=300, learning_rate=0.1,loss='huber',max_depth=8)
        forest = forest.fit(data,labels)
        return forest
    elif (parm == "cv"):
        output = forest.predict(data)
        cv_error = sum(map(lambda i:int(output[i]==labels[i]),range(len(output))))/float(len(labels))
        print 'Cross Validation Error %f' %cv_error
    elif (parm == "test"):
        output = forest.predict_proba(data)
        pred = pd.DataFrame(output,index=id,columns=forest.classes_)
        pred.to_csv("results.csv",index_label="id")

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('cv',forest)












