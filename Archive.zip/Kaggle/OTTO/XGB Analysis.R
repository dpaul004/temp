setwd("~/Documents/Models/Kaggle/OTTO")
require(xgboost)

mode <- c('regular')

train <- read.csv("train.csv",header=T)
cv <- read.csv("cv.csv",header=T)

train <- train[,-1]
id <- cv$id
cv <- cv[,-1]

train[,c('target')]<-as.numeric(substr(as.character(train$target),7,7)) - 1
t_target <- train$target
train<-train[,names(train) != "target"]

cv[,c('target')]<-as.numeric(substr(as.character(cv$target),7,7)) - 1
cv_target <- cv$target
cv<-cv[,names(cv) != "target"]

train <- apply(train, c(1,2), as.numeric)
cv <- apply(cv, c(1,2), as.numeric)

train_M <- as.matrix(train)
cv_M <- as.matrix(cv)

numberOfClasses <- max(t_target) + 1

paramdata <- read.csv("param.csv",header=T)

for (i in (1:nrow(paramdata))) {
  print(paramdata[i,])
  
  #cv.nround <- paramdata$nround[i]
  cv.nround <- 3
  
  cv.nfold <- 3
  cv.eta <- paramdata$eta[i]
  cv.maxdepth <- paramdata$maxdepth[i]
  cv.colsample <- paramdata$colsample[i]
  cv.childwidth <- paramdata$childwidth[i]
  cv.gamma <- paramdata$gamma[i]
  cv.subsample <- paramdata$subsample[i]
  
  param <- list("objective" = "multi:softprob", max.depth = cv.maxdepth, 
                gamma = cv.gamma, eta = cv.eta, colsample_bytree = cv.colsample,
                min_child_width = cv.childwidth, "eval_metric" = "mlogloss", 
                "num_class" = numberOfClasses, subsample = cv.subsample)
  
  bst = xgboost(param=param, data = train_M, label = t_target, verbose = 0,
                  nrounds = cv.nround)
  
  pred <- predict(bst, cv_M)
  pred <- matrix(pred,9,length(pred)/9)
  pred <- t(pred)
  pred <- format(pred, digits=2, scientific=F)
  pred <- data.frame(id,pred)
  names(pred) = c('id', paste0('Class_',1:9))
  
  model_pred <- (sapply((1:nrow(pred)), function (x) (which(as.numeric(pred[x,2:10]) == max(as.numeric(pred[x,2:10]))))))
  error <- sum((do.call('rbind',model_pred)[,1] != (cv_target + 1)))/length(model_pred)
  
  print(c('Error: ',error),quote=F)
}

#names <- dimnames(train_M)[[2]]
#imp_mat <- xgb.importance(names,model=bst)
#xgb.plot.importance(imp_mat[1:20])

