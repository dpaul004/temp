from distutils.core import setup

setup(
    name='OTTO',
    version='',
    packages=['pandas'],
    url='',
    license='',
    author='dipanjanpaul',
    author_email='',
    description=''
)
