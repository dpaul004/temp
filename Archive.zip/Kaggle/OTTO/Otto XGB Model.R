setwd("~/Documents/Models/Kaggle/OTTO")
require(xgboost)

mode <- c('regular')

train <- read.csv("train-2.csv",header=T)
test <- read.csv("test-2.csv",header=T)

train <- train[,-1]
id <- test$id
test <- test[,-1]

train[,c('target')]<-as.numeric(substr(as.character(train$target),7,7)) - 1
t_target <- train$target
train<-train[,names(train) != "target"]

#cv[,c('target')]<-as.numeric(substr(as.character(cv$target),7,7)) - 1
#cv_target <- cv$target
#cv<-cv[,names(cv) != "target"]

train <- apply(train, c(1,2), as.numeric)
test <- apply(test, c(1,2), as.numeric)

train_M <- as.matrix(train)
test_M <- as.matrix(test)

numberOfClasses <- max(t_target) + 1

param <- list("objective" = "multi:softprob", max.depth = 8, gamma = 2, eta = 0.001, colsample_bytree = .8,
              min_child_width = 5, "eval_metric" = "mlogloss", "num_class" = numberOfClasses,
              subsample = .8)

if (mode == "xcv") {
  cv.nround <- 5
  cv.nfold <- 3
  
  bst.cv = xgb.cv(param=param, data = train_M, label = t_target, 
                  nfold = cv.nfold, nrounds = cv.nround)
}

bst = xgboost(param=param, data = train_M, label = t_target, nrounds = 1200, verbose=0) 

#names <- dimnames(train_M)[[2]]
#imp_mat <- xgb.importance(names,model=bst)
#xgb.plot.importance(imp_mat[1:20])

pred <- predict(bst, test_M)
pred <- matrix(pred,9,length(pred)/9)
pred <- t(pred)
pred <- format(pred, digits=2, scientific=F)
pred <- data.frame(id,pred)
names(pred) = c('id', paste0('Class_',1:9))

#model_pred <- (sapply((1:nrow(pred)), function (x) (which(as.numeric(pred[x,2:10]) == max(as.numeric(pred[x,2:10]))))))
#error <- sum((do.call('rbind',model_pred)[,1] != (cv_target + 1)))/length(model_pred)
#print(c('Error: ',error),quote=F)

write.csv(pred,file='submission.csv', quote=FALSE,row.names=FALSE)