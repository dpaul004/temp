__author__ = 'dipanjanpaul'

import graphlab as gl
from numpy import *

def trainModel(parm,model):

##  Read the data
    if (parm=='train'):
        data=(gl.SFrame.read_csv('train-2.csv'))
        del data['id']
    elif (parm=='test'):
        data=(gl.SFrame.read_csv('test-2.csv'))
        id = data['id']
        del data["id"]

##  Train and Predict
    if (parm == "train"):
        net = gl.deeplearning.create(data,'target')
        model = gl.neuralnet_classifier.create(data, 'target', max_iterations=400, network=net)
        return model
    elif (parm == "test"):
        output = model.predict_topk(data, k=9)
        output['row_id'] = output['row_id'].astype(int) + 1
        output = output.unstack(['class','score'],'probs').unpack('probs','')
        output = output.sort('row_id')
        output.rename({'row_id': 'id'})
        output.save("results.csv")

if __name__ == "__main__":
    model=trainModel('train',NaN)
    trainModel('test',model)