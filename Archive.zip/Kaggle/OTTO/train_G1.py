__author__ = 'dipanjanpaul'

import pandas as pd
import graphlab as gl
from sklearn.feature_extraction.text import TfidfTransformer
from numpy import *

def trainModel(parm,forest):

    if (parm=='train'):
##        data=(gl.SFrame.read_csv('train-2.csv'))
        data=(pd.read_csv('train-2.csv',header=0))
        labels = data['target']
        data = data.drop(["id","target"],axis=1)
##        del data['id']
    elif (parm=='cv'):
        data=(gl.SFrame.read_csv('testcv.csv'))
        labels = data['target']
        id = data['id']
        del data['id']
    elif (parm=='test'):
        data=(pd.read_csv('test-2.csv',header=0))
##        data=(gl.SFrame.read_csv('test-2.csv'))
        id = data['id']
        data = data.drop(["id"],axis=1)
##        del data["id"]

    transformer = TfidfTransformer()
    data = pd.DataFrame(transformer.fit_transform(data).toarray())
    if (parm == 'train'):
        data['target'] = labels
    data = gl.SFrame(pd.DataFrame(data))

    if (parm == "train"):
##        forest = RandomForestClassifier(n_jobs=-1, n_estimators=400,max_features=16,min_samples_split=1)
        forest = gl.boosted_trees_classifier.create(data,target='target',max_iterations=300,max_depth=8,
                                                    step_size=.5,min_loss_reduction=1)
        return forest
    elif (parm == "cv"):
        output = forest.predict(data)
        cv_error = sum(map(lambda i:int(output[i]==labels[i]),range(len(output))))/float(len(labels))
        print 'Cross Validation Error %f' %cv_error
    elif (parm == "test"):
        output = forest.predict_topk(data,output_type='probability',k=9)
        output['id'] = output['id'].astype(int) + 1
        output = output.unstack(['class','probability'],'probs').unpack('probs','')
        output = output.sort('id')
        output.save("results.csv")

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('test',forest)