## This program will clean the weather data provided in the Walmart Sales Kaggle competition. For each field that 
## is marked with M, it imputes the value with the mean of the previous 4 values of the same field for the same station.
library(randomForest)

parm <- "none"

setwd("~/Documents/Models/Kaggle/WestNile")
data <- read.csv('weather.csv',header=T,colClasses="character")
data <- data[order(data$Station,data$Date),]

data$Tmax_M <- 0
data$PrecipTotal_M <- 0

data[which((as.character(data$Tmax) != 'M') & (as.character(data$Tmin) != 'M') 
           & (as.character(data$Tavg) == 'M')),c('Tavg')] <-
  rowMeans(apply((data[which((as.character(data$Tmax) != 'M') & (as.character(data$Tmin) != 'M')
                             & (as.character(data$Tavg) == 'M')),][,c('Tmax','Tmin')]),2,as.numeric))

l <- unique(data$Station)

for (itm in l) {
  print(c('item:',itm),quote=F)
  
  row_nm <- as.numeric(which(((as.character(data$Tmax) == 'M') | 
                                              (as.character(data$Tmin) == 'M')) & (as.character(data$Tavg) == 'M'
                                                    & data$Station == itm)))
  for (r in row_nm) {
    data[r,c('Tavg')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('Tavg')]))
  }
  
  row_nm <- as.numeric(row.names(which(as.character(data$DewPoint) == 'M' & data$Station == itm)))
  for (r in row_nm) {
    data[r,c('DewPoint')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('DewPoint')]))
  }
  
  row_nm <- as.numeric(which(as.character(data$WetBulb) == 'M' & data$Station == itm))
  for (r in row_nm) {
    data[r,c('WetBulb')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('WetBulb')]))
  }
  
  row_nm <- as.numeric(which(((as.character(data$PrecipTotal) == '  T') | 
                                              (as.character(data$PrecipTotal) == 'M')) & data$Station == itm))
  for (r in row_nm) {
    data[r,c('PrecipTotal')] <- mean(as.numeric(data[((r-3) : (r - 1)),c('PrecipTotal')]))
  }
  
  row_nm <- as.numeric(which(as.character(data$StnPressure) == 'M' & data$Station == itm))
  for (r in row_nm) {
    data[r,c('StnPressure')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('StnPressure')]))
  }
  
  row_nm <- as.numeric(which(as.character(data$SeaLevel) == 'M' & data$Station == itm))
  for (r in row_nm) {
    data[r,c('SeaLevel')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('SeaLevel')]))
  }
  
  row_nm <- as.numeric(which(as.character(data$AvgSpeed) == 'M' & data$Station == itm))
  for (r in row_nm) {
    data[r,c('AvgSpeed')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('AvgSpeed')]))
  }
  
  row_nm <- as.numeric(which(as.character(data$ResultDir) == 'M' & data$Station == itm))
  for (r in row_nm) {
    data[r,c('ResultDir')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('ResultDir')]))
  }
  
  row_nm <- as.numeric(which(data$Station == itm & data$Station == itm))
  for (r in row_nm[4:length(row_nm)]) {
    data$Tmax_M[r] <- mean(as.numeric(data$Tmax[r-3:r]))
  }
  
  row_nm <- as.numeric(which(data$Station == itm & data$Station == itm))
  for (r in row_nm[4:length(row_nm)]) {
    data$PrecipTotal_M[r] <- mean(as.numeric(data$PrecipTotal[r-3:r]))
  }
}  

data[data$Tmax == "M",]$Tmax <- data[data$Tmax == "M",]$Tavg
data[data$Tmin == "M",]$Tmin <- data[data$Tmin == "M",]$Tavg

if (length(data[which(as.character(data$SnowFall) == 'M'),]$SnowFall) > 0) {
  data[which(as.character(data$SnowFall) == 'M'),]$SnowFall <- 0.00
}

data[which(as.character(data$SnowFall) == '  T'),]$SnowFall <- 0.00

if (length(data[which(as.character(data$PrecipTotal) == '  T'),]$PrecipTotal > 0)) {
  data[which(as.character(data$PrecipTotal) == '  T'),]$PrecipTotal <- 0.00
}

data <- data[order(data$Station,data$Date),]

nam<-names(data)
rm_cols <- c(which(nam=='CodeSum'), which(nam=='Depart'), which(nam=='Heat'),
             which(nam=='SnowFall'), which(nam=='StnPressure'), which(nam=='SeaLLevel'),
             which(nam=='ResultDir'),
             which(nam=='Cool'), which(nam=='ResultSpeed'), which(nam=='Sunrise'),
             which(nam=='Sunset'), which(nam=="Depth"), which(nam=="Water1"), which(nam=="Tmin"),
             which(nam=="SeaLevel"))

data<-data[,-rm_cols]
data[is.na(data)]<-0

w_date <- as.POSIXlt(data$Date)
d_nr <- -abs(w_date$yday%/%6 - 33)
y_nr <- (w_date$year - 107)
data <- data.frame(data, d_nr, y_nr)

for (i in (3:(ncol(data)))) {
  data[,i] <- as.numeric(data[,i])
}

#data1 <- data[data$Station == "1",2:15]
#data2 <- data[data$Station == "2",2:15]

train <- read.csv("train.csv", header=T)
train <- train[((train$Species == "CULEX PIPIENS") | (train$Species == "CULEX PIPIENS/RESTUANS")),]
##m_df <- train[,c(which(names(train) == 'Date'), which(names(train) == 'NumMosquitos'))]
nam <- names(train)
train <- train[,c(which(nam=="Date"), which(nam=="Species"), which(nam=="Latitude"), which(nam=="Longitude"), 
                  which(nam=="Trap"), which(nam=="Block"), 
                  which(nam=="NumMosquitos"), which(nam=="WnvPresent"))]

train$Station <- ifelse((((train$Latitude-41.995)^2 + (train$Longitude + 87.933)^2) < 
                           ((train$Latitude-41.786)^2 + (train$Longitude + 87.752)^2)),1,2)

#train[(train$Species == "CULEX ERRATICUS" | train$Species == "CULEX SALINARIUS" | 
#         train$Species == "CULEX TARSALIS" | train$Species == "CULEX TERRITANS"),]$Species <- c('UNSPECIFIED CULEX')

train$Trap <- factor(substr(train$Trap,1,4))
train$Species <- as.factor(train$Species)

b <- train$Block
train$Block <- as.factor(as.numeric(cut(b, seq(min(b),max(b),2), include.lowest=T, right=F)))

train <- merge(train,data,sort=F)
train$y_nr <- as.factor(train$y_nr)
train <- train[,-c(which(names(train) == "Date"), which(names(train)=="Station"))]

#l <- rbinom(nrow(train),size=1,prob=0.1)
#UC_DF <- train[l==1,][,]
#UC_DF$Species <- c('UNSPECIFIED CULEX')
#train <- rbind(train,UC_DF)

train <- train[,-c(which(names(train)=="Latitude"), which(names(train)=="Longitude")),] 

#model <- (randomForest(NumMosquitos ~ ., data=train[,-c(which(names(train) == "WnvPresent"), 
#                                                        which(names(train)=="Trap"),
#                                                        which(names(train)=="AvgSpeed"),
#                                                        which(names(train)=="Tmax"),
#                                                        which(names(train)=="PrecipTotal_m"))],ntree=1000))

model <- (randomForest(NumMosquitos ~ d_nr + PrecipTotal_M +Tmax_M, data=train, ntree=1000))

#model <- (lm(NumMosquitos ~ Species + Trap + d_nr + y_nr + Tmax + PrecipTotal_M - 1, data=train))

## The test file contains data for 'UNSPECIFIED CULEX' (not found in the train set). So we are manufacturing data for 
## UNSPECIFIED CULEX in the train set with a 10% random sample from the train set.

write.csv(train, "train_enh.csv", row.names=F)

if (parm == "cv") {
  l <- rbinom(nrow(train),size=1,prob=0.3)
  trn <- train[l==0,][,]
  cv <- train[l==1,][,]
#  train$Trap <- substr(train$Trap,2,4)
#  fitControl <- trainControl(method="repeatedCV", number=10, repeats=10)
  
#  cv_model_m <- train(NumMosquitos ~ ., data=train[,-1], method="rf", preprocess="scale",
#                      trControl=fitControl,verbose=False)
}

test <- read.csv("test.csv", header=T)
nam <- names(test)
test <- test[,c(which(nam=="Id"), which(nam=="Date"), which(nam=="Species"), 
                which(nam=="Block"), which(nam=="Trap"), which(nam=="Latitude"), which(nam=="Longitude"))]

test$Station <- ifelse((((test$Latitude-41.995)^2 + (test$Longitude + 87.933)^2) < 
                          ((test$Latitude-41.786)^2 + (test$Longitude + 87.752)^2)),1,2)

#test[(test$Species == "CULEX ERRATICUS" | test$Species == "CULEX SALINARIUS" | 
#         test$Species == "CULEX TARSALIS" | test$Species == "CULEX TERRITANS"),]$Species <- c('UNSPECIFIED CULEX')
test$Species <- as.factor(test$Species)

test <- merge(test,data,sort=F)
test <- test[,-c(which(names(test) == "Date"), which(names(test)=="Station"))]

test <- test[,-c(which(names(test)=="Latitude"), which(names(test)=="Longitude")),] 

test[which(test$Trap=="T234"),]$Trap <- c("T238")
test$Trap <- factor(substr(test$Trap,1,4))

b <- test$Block
test$Block <- as.factor(as.numeric(cut(b, seq(min(b),max(b),2), include.lowest=T, right=F)))

test$y_nr <- as.factor(test$y_nr - 1)

## Predict NumMosquitos for the test set.

test$NumMosquitos <- (predict(model,test))
test$NumMosquitos[test$NumMosquitos < 0] <- 0

write.csv(test, "test_enh.csv", row.names=F)