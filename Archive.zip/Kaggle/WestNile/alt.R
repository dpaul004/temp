setwd("./")

train <- read.csv("train_enh.csv")

cells <- seq(from=min(train$NumMosquitos), to=max(train$NumMosquitos) + 2, by=2)
train$Mosquitos_Cat <- factor(NA,levels=seq(1, (length(cells)-1), 1))
for (i in (1:(length(cells) -1))) {
  train$Mosquitos_Cat[train$NumMosquitos >= cells[i] & train$NumMosquitos < cells[i+1]] <- i
}
train$Mosquitos_Cat <- as.factor(train$Mosquitos_Cat)

l <-round(runif(nrow(train),1,4))

for (i in (1:4)) {
  
  model <- gbm(Mosquitos_Cat ~ Species + Trap + d_nr + y_nr + Tmax + PrecipTotal_M + Tmax_M - 1, 
               data=train, n.trees=1500, shrinkage=0.001, n.cores=2)
  
  
  trn <- train[l <> i,][,]
  tst <- train[l==i,][,]
  
  
}



test <- read.csv("test_enh.csv")

submission <- as.data.frame(test$Id)
submission$WnvPresent <- 0

test.hex <- as.h2o(localH2O,test[,2:(ncol(test))])
  
for(j in 1:5){
    print(j)
    
    model <- h2o.deeplearning(x=predictors,
                              y=response,
                              data=train.hex,
                              classification=T,
                              activation="RectifierWithDropout",
                              hidden=c(1024,512,256),
                              hidden_dropout_ratio=c(0.5,0.5,0.5),
                              input_dropout_ratio=0.05,
                              epochs=20,
                              l1=1e-5,
                              l2=1e-5,
                              rho=0.99,
                              epsilon=1e-8,
                              train_samples_per_iteration=500,
                              max_w2=10,
                              seed=1)
    submission$WnvPresent <- submission$WnvPresent + as.data.frame(h2o.predict(model,test.hex))$X1
    print(j)
}

submission$WnvPresent <- submission$WnvPresent/j
names(submission) <- c('Id','WnvPresent')
write.csv(submission,file="submission_h2o.csv",row.names=FALSE)     