__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm):

    train=(pd.read_csv('train_enh.csv',header=0))
    train["Block"] = train["Block"].astype('category')
    train["Trap"] = map(lambda x: x[1:4], train.Trap)
    train["Trap"] = train["Trap"].astype('category')
    train["d_nr"] = train["d_nr"].astype('category')
    train["y_nr"] = train["y_nr"].astype('category')
    train["WnvPresent"] = train["WnvPresent"].astype('category')

    NumMosquitoes = train.NumMosquitos.values
    train_M = train.drop(["Species", "NumMosquitos", "WnvPresent"],axis=1)

    rfm = RandomForestRegressor(n_estimators=500, verbose=0, n_jobs=-1)
    m_model = rfm.fit(train_M,NumMosquitoes)

    test=(pd.read_csv('test_enh.csv',header=0))
    test["Block"] = test["Block"].astype('category')
    test["Trap"] = map(lambda x: x[1:4], test.Trap)
    test["Trap"] = test["Trap"].astype('category')
    test["d_nr"] = test["d_nr"].astype('category')
    test["y_nr"] = test["y_nr"].astype('category')

    
    test_M = test.drop(["Id", "Species"],axis=1)
    test["NumMosquitos"] = m_model.predict(test_M)

## Train and Predict the probability wuth visrus present.
    WnvPresent = train.WnvPresent.values
    train_M = train.drop(["Species", "WnvPresent"],axis=1)

    Id = test.Id.values
    test_M = test.drop(["Id", "Species"],axis=1)

    rfm_f = RandomForestClassifier(criterion="entropy", n_estimators=1200, n_jobs=-1,
                                     verbose=0, max_depth=8)
    f_model = rfm_f.fit(train_M,WnvPresent)

    output = f_model.predict_proba(test_M)

    results = pd.DataFrame()
    results["Id"] = Id
    results["WnvPresent"] = output[:,1]
    results.columns = ['Id','WnvPresent']
    results.to_csv("results_gbm.csv",index=False)

if __name__ == "__main__":
    trainModel('none')