setwd("./")

train <- read.csv("train_enh.csv")
train <- train[,-c(which(names(train)=="Block"))]
train$d_nr <- as.factor(train$d_nr)
train$y_nr <- as.factor(train$y_nr)

test <- read.csv("test_enh.csv")
test <- test[,-c(which(names(test)=="Block"))]
test$d_nr <- as.factor(test$d_nr)
test$y_nr <- as.factor(test$y_nr)

submission <- as.data.frame(test$Id)
    
model <- glm(WnvPresent ~ ., data=train, family="binomial")

submission$WnvPresent <- predict.glm(model,test, type="response")

names(submission) <- c('Id','WnvPresent')
write.csv(submission,file="submission_glm.csv",row.names=FALSE)     