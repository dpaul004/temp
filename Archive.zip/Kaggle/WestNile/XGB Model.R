setwd("./")
require(xgboost)

mode <- c('regular')

train <- read.csv("train_enh.csv",header=T)
train <- train[,names(train) != "Trap"]
train$Species <- as.numeric(train$Species)

test <- read.csv("test_enh.csv",header=T)
test <- test[,names(test) != "Trap"]
test$Species <- as.numeric(test$Species)

Id <- test$Id
test <- test[,-1]

WnvPresent <- train$WnvPresent
train <- train[,names(train) != "WnvPresent"]

train <- apply(train, c(1,2), as.numeric)
test <- apply(test, c(1,2), as.numeric)

train_M <- as.matrix(train)
test_M <- as.matrix(test)

numberOfClasses <- 2

param <- list("objective" = "multi:softprob", max.depth = 8, gamma = 2, eta = 0.001, colsample_bytree = .8,
              min_child_width = 5, "eval_metric" = "mlogloss", "num_class" = numberOfClasses,
              subsample = .8)

model = xgboost(param=param, data = train_M, label = WnvPresent, nrounds = 1200, verbose=0) 

#names <- dimnames(train_M)[[2]]
#imp_mat <- xgb.importance(names,model=bst)
#xgb.plot.importance(imp_mat[1:20])

pred <- predict(model, test_M)
pred <- matrix(pred,2,length(pred)/2)
pred <- t(pred)
pred <- format(pred, digits=2, scientific=F)
pred <- data.frame(Id,pred[,2])
names(pred) = c('Id', "WnvPresent")

#model_pred <- (sapply((1:nrow(pred)), function (x) (which(as.numeric(pred[x,2:10]) == max(as.numeric(pred[x,2:10]))))))
#error <- sum((do.call('rbind',model_pred)[,1] != (cv_target + 1)))/length(model_pred)
#print(c('Error: ',error),quote=F)

write.csv(pred,file='submission.csv', quote=FALSE,row.names=FALSE)