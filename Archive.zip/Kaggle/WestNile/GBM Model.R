require(gbm)

mode <- c('reg')

train <- read.csv("train_enh.csv",header=T)
train$Block <- as.factor(train$Block)
train$d_nr <- as.factor(train$d_nr)
train$y_nr <- as.factor(train$y_nr)

train <- train[,names(train) != "Trap"]

test <- read.csv("test_enh.csv",header=T)
test$Block <- as.factor(test$Block)
test$d_nr <- as.factor(test$d_nr)
test$y_nr <- as.factor(test$y_nr)

test <- test[,names(test) != "Trap"]

Id <- test$Id
test <- test[,-1]

if (mode == 'cv') {
  l <- rbinom(nrow(train),size=1,prob=0.3)
  trn <- train[l==0,][,]
  cv <- train[l==1,][,]
  
  model <- gbm(WnvPresent ~ ., data=trn, n.trees=3000, shrinkage=0.001, cv.folds=3, n.cores=2)
  best.iter <- gbm.perf(model,method="cv")
  print(best.iter)
  
  res <- predict(model, cv[,-c(which(names(cv)=="WnvPresent"))],type="response")
  res[res < .2] <- 0
  res[res >= .2] <- 1
  print(sum((cv$WnvPresent - res)^2))
  
} else {
  model <- gbm(WnvPresent ~ ., data=train, n.trees=1500, shrinkage=0.001, n.cores=2)
  
  res <- predict(model, test, n.trees=3000, type="response")
  pred <- data.frame(Id, res)
  names(pred) <- c('Id', 'WnvPresent')
  write.csv(pred,file='submission_gbm.csv', quote=FALSE,row.names=FALSE)
}

#