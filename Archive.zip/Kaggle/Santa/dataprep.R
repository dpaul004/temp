dataprep<-function(file) {
  setwd("~/Documents/Models/Kaggle/Santa")
  
  tot_emp<-900
  
  job<-read.csv("toys_rev2.csv",strip.white=TRUE,header=T,nrows=1000)
  job[,2]<-as.numeric(((as.POSIXct(strptime(job[,2],"%Y %m %d %H %M")))-1388552460))/60 + 1
  job$status<-" "
  job$actual_start<-0
  job$actual_end<-0
  
  emp<-data.frame(1:tot_emp)
  names(emp)<-c("id")
  emp$start_time<-1
  emp$prod_lvl<-1
  emp$status<-c("W")
  emp$avail_tm_next<-0
  emp$avail_hrs_today<-600
  emp$idle_time<-0
  
  ref_time<-1
  
  while (more_job == "y") {
##    unassigned_job<-job[which(job$Arrival_time <= ref_time & job$status == " "),]
##    unassigned_job<-which(job$Arrival_time <= ref_time & job$status == " ")
    
##  Code the productivity factor in the avail_today field ##
    
    emp$avail_hrs_today<- as.numeric(600 - (emp$avail_tm_next%%1440))
    emp$avail_hrs_today<- ifelse(emp$avail_hrs_today <= (1140 -ref_time%%1440), emp$avail_hrs_today, (1140 - ref_time%%1440))
    
##    unassigned_job<-job[which(job$Arrival_time <= ref_time & job$status == " "),][,1:3]
    job_duration_unq_lst_1<-(unique(job[which(job$Arrival_time <= ref_time & job$status == " " &
                                                       job$Duration <= max(emp$avail_hrs_today)),][,3]))
    
    c<-sum(2^(as.matrix(1:length(job_duration_unq_lst_1)-1)))
    r<-length(job_duration_unq_lst_1)
    job_m<-matrix(0,nrow=r,ncol=c)

    j<-1
    for (i in 1:length(job_duration_unq_lst_1)) {
      x<-combn(job_duration_unq_lst_1,i)
      job_m[1:i,j:(j+ncol(x)-1)]<-x
      j<-j+ncol(x)
    }
    for (i=1:length(job_duration_unq_lst_1)) {
      no_of_job<-length(job[which(job$Duration==job_duration_unq_lst_1[1]),][,])
      
      
    }
    
    avail_emp<-order(emp$avail_next)
    
##    emp[avail_emp[1:length(unassigned_job_lst)],5]<-job[unassigned_job_lst,][,3]
    
    if (length(unassigned_jobs) > tot_emp) {
      
    } else {
      
      emp[avail_emp[1:length(unassigned_job_lst)],5]<-ifelse((emp[avail_emp[1:length(unassigned_job_lst)],5]
                                                       + job[unassigned_job_lst,][,3])%%1440 <= 1140,
                                                       (emp[avail_emp[1:length(unassigned_job_lst)],5]
                                                        + job[unassigned_job_lst,][,3]),
                                                       (emp[avail_emp[1:length(unassigned_job_lst)],5]
                                                        + job[unassigned_job_lst,][,3]) + 840)
                                                       
      
      
    }
    
    for (i in 1:length(unassigned_job)) {
      
      mean_avail_next<-mean(emp$avail_next)
      sd_avail_next<-sd(emp$avail_next)
      
      if (sd_avail > ) {
        
        
      }
      avail_emp<-order(emp$avail_next)
      
      
    }  
    
    
  }
  
}