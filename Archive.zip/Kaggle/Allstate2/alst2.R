library(tree)
library(h2o)
library(rpart.plot)
library(pROC)
library(gam)
require(cluster)
require(useful)
require(Hmisc)
require(plot3D)
library(HSAUR)
library(MVA)
library(HSAUR2)
library(fpc)
library(mclust)
library(lattice)
library(car)
library(corrplot)
library(gbm)
library(randomForest)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Allstate2")

eda = "N"
var_sel = "N"

train <- read.csv('train.csv', header=T)

Response <- as.factor(train$Response)
RowID <- train$RowID

# Initial Transformation
train$Response <- as.factor(train$Response)

#EDA
if (eda == "Y") {
  apply(train, 2, function(x) sum(is.na(x)))
  
  smp <- rbinom(nrow(train), 1, .6)
  eda <- train[smp==1,][]
  
  mcor <- cor(train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7", 'Var8',
                       'NVVar1', 'NVVar2','NVVar3','NVVar4')])
  corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)
  
  barplot(table(eda$Response, eda$Cat1), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  barplot(table(eda$Response, eda$Cat2), bg=c('red', 'green')[unclass(eda$Response)], main="Cat2")
  barplot(table(eda$Response, eda$Cat3), bg=c('red', 'green')[unclass(eda$Response)], main="Cat3")
  barplot(table(eda$Response, eda$Cat4), bg=c('red', 'green')[unclass(eda$Response)], main="Cat4")
  barplot(table(eda$Response, eda$Cat5), bg=c('red', 'green')[unclass(eda$Response)], main="Cat5")
  barplot(table(eda$Response, eda$Cat6), bg=c('red', 'green')[unclass(eda$Response)], main="Cat6")
  barplot(table(eda$Response, eda$Cat7), bg=c('red', 'green')[unclass(eda$Response)], main="Cat7")
  barplot(table(eda$Response, eda$Cat8), bg=c('red', 'green')[unclass(eda$Response)], main="Cat8")
  barplot(table(eda$Response, eda$Cat9), bg=c('red', 'green')[unclass(eda$Response)], main="Cat9")
  barplot(table(eda$Response, eda$Cat10), bg=c('red', 'green')[unclass(eda$Response)], main="Cat10")
  barplot(table(eda$Response, eda$Cat11), bg=c('red', 'green')[unclass(eda$Response)], main="Cat11")
  barplot(table(eda$Response, eda$Cat12), bg=c('red', 'green')[unclass(eda$Response)], main="Cat12")
  
  
  fit1 <- rpart(Response ~., data=train[,c("Cat1", "Cat2", "Cat3", "Cat4", "Cat5", "Cat6",
                                    "Cat7", "Cat8", "Cat9", "Cat10", "Cat11", "Cat12",
                                    "Response")],
                      control=rpart.control(cp=0.0,minsplit=100))
  
  min_cp <- fit1$cptable[which.min(fit1$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit1, cp=0.00005)
  rpart.plot(pfit)
  
  fit2 <- rpart(Response ~ ., data=train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7",
                                     "Response")], control=rpart.control(cp=0,minsplit=25))
  rpart.plot(fit2)
  min_cp <- fit2$cptable[which.min(fit2$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit2, cp=0.00002)
  rpart.plot(pfit) 
}

# More Transformation and Indicator Variables,.. Tighten up
tmp <- data.frame(unclass(t(table(train$Response, train$Model))))
p_a <- (tmp$X1/(tmp$X0 + tmp$X1))
p_e <- (tmp$X0 + tmp$X1)/(sum(tmp$X0) + sum(tmp$X1))
p_d <- sum(p_a * p_e)                    
model_risk <- data.frame(rownames(tmp), (p_a*p_e/p_d))
names(model_risk) <- c('Model', 'M_Risk')
train <- merge(train, model_risk, by.x="Model", by.y="Model", sort=F)
#train <- train[,-(which(names(train) %in% c("RowID", "Model", "Make", "Response")))]

c_id1 <- as.factor(I(as.character(train$Cat1) %in% c('A','C','E','F','G')))
c_id2 <- as.factor(I(train$Cat3 %in% c('B','E')))
c_id3 <- as.factor(I(train$Cat6 %in% c('D','E')))
c_id4 <- as.factor(I(train$Cat6 %in% c('B')))
c_id5 <- as.factor(I(train$Cat8 %in% c('B','C')))
c_id6 <- as.factor(I(train$Cat3 %in% c('D')))
c_id7 <- as.factor(I(train$Cat12 %in% c('C')))
c_id8 <- as.factor(I(train$Cat10 %in% c('A')))

var1 <- log(abs(train$Var1 + train$Var2 + train$Var3 + train$Var5 + 
                  train$Var7) + 0.001) * sign((train$Var1 + 
                  train$Var2 + train$Var3 + train$Var5 + train$Var7))

var2 <- log(abs(train$Var6 + 0.001)) * sign(train$Var6)
var3 <- log(abs(train$Var8 + 0.001)) * sign(train$Var8)
var4 <- log(abs(train$NVVar1 + 0.001)) * sign(train$Var1)
var5 <- log(abs(train$NVVar2 + 0.001)) * sign(train$Var2)
var6 <- log(abs(train$NVVar3 + 0.001)) * sign(train$Var3)
var7 <- log(abs(train$NVVar4 + 0.001)) * sign(train$Var4)

x_id1 <- I(train$ModelYear < 1997)
train[(train$ModelYear < 1997), c('ModelYear')] <- 1997
train$CalendarYear <- as.factor(train$CalendarYear)
train$ModelYear <- as.factor(train$ModelYear)

new_data <- data.frame(train$CalendarYear, train$ModelYear, train$OrdCat, train$NVCat, train$M_Risk, 
                  train$Cat1, train$Cat2, train$Cat3, train$Cat4, train$Cat5, train$Cat6,
                  train$Cat7, train$Cat8, train$Cat9, train$Cat10, train$Cat11, train$Cat12, 
                  c_id1, c_id2, c_id3, c_id4, c_id5, c_id6, c_id7, c_id8,
                  var1, var2, var3, var4, var5, var6, var7,
                  train$Response)

#Additional Transformation

# Normalize Variables

# Split train set into trn and xcv
set.seed(12345)
ix <- rbinom(nrow(new_data), 1, .7)
trn <- new_data[ix==1,][,]
xcv <- new_data[ix==0,][,]

write.csv(new_data, file="alst_cln.csv", row.names=FALSE) 

if (var_sel == "Y") {
  model.step <- glm(train.Response ~ ., data=trn, family = binomial("logit"))
  step(model.step, direction="both")
}

# GLM
model.glm <- glm(formula = train.Response ~ train.CalendarYear + train.ModelYear + 
                   train.OrdCat + train.NVCat + train.M_Risk + train.Cat3 + 
                   train.Cat5 + train.Cat6 + train.Cat7 + train.Cat8 + train.Cat9 + 
                   train.Cat10 + train.Cat11 + var4 + var5 + var6 + var7 + c_id7, family = binomial, 
                 data = trn)
pred <- predict(model.glm, newdata=xcv, type="response")
roc1 <- roc(xcv$train.Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$train.Response)) * log(pred) + 
      (1 - as.integer(as.character(xcv$train.Response))) * log(1 - pred))

# GLM with Polynomial
for (i in 3:10) {
  model.glm.pol <- glm(formula = train.Response ~ train.CalendarYear + train.ModelYear + 
                         train.OrdCat + train.NVCat + poly(train.M_Risk,i) + train.Cat3 + 
                         train.Cat5 + train.Cat6 + train.Cat7 + train.Cat8 + train.Cat9 + 
                         train.Cat10 + train.Cat11 + 
                         poly(var4,i) + poly(var5,i) + poly(var6,i) + 
                         poly(var7,i) + c_id7, family = binomial, data = trn)
  pred <- predict(model.glm.pol, newdata=xcv, type="response")
  # Loss Function
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$train.Response)) * log(pred) + 
                         (1 - as.integer(as.character(xcv$train.Response))) * log(1 - pred))))
}
model.glm.pol <- glm(formula = train.Response ~ train.CalendarYear + train.ModelYear + 
                       train.OrdCat + train.NVCat + poly(train.M_Risk,6) + train.Cat3 + 
                       train.Cat5 + train.Cat6 + train.Cat7 + train.Cat8 + train.Cat9 + 
                       train.Cat10 + train.Cat11 + 
                       poly(var4,6) + poly(var5,6) + poly(var6,6) + 
                       poly(var7,6) + c_id7, family = binomial, data = trn)
pred <- predict(model.glm.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$train.Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$train.Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$train.Response))) * log(1 - pred))

# GAM with Polynomial
for (i in 3:10) {
  model.gam.pol <- gam(formula = train.Response ~ train.CalendarYear + train.ModelYear + 
                         train.OrdCat + train.NVCat + s(train.M_Risk,i) + train.Cat3 + 
                         train.Cat5 + train.Cat6 + train.Cat7 + train.Cat8 + train.Cat9 + 
                         train.Cat10 + train.Cat11 + 
                         s(var4,i) + s(var5,i) + s(var6,i) + 
                         s(var7,i) + c_id7, family = binomial, data = trn)
  pred <- predict(model.gam.pol, newdata=xcv, type="response")
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$train.Response)) * log(pred) + 
                     (1 - as.integer(as.character(xcv$train.Response))) * log(1 - pred))))
}
model.gam.pol <- gam(formula = train.Response ~ train.CalendarYear + train.ModelYear + 
                       train.OrdCat + train.NVCat + s(train.M_Risk,10) + train.Cat3 + 
                       train.Cat5 + train.Cat6 + train.Cat7 + train.Cat8 + train.Cat9 + 
                       train.Cat10 + train.Cat11 + 
                       s(var4,10) + s(var5,10) + s(var6,10) + 
                       s(var7,10) + c_id7, family = binomial, data = trn)
pred <- predict(model.gam.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$train.Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$train.Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$train.Response))) * log(1 - pred))

# Random Forest
model.rf <- randomForest(train.Response ~ .,
                         ntree=750, importance=T, data = trn)
pred <- predict(model.rf, newdata=xcv, type="response")
roc1 <- roc(xcv$train.Response, as.integer(as.character(pred)))
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))

#GBM
model.gbm <- gbm(as.numeric(as.character(train.Response)) ~ .,
                 n.trees=2000, shrinkage=0.01, interaction.depth=1,
                 data = trn)
pred <- predict(model.gbm, newdata=xcv, type="response", n.trees=2000)
roc1 <- roc(xcv$train.Response, as.integer(as.character(pred)))
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))