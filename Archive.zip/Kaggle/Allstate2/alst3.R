library(tree)
library(h2o)
library(rpart.plot)
library(pROC)
library(gam)
require(cluster)
require(useful)
require(Hmisc)
require(plot3D)
library(HSAUR)
library(MVA)
library(HSAUR2)
library(fpc)
library(mclust)
library(lattice)
library(car)
library(corrplot)
library(gbm)
library(randomForest)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Allstate2")

eda = "N"
var_sel = "N"

train <- read.csv('train.csv', header=T)
test <- read.csv('test.csv', header=T)

# Initial Transformation
train$Response <- as.factor(train$Response)

#EDA
if (eda == "Y") {
  apply(train, 2, function(x) sum(is.na(x)))
  apply(test, 2, function(x) sum(is.na(x)))
  
  smp <- rbinom(nrow(train), 1, .6)
  eda <- train[smp==1,][]
  
  mcor <- cor(train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7", 'Var8',
                       'NVVar1', 'NVVar2','NVVar3','NVVar4')])
  corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)
  
  barplot(table(eda$Response, eda$Cat1), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  barplot(table(eda$Response, eda$Cat2), bg=c('red', 'green')[unclass(eda$Response)], main="Cat2")
  barplot(table(eda$Response, eda$Cat3), bg=c('red', 'green')[unclass(eda$Response)], main="Cat3")
  barplot(table(eda$Response, eda$Cat4), bg=c('red', 'green')[unclass(eda$Response)], main="Cat4")
  barplot(table(eda$Response, eda$Cat5), bg=c('red', 'green')[unclass(eda$Response)], main="Cat5")
  barplot(table(eda$Response, eda$Cat6), bg=c('red', 'green')[unclass(eda$Response)], main="Cat6")
  barplot(table(eda$Response, eda$Cat7), bg=c('red', 'green')[unclass(eda$Response)], main="Cat7")
  barplot(table(eda$Response, eda$Cat8), bg=c('red', 'green')[unclass(eda$Response)], main="Cat8")
  barplot(table(eda$Response, eda$Cat9), bg=c('red', 'green')[unclass(eda$Response)], main="Cat9")
  barplot(table(eda$Response, eda$Cat10), bg=c('red', 'green')[unclass(eda$Response)], main="Cat10")
  barplot(table(eda$Response, eda$Cat11), bg=c('red', 'green')[unclass(eda$Response)], main="Cat11")
  barplot(table(eda$Response, eda$Cat12), bg=c('red', 'green')[unclass(eda$Response)], main="Cat12")
  
  
  fit1 <- rpart(Response ~., data=train[,c("Cat1", "Cat2", "Cat3", "Cat4", "Cat5", "Cat6",
                                    "Cat7", "Cat8", "Cat9", "Cat10", "Cat11", "Cat12",
                                    "Response")],
                      control=rpart.control(cp=0.0,minsplit=100))
  
  min_cp <- fit1$cptable[which.min(fit1$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit1, cp=0.00005)
  rpart.plot(pfit)
  
  fit2 <- rpart(Response ~ ., data=train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7",
                                     "Response")], control=rpart.control(cp=0,minsplit=25))
  rpart.plot(fit2)
  min_cp <- fit2$cptable[which.min(fit2$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit2, cp=0.00002)
  rpart.plot(pfit) 
}

# More Transformation and Indicator Variables,.. Tighten up
# tmp <- data.frame(unclass(t(table(train$Response, train$Model))))
# p_a <- (tmp$X1/(tmp$X0 + tmp$X1))
# p_e <- (tmp$X0 + tmp$X1)/(sum(tmp$X0) + sum(tmp$X1))
# p_d <- sum(p_a * p_e)                    
# model_risk <- data.frame(rownames(tmp), (p_a*p_e/p_d))
# names(model_risk) <- c('Model', 'M_Risk')
# train <- merge(train, model_risk, by.x="Model", by.y="Model", sort=F)
# test <- merge(test, model_risk, by.x="Model", by.y="Model", sort=F)

# Category ID Variables on train set
c_id1 <- as.factor(I(as.character(train$Cat1) %in% c('A','C','E','F','G')))
c_id2 <- as.factor(I(train$Cat3 %in% c('B','E')))
c_id3 <- as.factor(I(train$Cat6 %in% c('D','E')))
c_id4 <- as.factor(I(train$Cat6 %in% c('B')))
c_id5 <- as.factor(I(train$Cat8 %in% c('B','C')))
c_id6 <- as.factor(I(train$Cat3 %in% c('D')))
c_id7 <- as.factor(I(train$Cat12 %in% c('C')))
c_id8 <- as.factor(I(train$Cat10 %in% c('A')))

# Category ID Variables on Test Set 
t_c_id7 <- as.factor(I(test$Cat12 %in% c('C')))

# Transformed Continuous Variables on Train set
var1 <- log(abs(train$Var1 + train$Var2 + train$Var3 + train$Var5 + 
                  train$Var7) + 0.001) * 
                  sign((train$Var1 + train$Var2 + train$Var3 + train$Var5 + train$Var7))
var2 <- log(abs(train$Var6 + 0.001)) * sign(train$Var6)
var3 <- log(abs(train$Var8 + 0.001)) * sign(train$Var8)
var4 <- log(abs(train$NVVar1 + 0.001)) * sign(train$Var1)
var5 <- log(abs(train$NVVar2 + 0.001)) * sign(train$Var2)
var6 <- log(abs(train$NVVar3 + 0.001)) * sign(train$Var3)
var7 <- log(abs(train$NVVar4 + 0.001)) * sign(train$Var4)

# Transformed Continuous Variables on Test set
t_var1 <- log(abs(test$Var1 + test$Var2 + test$Var3 + test$Var5 + 
                  test$Var7) + 0.001) * 
                  sign((test$Var1 + test$Var2 + test$Var3 + test$Var5 + test$Var7))
t_var2 <- log(abs(test$Var6 + 0.001)) * sign(test$Var6)
t_var3 <- log(abs(test$Var8 + 0.001)) * sign(test$Var8)
t_var4 <- log(abs(test$NVVar1 + 0.001)) * sign(test$Var1)
t_var5 <- log(abs(test$NVVar2 + 0.001)) * sign(test$Var2)
t_var6 <- log(abs(test$NVVar3 + 0.001)) * sign(test$Var3)
t_var7 <- log(abs(test$NVVar4 + 0.001)) * sign(test$Var4)

# Reformatting Train Set
#x_id1 <- I(train$ModelYear < 1997)
train[(train$ModelYear < 1997), c('ModelYear')] <- 1997
train$CalendarYear <- train$CalendarYear - 2000
train$ModelYear <- train$ModelYear - 2000

# Reformatting Test Set
#x_id1 <- I(test$ModelYear < 1997)
test[(test$ModelYear < 1997), c('ModelYear')] <- 1997
test$CalendarYear <- test$CalendarYear - 2000
test$ModelYear <- test$ModelYear - 2000

new_data <- data.frame(train$CalendarYear, train$ModelYear, train$OrdCat, train$NVCat, 
                  train$Cat1, train$Cat2, train$Cat3, train$Cat4, train$Cat5, train$Cat6,
                  train$Cat7, train$Cat8, train$Cat9, train$Cat10, train$Cat11, train$Cat12,
                  var1, var2, var3, var4, var5, var6, var7, c_id7, 
                  train$Response)
names(new_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat', 
                      'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                      'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                      'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'c_id7',
                      'Response')

tst_data <- data.frame(test$CalendarYear, test$ModelYear, test$OrdCat, test$NVCat, 
                       test$Cat1, test$Cat2, test$Cat3, test$Cat4, test$Cat5, test$Cat6,
                       test$Cat7, test$Cat8, test$Cat9, test$Cat10, test$Cat11, test$Cat12, 
                       t_var1, t_var2, t_var3, t_var4, t_var5, t_var6, t_var7, t_c_id7)
names(tst_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat', 
                     'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                     'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                     'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'c_id7')


#Additional Transformation

# Normalize Variables

# Split train set into trn and xcv
set.seed(12345)
ix <- rbinom(nrow(new_data), 1, .7)
trn <- new_data[ix==1,][,]
xcv <- new_data[ix==0,][,]

write.csv(new_data, file="alst_cln.csv", row.names=FALSE) 

if (var_sel == "Y") {
  model.step <- glm(Response ~ ., data=trn, family = binomial("logit"))
  step(model.step, direction="both")
}

# GLM
model.glm <- glm(formula = Response ~ CalendarYear + ModelYear + OrdCat + 
                   NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + Cat10 + 
                   Cat11 + Cat12 + var5 + var6 + var7, family = binomial, 
                 data = trn)
pred <- predict(model.glm, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
      (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# GLM with Polynomial
for (i in 3:10) {
  model.glm.pol <- glm(formula = Response ~ poly(CalendarYear,2) + poly(ModelYear,4) + 
                         OrdCat + NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                         Cat10 + Cat11 + Cat12 +  
                         poly(var5,i) + poly(var6,i) + poly(var7,i), family = binomial, data = trn)
  pred <- predict(model.glm.pol, newdata=xcv, type="response")
  # Loss Function
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                                           (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))))
}
model.glm.pol <- glm(formula = Response ~ poly(CalendarYear,2) + poly(ModelYear,4) + 
                       OrdCat + NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                       Cat10 + Cat11 + Cat12 +  
                       poly(var5,7) + poly(var6,7) + poly(var7,7), family = binomial, data = trn)
pred <- predict(model.glm.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# GAM with Polynomial
for (i in 3:10) {
  model.gam.pol <- gam(formula = Response ~ CalendarYear + s(ModelYear,2) + 
                         OrdCat + NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                         Cat10 + Cat11 + Cat12 +  
                         s(var5,i) + s(var6,i) + s(var7,i), family = binomial, data = trn)
  pred <- predict(model.gam.pol, newdata=xcv, type="response")
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                                           (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))))
}
model.gam.pol <- gam(formula = Response ~ CalendarYear + s(ModelYear,2) + 
                       OrdCat + NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                       Cat10 + Cat11 + Cat12 +  
                       s(var5,10) + s(var6,10) + s(var7,10), family = binomial, data = trn)
pred <- predict(model.gam.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))


# Random Forest
model.rf <- randomForest(train.Response ~ .,
                         ntree=750, importance=T, data = trn)
pred <- predict(model.rf, newdata=xcv, type="response")
roc1 <- roc(xcv$train.Response, as.integer(as.character(pred)))
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))

#GBM
model.gbm <- gbm(as.numeric(as.character(train.Response)) ~ .,
                 n.trees=2000, shrinkage=0.01, interaction.depth=1,
                 data = trn)
pred <- predict(model.gbm, newdata=xcv, type="response", n.trees=2000)
roc1 <- roc(xcv$train.Response, as.integer(as.character(pred)))
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))

############################################################
## Predicting the Test Set with training on the full set,. 
############################################################
model.final <- gam(formula = Response ~ CalendarYear + s(ModelYear,2) + 
                     OrdCat + NVCat + Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                     Cat10 + Cat11 + Cat12 +  
                     s(var5,10) + s(var6,10) + s(var7,10), family = binomial, data = new_data)

# Impute Test Set For missing levels
# Cat6
tree_model_cat6 <- tree(Cat6 ~ ., data=new_data[,-ncol(new_data)])
tst_data[which(tst_data$Cat6 == "A"), c('Cat6')] <- 
            predict(tree_model_cat6, newdata = tst_data[which(tst_data$Cat6 == "A"),], type="class")


pred <- predict(model.final, newdata=tst_data, type="response")

sub <- data.frame(test$RowID, pred)
names(sub) <- c('RowID',  'ProbabilityOfResponse')
write.csv(sub, file="sub_1.csv", row.names=FALSE) 
