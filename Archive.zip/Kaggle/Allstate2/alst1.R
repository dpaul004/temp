library(tree)
library(h2o)
library(rpart.plot)
library(pROC)
library(gam)
require(cluster)
require(useful)
require(Hmisc)
require(plot3D)
library(HSAUR)
library(MVA)
library(HSAUR2)
library(fpc)
library(mclust)
library(lattice)
library(car)
library(corrplot)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Allstate2")

eda = "N"

train <- read.csv('train.csv', header=T)

Response <- as.factor(train$Response)
RowID <- train$RowID

# Initial Transformation
x_id1 <- I(train$ModelYear < 1997)
train[(train$ModelYear < 1997), c('ModelYear')] <- 1997

#train[(train$Cat3 %in% c('C', 'D', 'F')), c('Cat3')] <- "A"
#train[(train$Cat12 %in% c('A')), c('Cat12')] <- "B"
#train[(train$OrdCat > 4), c('OrdCat')] <- 3
train$Response <- as.factor(train$Response)
train$CalendarYear <- as.factor(train$CalendarYear)
train$ModelYear <- as.factor(train$ModelYear)

train[(train$Var2 > 2.0), c('Var2')] <- 2.0
train[(train$Var4 > 2.0), c('Var4')] <- 2.0
train[(train$Var4 > 1.75), c('Var4')] <- 1.75
train[(train$Var5 < -2.0), c('Var5')] <- -2.0
train[(train$Var5 > 1.75), c('Var5')] <- 1.75
train$Var6 <- log(abs(train$Var6) + 0.001) * sign(train$Var6)
#train[(train$Var8 > 2), c('Var8')] <- 2

#EDA
if (eda == "Y") {
  apply(train, 2, function(x) sum(is.na(x)))
  
  smp <- rbinom(nrow(train), 1, .6)
  eda <- train[smp==1,][]
  
  mcor <- cor(train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7", 'Var8',
                       'NVVar1', 'NVVar2','NVVar3','NVVar4')])
  corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)
  
  barplot(table(eda$Response, eda$Cat1), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  barplot(table(eda$Response, eda$Cat2), bg=c('red', 'green')[unclass(eda$Response)], main="Cat2")
  barplot(table(eda$Response, eda$Cat3), bg=c('red', 'green')[unclass(eda$Response)], main="Cat3")
  barplot(table(eda$Response, eda$Cat4), bg=c('red', 'green')[unclass(eda$Response)], main="Cat4")
  barplot(table(eda$Response, eda$Cat5), bg=c('red', 'green')[unclass(eda$Response)], main="Cat5")
  barplot(table(eda$Response, eda$Cat6), bg=c('red', 'green')[unclass(eda$Response)], main="Cat6")
  barplot(table(eda$Response, eda$Cat7), bg=c('red', 'green')[unclass(eda$Response)], main="Cat7")
  barplot(table(eda$Response, eda$Cat8), bg=c('red', 'green')[unclass(eda$Response)], main="Cat8")
  barplot(table(eda$Response, eda$Cat9), bg=c('red', 'green')[unclass(eda$Response)], main="Cat9")
  barplot(table(eda$Response, eda$Cat10), bg=c('red', 'green')[unclass(eda$Response)], main="Cat10")
  barplot(table(eda$Response, eda$Cat11), bg=c('red', 'green')[unclass(eda$Response)], main="Cat11")
  barplot(table(eda$Response, eda$Cat12), bg=c('red', 'green')[unclass(eda$Response)], main="Cat12")
  
  
  fit1 <- rpart(Response ~., data=train[,c("Cat1", "Cat2", "Cat3", "Cat4", "Cat5", "Cat6",
                                    "Cat7", "Cat8", "Cat9", "Cat10", "Cat11", "Cat12",
                                    "Response")],
                      control=rpart.control(cp=0.0,minsplit=100))
  
  min_cp <- fit1$cptable[which.min(fit1$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit1, cp=0.00005)
  rpart.plot(pfit)
  
  fit2 <- rpart(Response ~ ., data=train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7",
                                     "Response")], control=rpart.control(cp=0,minsplit=25))
  rpart.plot(fit2)
  min_cp <- fit2$cptable[which.min(fit2$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit2, cp=0.00002)
  rpart.plot(pfit) 
}

# More Transformation and Indicator Variables,.. Tighten up
tmp <- data.frame(unclass(t(table(train$Response, train$Model))))
p_a <- (tmp$X1/(tmp$X0 + tmp$X1))
p_e <- (tmp$X0 + tmp$X1)/(sum(tmp$X0) + sum(tmp$X1))
p_d <- sum(p_a * p_e)                    
model_risk <- data.frame(rownames(tmp), (p_a*p_e/p_d))
names(model_risk) <- c('Model', 'M_Risk')
train <- merge(train, model_risk, by.x="Model", by.y="Model", sort=F)
train <- train[,-(which(names(train) %in% c("RowID", "Model", "Make", "Response")))]

c_id1 <- I(as.character(train$Cat1) %in% c('A','C','E','F','G'))
c_id2 <- I(train$Cat3 %in% c('B','E'))
c_id3 <- I(train$Cat6 %in% c('D','E'))
c_id4 <- I(train$Cat6 %in% c('B'))
c_id5 <- I(train$Cat8 %in% c('B','C'))
c_id6 <- I(train$Cat3 %in% c('D'))
c_id7 <- I(train$Cat12 %in% c('C'))
c_id8 <- I(train$Cat10 %in% c('A'))

#Var8_Cat <- cut(train$Var8,12)
#train <- train[,-(which(names(train) %in% c("Var8")))]

v_id1 <- I(train$Var7 > 0)
v_id2 <- I(train$Var4 >= -0.571) 
v_id3 <- I(v_id2 & (train$Var2 >= 0.126))
v_id4 <- I(v_id3 & (train$Var7 < -1.267))
v_id5 <- I(v_id2 & v_id3 &  (-v_id4) & (train$Var4 >= 1.255))

new_data <- cbind(train, x_id1,
                  v_id1, v_id2, v_id3, v_id4, v_id5, Response)

#Additional Transformation

# Normalize Variables


# Split train set into trn and xcv
set.seed(12345)
ix <- rbinom(nrow(new_data), 1, .7)
trn <- new_data[ix==1,][,]
xcv <- new_data[ix==0,][,]

write.csv(new_data, file="alst_cln.csv", row.names=FALSE) 

if (var_sel == "Y") {
  model.step <- glm(Response ~ ., data=trn[,-1], family = binomial("logit"))
  step(model.step, direction="forward")
  
  model.full <- regsubsets(damt ~ ., data.train.std.y) 
}

model_glm <- glm(Response ~ ., data=trn, family = binomial("logit"))
pred <- predict(model_glm, newdata=xcv)
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))

model_glm_pol <- glm(Response ~ Cat2 + NVCat + poly(NVVar4,8) + poly(M_Risk,8) + poly(v_id2, 8), 
                     data=trn[,-1], family = binomial("logit"))
pred <- predict(model_glm_pol, newdata=xcv[,-1])
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))

model_gam <- glm(Response ~ CalendarYear + ModelYear + Cat1 + Cat2 + 
                   Cat3 + Cat4 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + Cat10 + 
                   Cat11 + Cat12 + OrdCat + s(Var1,6) + s(Var2,6) + s(Var3,6) + s(Var4,6) + s(Var5,6) + 
                   s(Var6,6) +  s(Var8,6) + NVCat + s(NVVar1,6) + 
                   s(NVVar2, 6) + s(NVVar3,6) + s(NVVar4,6) + 
                   Calendar + s(M_Risk,4) + c_id1 + c_id2 + c_id3 + v_id1 + v_id2 + 
                   v_id3 + v_id4 + v_id8 + v_id9, 
                     data=trn[,-1], family = binomial)
pred <- predict(model_gam, newdata=xcv[,-1])
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
