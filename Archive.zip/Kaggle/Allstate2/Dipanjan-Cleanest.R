library(tree)
library(h2o)
library(rpart.plot)
library(pROC)
library(gam)
require(cluster)
require(useful)
require(Hmisc)
require(plot3D)
library(HSAUR)
library(MVA)
library(HSAUR2)
library(fpc)
library(mclust)
library(lattice)
library(car)
library(corrplot)
library(gbm)
library(randomForest)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Allstate2")

eda = "N"
var_sel = "N"

train <- read.csv('train.csv', header=T)
test <- read.csv('test.csv', header=T)
test_orig <- read.csv('test.csv', header=T)
train_orig <- read.csv('train.csv', header=T)

str(train_orig$ModelYear)
hist(train_orig$ModelYear)

str(test_orig$ModelYear)
hist(test_orig$ModelYear)


# Initial Transformation
train$Response <- as.factor(train$Response)

#EDA
if (eda == "Y") {
  
  table(eda$Response, eda$OrdCat)
  
  table(test_orig$OrdCat)
  barplot(table(eda$Response, eda$OrdCat), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  
  hist()
  hist(log(train$OrdCat))
  
  
  apply(train, 2, function(x) sum(is.na(x)))
  apply(test, 2, function(x) sum(is.na(x)))
  
  smp <- rbinom(nrow(train), 1, .6)
  eda <- train[smp==1,][]
  
  mcor <- cor(train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7", 'Var8',
                       'NVVar1', 'NVVar2','NVVar3','NVVar4')])
  corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)
  
  barplot(table(eda$Response, eda$Cat1), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  barplot(table(eda$Response, eda$Cat2), bg=c('red', 'green')[unclass(eda$Response)], main="Cat2")
  barplot(table(eda$Response, eda$Cat3), bg=c('red', 'green')[unclass(eda$Response)], main="Cat3")
  barplot(table(eda$Response, eda$Cat4), bg=c('red', 'green')[unclass(eda$Response)], main="Cat4")
  barplot(table(eda$Response, eda$Cat5), bg=c('red', 'green')[unclass(eda$Response)], main="Cat5")
  barplot(table(eda$Response, eda$Cat6), bg=c('red', 'green')[unclass(eda$Response)], main="Cat6")
  barplot(table(eda$Response, eda$Cat7), bg=c('red', 'green')[unclass(eda$Response)], main="Cat7")
  barplot(table(eda$Response, eda$Cat8), bg=c('red', 'green')[unclass(eda$Response)], main="Cat8")
  barplot(table(eda$Response, eda$Cat9), bg=c('red', 'green')[unclass(eda$Response)], main="Cat9")
  barplot(table(eda$Response, eda$Cat10), bg=c('red', 'green')[unclass(eda$Response)], main="Cat10")
  barplot(table(eda$Response, eda$Cat11), bg=c('red', 'green')[unclass(eda$Response)], main="Cat11")
  barplot(table(eda$Response, eda$Cat12), bg=c('red', 'green')[unclass(eda$Response)], main="Cat12")
  
  barplot(table(eda$Response, eda$Var1), bg=c('red', 'green')[unclass(eda$Response)], main="Var1")
  
  
  boxplot(eda$Var1)
  
  
  
  
  fit1 <- rpart(Response ~., data=train[,c("Cat1", "Cat2", "Cat3", "Cat4", "Cat5", "Cat6",
                                           "Cat7", "Cat8", "Cat9", "Cat10", "Cat11", "Cat12",
                                           "Response")],
                control=rpart.control(cp=0.0,minsplit=100))
  
  min_cp <- fit1$cptable[which.min(fit1$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit1, cp=0.00005)
  rpart.plot(pfit)
  
  fit2 <- rpart(Response ~ ., data=train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7",
                                            "Response")], control=rpart.control(cp=0,minsplit=25))
  rpart.plot(fit2)
  min_cp <- fit2$cptable[which.min(fit2$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit2, cp=0.00002)
  rpart.plot(pfit) 
}

# Category ID Variables on train set
c_id1 <- as.integer(I(train$Cat1) %in% c('A','C','E','F','G'))
c_id2 <- as.integer(I(train$Cat2) %in% c('A'))
c_id3 <- as.integer(I(train$Cat3) %in% c('C','E'))
c_id4 <- as.integer(I(train$Cat4) %in% c('B'))
c_id5 <- as.integer(I(train$Cat3) %in% c('D','F'))
c_id6 <- as.integer(I(train$Cat5) %in% c('B','C'))
c_id7 <- as.integer(I(train$Cat6) %in% c('C','F'))
c_id8 <- as.integer(I(train$Cat6) %in% c('D','E'))
c_id9 <- as.integer(I(train$Cat7) %in% c('A','B'))
c_id10 <- as.integer(I(train$Cat7) %in% c('D'))
c_id11 <- as.integer(I(train$Cat9) %in% c('A'))
c_id12 <- as.integer(I(train$Cat12) %in% c('A'))

# Category ID Variables on test set
t_c_id1 <- as.integer(I(test$Cat1) %in% c('A','C','E','F','G'))
t_c_id2 <- as.integer(I(test$Cat2) %in% c('A'))
t_c_id3 <- as.integer(I(test$Cat3) %in% c('C','E'))
t_c_id4 <- as.integer(I(test$Cat4) %in% c('B'))
t_c_id5 <- as.integer(I(test$Cat3) %in% c('D','F'))
t_c_id6 <- as.integer(I(test$Cat5) %in% c('B','C'))
t_c_id7 <- as.integer(I(test$Cat6) %in% c('C','F'))
t_c_id8 <- as.integer(I(test$Cat6) %in% c('D','E'))
t_c_id9 <- as.integer(I(test$Cat7) %in% c('A','B'))
t_c_id10 <- as.integer(I(test$Cat7) %in% c('D'))
t_c_id11 <- as.integer(I(test$Cat9) %in% c('A'))
t_c_id12 <- as.integer(I(test$Cat12) %in% c('A'))

if (eda =="Y") {
  (c(min(train$Var1),quantile(train$Var1,c(.05,.10,.75,.90,.95,.99)),max(train$Var1),mean(train$Var1),median(train$Var1)))
  (c(min(train$Var2),quantile(train$Var2,c(.05,.10,.75,.90,.95,.99)),max(train$Var2),mean(train$Var2),median(train$Var2)))
  (c(min(train$Var3),quantile(train$Var3,c(.05,.10,.75,.90,.95,.99)),max(train$Var3),mean(train$Var3),median(train$Var3)))
  (c(min(train$Var4),quantile(train$Var4,c(.05,.10,.75,.90,.95,.99)),max(train$Var4),mean(train$Var4),median(train$Var4)))
  (c(min(train$Var5),quantile(train$Var5,c(.05,.10,.75,.90,.95,.99)),max(train$Var5),mean(train$Var5),median(train$Var5)))
  (c(min(train$Var6),quantile(train$Var6,c(.05,.10,.75,.90,.95,.99)),max(train$Var6),mean(train$Var6),median(train$Var6)))
  (c(min(train$Var7),quantile(train$Var7,c(.05,.10,.75,.90,.95,.99)),max(train$Var7),mean(train$Var7),median(train$Var7)))
  (c(min(train$Var8),quantile(train$Var8,c(.05,.10,.75,.90,.95,.99)),max(train$Var8),mean(train$Var8),median(train$Var8)))
  hist(train$Var1)
  hist(train$Var2)
  hist(train$Var3)
  hist(train$Var4)
  hist(train$Var5)
  hist(train$Var6)
  hist(train$Var7)
  hist(train$Var8)
}


# Reformatting Train Set Var1 through Var8

train$Var1[which(train$Var1 < -0.9792612)] <- -0.9792612
train$var1[(train$Var1 > 1)] <- 1

train$Var2[(train$Var2 < -2.0265319)] <- -2.0265319
train$Var2[(train$Var2 > 2)] <- 2

train$Var3[(train$Var3 < -1.5)] <- -1.5
train$Var3[(train$Var3 > 1.5)] <- 1.5

train$Var4[(train$Var4 < -1.3749984)] <- -1.3749984
train$Var4[(train$Var4 > 2.5151525)] <- 2.5151525

train$Var5[(train$Var5 < -1.1796368)] <- -1.1796368
train$Var5[(train$Var5 > 1.2408507)] <- 1.2408507

train$Var6[(train$Var6 < -1.3484815)] <- -1.3484815
train$Var6[(train$Var6 > 1)] <- 1

train$Var7[(train$Var7 < -1.0213619)] <- -1.0213619
train$Var7[(train$Var7 > 0.9077934)] <- 0.9077934

train$Var8[(train$Var8 < -0.934003701)] <- -0.934003701
train$Var8[(train$Var8 > 4.998416962)] <- 4.998416962

# Reformatting Test Set Var1 through Var8
test$Var1[(test$Var1 < -0.9792612)] <- -0.9792612
test$Var1[(test$Var1 > 1)] <- 1

test$Var2[(test$Var2 < -2.0265319)] <- -2.0265319
test$Var2[(test$Var2 > 2)] <- 2

test$Var3[(test$Var3 < -1.5)] <- -1.5
test$Var3[(test$Var3 > 1.5)] <- 1.5

test$Var4[(test$Var4 < -1.3749984)] <- -1.3749984
test$Var4[(test$Var4 > 2.5151525)] <- 2.5151525

test$Var5[(test$Var5 < -1.1796368)] <- -1.1796368
test$Var5[(test$Var5 > 1.2408507)] <- 1.2408507

test$Var6[(test$Var6 < -1.3484815)] <- -1.3484815
test$Var6[(test$Var6 > 1)] <- 1

test$Var7[(test$Var7 < -1.0213619)] <- -1.0213619
test$Var7[(test$Var7 > 0.9077934)] <- 0.9077934

test$Var8[(test$Var8 < -0.934003701)] <- -0.934003701
test$Var8[(test$Var8 > 4.998416962)] <- 4.998416962

#

if (eda == "Y") {
  print (c("min","5%","10%","75%","95%","99%","max","mean","median"))
  (c(min(train$NVVar1),quantile(train$NVVar1,c(.05,.10,.75,.90,.95,.99)),max(train$NVVar1),mean(train$NVVar1),median(train$NVVar1)))
  (c(min(train$NVVar2),quantile(train$NVVar2,c(.05,.10,.75,.90,.95,.99)),max(train$NVVar2),mean(train$NVVar2),median(train$NVVar2)))
  (c(min(train$NVVar3),quantile(train$NVVar3,c(.05,.10,.75,.90,.95,.99)),max(train$NVVar3),mean(train$NVVar3),median(train$NVVar3)))
  (c(min(train$NVVar4),quantile(train$NVVar4,c(.05,.10,.75,.90,.95,.99)),max(train$NVVar4),mean(train$NVVar4),median(train$NVVar4)))
  hist(train$NVVar1)
  hist(train$NVVar2)
  hist(train$NVVar3)
  hist(train$NVVar4)
  
  table(train$NVVar1)
  table(train$NVVar2)
  table(train$NVVar3)
  table(train$NVVar4)
}

# Train data
age <- train$CalendarYear - train$ModelYear


var1_10 <- cut(train$Var1, 10)
var2_10 <- cut(train$Var2, 10)
var3_10 <- cut(train$Var3, 10)
var4_10 <- cut(train$Var4, 10)
var5_10 <- cut(train$Var5, 10)
var6_10 <- cut(train$Var6, 10)
var7_10 <- cut(train$Var7, 10)
var8_10 <- cut(train$Var8, 10)


if (eda=="Y") {
  barplot(table(train$Response,var3_10))
  table(train$Response,var3_10)
  100*prop.table(table(train$Response,var3_10),2)
}

pos_nvvar1 <- as.integer(train$NVVar1>0) 
pos_nvvar2 <- as.integer(train$NVVar2>0) 
pos_nvvar3 <- as.integer(train$NVVar3>0) 
pos_nvvar4 <- as.integer(train$NVVar4>0) 

# Test data
t_age <- test$CalendarYear - test$ModelYear


t_pos_nvvar1 <- as.integer(test$NVVar1>0) 
t_pos_nvvar2 <- as.integer(test$NVVar2>0) 
t_pos_nvvar3 <- as.integer(test$NVVar3>0) 
t_pos_nvvar4 <- as.integer(test$NVVar4>0) 

t_var1_10 <- cut(test$Var1, 10)
t_var2_10 <- cut(test$Var2, 10)
t_var3_10 <- cut(test$Var3, 10)
t_var4_10 <- cut(test$Var4, 10)
t_var5_10 <- cut(test$Var5, 10)
t_var6_10 <- cut(test$Var6, 10)
t_var7_10 <- cut(test$Var7, 10)
t_var8_10 <- cut(test$Var8, 10)


transmake <- function(x) {
  if (x["Make"] %in% c("AU","K"))  {"A"}
  else if (x["Make"] %in% c("Y","X","BU")) {"B"}
  else if (x["Make"] %in% c("R","BH","AJ","AL","P","BF","AR","AQ","L")) {"C"}
  else {"D"}
}


#transmake <- function(x) {
#  if (x["Make"] %in% c("AC","AU","AN","AV","AX","BA","BF","BH","BP","Z"))  {"A"}
#  else if (x["Make"] %in% c("AH","AR","BZ","K","BV","M","X","Y")) {"B"}
#  else if (x["Make"] %in% c("AF","AG","AI","AJ","AL","AO","BG","AQ","AY"
#                            ,"AZ","BR","BT","BO","BU","L","BW","BY","N","O",
#                            "D","E","I","J","P","Q","R")) {"C"}
#  else {"D"}
#}

train$Model_Cat <- c('0')
train[(train$Model %in% c('AJ.129', 'AQ.17', 'AR.41', 'BV.8', 'L.29', 'M.16', 'Q.22', 'R.30')), c('Model_Cat')] <- '1'
train[(train$Model %in% c('AU.11', 'BF.36', 'BH.18', 'BO.38,', 'K.65', 'Y.10')), c('Model_Cat')] <- '2'
train[(train$Model %in% c('AU.58', 'X.24', 'Y.29', 'Y.34')), c('Model_Cat')] <- '3'
train[(train$Model %in% c('X.45', 'AU.14', 'K.7')), c('Model_Cat')] <- '4'
train$Model_Cat <- as.factor(train$Model_Cat)

test$Model_Cat <- c('0')
test[(test$Model %in% c('AJ.129', 'AQ.17', 'AR.41', 'BV.8', 'L.29', 'M.16', 'Q.22', 'R.30')), c('Model_Cat')] <- '1'
test[(test$Model %in% c('AU.11', 'BF.36', 'BH.18', 'BO.38,', 'K.65', 'Y.10')), c('Model_Cat')] <- '2'
test[(test$Model %in% c('AU.58', 'X.24', 'Y.29', 'Y.34')), c('Model_Cat')] <- '3'
test[(test$Model %in% c('X.45', 'AU.14', 'K.7')), c('Model_Cat')] <- '4'
test$Model_Cat <- as.factor(test$Model_Cat)


# Train data Make
train$Makebin <- ""
train$Makebin <- apply(train,1,transmake)
train$Makebin <- as.factor(train$Makebin)

# Test Data Make binning
test$Makebin <- ""
test$Makebin <- apply(test,1,transmake)

table(train$Response,train$Make)
table(test$Make)

# Category ID Variables on Test Set 
t_c_id7 <- as.factor(I(test$Cat12 %in% c('C')))

# Transformed Continuous Variables on Train set
var1 <- log(abs(train$Var1 + train$Var2 + train$Var3 + train$Var5 + 
                  train$Var7) + 0.001) * 
  sign((train$Var1 + train$Var2 + train$Var3 + train$Var5 + train$Var7))
var2 <- log(abs(train$Var6 + 0.001)) * sign(train$Var6)
var3 <- log(abs(train$Var8 + 0.001)) * sign(train$Var8)
var4 <- log(abs(train$NVVar1 + 0.001)) * sign(train$NVVar1)
var5 <- log(abs(train$NVVar2 + 0.001)) * sign(train$NVVar2)
var6 <- log(abs(train$NVVar3 + 0.001)) * sign(train$NVVar3)
var7 <- log(abs(train$NVVar4 + 0.001)) * sign(train$NVVar4)

if (eda=="Y") {
  hist(var1)
  hist(var2)
  hist(var3)
  hist(var4)
}

# Transformed Continuous Variables on Test set
t_var1 <- log(abs(test$Var1 + test$Var2 + test$Var3 + test$Var5 + 
                    test$Var7) + 0.001) * 
  sign((test$Var1 + test$Var2 + test$Var3 + test$Var5 + test$Var7))
t_var2 <- log(abs(test$Var6 + 0.001)) * sign(test$Var6)
t_var3 <- log(abs(test$Var8 + 0.001)) * sign(test$Var8)
t_var4 <- log(abs(test$NVVar1 + 0.001)) * sign(test$NVVar1)
t_var5 <- log(abs(test$NVVar2 + 0.001)) * sign(test$NVVar2)
t_var6 <- log(abs(test$NVVar3 + 0.001)) * sign(test$NVVar3)
t_var7 <- log(abs(test$NVVar4 + 0.001)) * sign(test$NVVar4)

if (eda=="Y") {
  hist(train$Var6)
  hist(t_var2)
}
# Reformatting Train Set
#x_id1 <- I(train$ModelYear < 1997)
train[(train$ModelYear < 1997), c('ModelYear')] <- 1997
train$CalendarYear <- train$CalendarYear - 2000
train$ModelYear <- train$ModelYear - 2000

# Reformatting Test Set
#x_id1 <- I(test$ModelYear < 1997)
test[(test$ModelYear < 1997), c('ModelYear')] <- 1997
test$CalendarYear <- test$CalendarYear - 2000
test$ModelYear <- test$ModelYear - 2000




new_data <- data.frame(train$CalendarYear, train$ModelYear, train$OrdCat, train$NVCat,train$Makebin,
                       train$Cat1, train$Cat2, train$Cat3, train$Cat4, train$Cat5, train$Cat6,
                       train$Cat7, train$Cat8, train$Cat9, train$Cat10, train$Cat11, train$Cat12,
                       train$Model_Cat,
                       var1, var2, var3, var4, var5, var6, var7, c_id7,
                       age,pos_nvvar1,pos_nvvar2,pos_nvvar3,pos_nvvar4,
                       var1_10,var2_10,var3_10,var4_10,var5_10,var6_10,var7_10,var8_10,
                       c_id1,c_id2,c_id3,c_id4,c_id5,
                       c_id6,c_id7,c_id8,c_id9,c_id10,
                       c_id11,c_id12,
                       train$Response)
names(new_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat','Makebin',
                     'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                     'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                     'Model_Cat',
                     'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'c_id7',
                     'age','pos_nvvar1','pos_nvvar2','pos_nvvar3','pos_nvvar4',
                     'var1_10','var2_10','var3_10','var4_10','var5_10','var6_10','var7_10','var8_10',
                     'c_id1','c_id2','c_id3','c_id4','c_id5',
                     'c_id6','c_id7','c_id8','c_id9','c_id10',
                     'c_id11','c_id12',
                     'Response')

tst_data <- data.frame(test$CalendarYear, test$ModelYear, test$OrdCat, test$NVCat,test$Makebin,
                       test$Cat1, test$Cat2, test$Cat3, test$Cat4, test$Cat5, test$Cat6,
                       test$Cat7, test$Cat8, test$Cat9, test$Cat10, test$Cat11, test$Cat12, 
                       test$Model_Cat,
                       t_var1, t_var2, t_var3, t_var4, t_var5, t_var6, t_var7, t_c_id7,
                       t_age, t_pos_nvvar1,t_pos_nvvar2,t_pos_nvvar3,t_pos_nvvar4,
                       t_var1_10,t_var2_10,t_var3_10,t_var4_10,t_var5_10,t_var6_10,t_var7_10,t_var8_10,
                       t_c_id1,t_c_id2,t_c_id3,t_c_id4,t_c_id5,
                       t_c_id6,t_c_id7,t_c_id8,t_c_id9,t_c_id10,
                       t_c_id11,t_c_id12)
names(tst_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat','Makebin', 
                     'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                     'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                     'Model_Cat',
                     'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'c_id7',
                     'age','pos_nvvar1','pos_nvvar2','pos_nvvar3','pos_nvvar4',
                     'var1_10','var2_10','var3_10','var4_10','var5_10','var6_10','var7_10','var8_10',
                     'c_id1','c_id2','c_id3','c_id4','c_id5',
                     'c_id6','c_id7','c_id8','c_id9','c_id10',
                     'c_id11','c_id12')


#Additional Transformation

# Normalize Variables

# Split train set into trn and xcv
set.seed(12345)
ix <- rbinom(nrow(new_data), 1, .7)
trn <- new_data[ix==1,][,]
xcv <- new_data[ix==0,][,]

write.csv(new_data, file="alst_cln.csv", row.names=FALSE) 

# Impute Tree
#tree_model_cat6 <- tree(Cat6 ~ ., data=new_data[,-ncol(new_data)])
#tst_data[which(tst_data$Cat6 == "A"), c('Cat6')] <- predict(tree_model_cat6, newdata = tst_data[which(tst_data$Cat6 == "A"),] , type='class')
tst_data[which(tst_data$Cat6 == "A"), c('Cat6')] <- 'F'

#### Testing GBM with limited set of variables
#### Last test - 4222016

bestShrinkage <- 0.08
bestNumTrees <- 360
bestInteractionDepth <- 2

model.gbm.lim <- gbm(as.integer(as.character(Response)) ~ age + 
                       OrdCat + NVCat + 
                       Makebin + 
                       Model_Cat + 
                       Cat3 + 
                       Cat5 + 
                       Cat6 + Cat7 + Cat8 + Cat9 + 
                       Cat11 + Cat12 + 
                       pos_nvvar1 + Cat10 + 
                       pos_nvvar2 + pos_nvvar3 + pos_nvvar4,
                     n.trees=bestNumTrees, shrinkage=bestShrinkage, interaction.depth=bestInteractionDepth,
                     distribution = "bernoulli",data = trn,bag.fraction=1,train.fraction=1)
pred <- predict(model.gbm.lim, newdata=xcv, type="response", n.trees=bestNumTrees)

# Log loss -> 0.577705395311675
print(c("GBM Log Loss:",-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                                               (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))))

summary(model.gbm.lim)

# 0.6081
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("model.gbm.lim AUC: ", round(roc1$auc,4), sep="")))

##

############################################################
## Predicting the Test Set with training on the full set,. 
############################################################

##################################################################
## Predicting the Test Set with training on the full set for GBM,. 
##################################################################

bestShrinkage <- 0.08
bestNumTrees <- 360
bestInteractionDepth <- 2

model.final.gbm <- gbm(as.integer(as.character(Response)) ~ age + 
                         OrdCat + NVCat + 
                         Makebin + 
                         Model_Cat +
                         Cat10 + pos_nvvar1 +
                         Cat3 + Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + 
                         Cat11 + Cat12 + 
                         pos_nvvar2 + pos_nvvar3 + pos_nvvar4,
                       n.trees=bestNumTrees, shrinkage=bestShrinkage, 
                       interaction.depth=bestInteractionDepth,
                       distribution = "bernoulli",
                       data = new_data, bag.fraction=1,train.fraction=1)

# Only for verification
pred <- predict(model.final.gbm, n.trees=bestNumTrees, newdata=new_data, type="response")
# Logloss - 0.577379289169541
print(c("Log Loss:",-(1/nrow(new_data)) * sum(as.integer(as.character(new_data$Response)) * log(pred) + 
                                                (1 - as.integer(as.character(new_data$Response))) * log(1 - pred))))

summary(model.final.gbm)
#0.6105
roc1 <- roc(new_data$Response, pred)
plot(roc1, main=c(paste("model.final AUC: ", round(roc1$auc,4), sep="")))

# Main Test data predictions and submission file generation 

pred <- predict(model.final.gbm, newdata=tst_data, n.trees = bestNumTrees, type="response")

sub.gbm <- data.frame(test$RowID, pred)
names(sub.gbm) <- c('RowID',  'ProbabilityOfResponse')

write.csv(sub.gbm, file="new_final_file.csv", row.names=FALSE) 

#verification
head(sub.gbm)
str(sub.gbm)
summary(sub.gbm)
