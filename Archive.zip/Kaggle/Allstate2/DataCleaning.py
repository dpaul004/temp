"""
@author Dipanjan Paul
"""

## For each day, develop weather information pattern on the past 3 days
## leading to the current day and the next 3 days starting from the current day.
## This weather pattern will include 7 days of weather information.

import csv
import sys
import pandas as pd
import logging
import argparse
import numpy as np
from sklearn import datasets, linear_model
from numpy import *
from sklearn.ensemble import RandomForestClassifier

# configure logging
logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

regr = linear_model.LinearRegression()


def data_cleaner(parm):
    data = pd.read_csv("train.csv",header=0)
    data.ix[:,'s'] = np.random.binomial(1, .7, shape(data)[0])
    trn = pd.DataFrame(data.loc[data.s == 1,:])
    xcv = pd.DataFrame(data.loc[data.s == 0,:])

    model = RandomForestClassifier(min_samples_split=10,)



if __name__ == "__main__":
    # set up logger
    parser = argparse.ArgumentParser(description=__doc__)
    data_cleaner('null')
