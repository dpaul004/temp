library(tree)
library(e1071)
library(h2o)
library(rpart.plot)
library(pROC)
library(gam)
require(cluster)
require(useful)
require(Hmisc)
require(plot3D)
library(HSAUR)
library(MVA)
library(HSAUR2)
library(fpc)
library(mclust)
library(lattice)
library(car)
library(corrplot)
library(gbm)
library(randomForest)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Allstate2")

eda = "N"
var_sel = "N"

train <- read.csv('train.csv', header=T)
test <- read.csv('test.csv', header=T)

# Initial Transformation
train$Response <- as.factor(train$Response)

#EDA
if (eda == "Y") {
  apply(train, 2, function(x) sum(is.na(x)))
  apply(test, 2, function(x) sum(is.na(x)))
  
  smp <- rbinom(nrow(train), 1, .6)
  eda <- train[smp==1,][]
  
  mcor <- cor(train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6")])
  corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)
  
  p_data <- train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6")]
  m <- matrix(rep(apply(p_data,FUN=mean,MARGIN=2),dim(p_data)[1]),nrow=dim(p_data)[1],byrow=TRUE);
  sd <- matrix(rep(apply(p_data,FUN=sd,MARGIN=2),dim(p_data)[1]),nrow=dim(p_data)[1],byrow=TRUE)
  
  p_data_n <- as.matrix((p_data - m)/sd)
  
  pca <-princomp(p_data_n)
  summary(pca)
  
  pca_df <- data.frame(pca$scores, train$Response)
  
  pairs(~ Comp.1 + Comp.2, data=pca_df,
        pch=21, bg=c('red', 'green')[unclass(pca_df$train.Response)])
  
  pca1 <- cut(pca_df$Comp.1, 5)
  pca2 <- cut(pca_df$Comp.2, 5)
  table(pca_df$train.Response, pca1, pca2)
  
  barplot(table(eda$Response, eda$Cat1), bg=c('red', 'green')[unclass(eda$Response)], main="Cat1")
  barplot(table(eda$Response, eda$Cat2), bg=c('red', 'green')[unclass(eda$Response)], main="Cat2")
  barplot(table(eda$Response, eda$Cat3), bg=c('red', 'green')[unclass(eda$Response)], main="Cat3")
  barplot(table(eda$Response, eda$Cat4), bg=c('red', 'green')[unclass(eda$Response)], main="Cat4")
  barplot(table(eda$Response, eda$Cat5), bg=c('red', 'green')[unclass(eda$Response)], main="Cat5")
  barplot(table(eda$Response, eda$Cat6), bg=c('red', 'green')[unclass(eda$Response)], main="Cat6")
  barplot(table(eda$Response, eda$Cat7), bg=c('red', 'green')[unclass(eda$Response)], main="Cat7")
  barplot(table(eda$Response, eda$Cat8), bg=c('red', 'green')[unclass(eda$Response)], main="Cat8")
  barplot(table(eda$Response, eda$Cat9), bg=c('red', 'green')[unclass(eda$Response)], main="Cat9")
  barplot(table(eda$Response, eda$Cat10), bg=c('red', 'green')[unclass(eda$Response)], main="Cat10")
  barplot(table(eda$Response, eda$Cat11), bg=c('red', 'green')[unclass(eda$Response)], main="Cat11")
  barplot(table(eda$Response, eda$Cat12), bg=c('red', 'green')[unclass(eda$Response)], main="Cat12")
  
  
  fit1 <- rpart(Response ~., data=train[,c("Cat1", "Cat2", "Cat3", "Cat4", "Cat5", "Cat6",
                                    "Cat7", "Cat8", "Cat9", "Cat10", "Cat11", "Cat12",
                                    "Response")],
                      control=rpart.control(cp=0.0,minsplit=100))
  
  min_cp <- fit1$cptable[which.min(fit1$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit1, cp=0.00005)
  rpart.plot(pfit)
  
  fit2 <- rpart(Response ~ ., data=train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6", "Var7",
                                     "Response")], control=rpart.control(cp=0,minsplit=25))
  rpart.plot(fit2)
  min_cp <- fit2$cptable[which.min(fit2$cptable[,"xerror"]),"CP"]
  pfit <- prune(fit2, cp=0.00002)
  rpart.plot(pfit) 
}

#More Transformation and Indicator Variables,.. Tighten up
train[(train$Var8 > 2.5), c('Var8')] <- 2.5
test[(test$Var8 > 2.5), c('Var8')] <- 2.5

tmp <- data.frame(unclass(t(table(train$Response, train$Model))))
p_a <- (tmp$X1/(tmp$X0 + tmp$X1))
p_e <- (tmp$X0 + tmp$X1)/(sum(tmp$X0) + sum(tmp$X1))
p_d <- sum(p_a * p_e)                    
model_risk <- data.frame(rownames(tmp), (p_a*p_e/p_d))
names(model_risk) <- c('Model', 'M_Risk')
train <- merge(train, model_risk, by.x="Model", by.y="Model", sort=F)
test <- merge(test, model_risk, by.x="Model", by.y="Model", sort=F, all.x=T)

train$Model_Cat <- c('0')
train[(train$Model %in% c('AJ.129', 'AQ.17', 'AR.41', 'BV.8', 'L.29', 'M.16', 'Q.22', 'R.30')), c('Model_Cat')] <- '1'
train[(train$Model %in% c('AU.11', 'BF.36', 'BH.18', 'BO.38,', 'K.65', 'Y.10')), c('Model_Cat')] <- '2'
train[(train$Model %in% c('AU.58', 'X.24', 'Y.29', 'Y.34')), c('Model_Cat')] <- '3'
train[(train$Model %in% c('X.45', 'AU.14', 'K.7')), c('Model_Cat')] <- '4'
train$Model_Cat <- as.factor(train$Model_Cat)

test$Model_Cat <- c('0')
test[(test$Model %in% c('AJ.129', 'AQ.17', 'AR.41', 'BV.8', 'L.29', 'M.16', 'Q.22', 'R.30')), c('Model_Cat')] <- '1'
test[(test$Model %in% c('AU.11', 'BF.36', 'BH.18', 'BO.38,', 'K.65', 'Y.10')), c('Model_Cat')] <- '2'
test[(test$Model %in% c('AU.58', 'X.24', 'Y.29', 'Y.34')), c('Model_Cat')] <- '3'
test[(test$Model %in% c('X.45', 'AU.14', 'K.7')), c('Model_Cat')] <- '4'
test$Model_Cat <- as.factor(test$Model_Cat)

# PCA Area
p_data <- train[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6")]
m <- matrix(rep(apply(p_data,FUN=mean,MARGIN=2),dim(p_data)[1]),nrow=dim(p_data)[1],byrow=TRUE);
sd <- matrix(rep(apply(p_data,FUN=sd,MARGIN=2),dim(p_data)[1]),nrow=dim(p_data)[1],byrow=TRUE)
p_data_n <- as.matrix((p_data - m)/sd)
eigen.vectors <- eigen(t(p_data_n)%*%p_data_n)$vectors
trn.pca <- p_data_n %*% eigen.vectors

p_data_tst <- test[,c("Var1", "Var2", "Var3", "Var4", "Var5", "Var6")]
p_data_n_tst <- as.matrix((p_data_tst - m)/sd)
tst.pca <- p_data_n_tst %*% eigen.vectors

# Transformed Continuous Variables on Train set
var1 <- trn.pca[,1]
var2 <- trn.pca[,2]
var3 <- log(abs(train$Var7 + 0.00001)) * sign(train$Var7)
var4 <- log(abs(train$Var8 + 0.00001)) * sign(train$Var8)

var5 <- log(abs(train$NVVar1 + 0.00001)) * sign(train$NVVar1)
var6 <- log(abs(train$NVVar2 + 0.00001)) * sign(train$NVVar2)
var7 <- log(abs(train$NVVar3 + 0.00001)) * sign(train$NVVar3)
var8 <- log(abs(train$NVVar4 + 0.00001)) * sign(train$NVVar4)

# Transformed Continuous Variables on Test set
t_var1 <- tst.pca[,1]
t_var2 <- tst.pca[,2]
t_var3 <- log(abs(test$Var7 + 0.00001)) * sign(test$Var7)
t_var4 <- log(abs(test$Var8 + 0.00001)) * sign(test$Var8)

t_var5 <- log(abs(test$NVVar1 + 0.00001)) * sign(test$NVVar1)
t_var6 <- log(abs(test$NVVar2 + 0.00001)) * sign(test$NVVar2)
t_var7 <- log(abs(test$NVVar3 + 0.00001)) * sign(test$NVVar3)
t_var8 <- log(abs(test$NVVar4 + 0.00001)) * sign(test$NVVar4)

# Reformatting Train Set
#x_id1 <- I(train$ModelYear < 1997)
train[(train$ModelYear < 1997), c('ModelYear')] <- 1997
train$CalendarYear <- train$CalendarYear - 1997
train$ModelYear <- train$ModelYear - 1997
train$Age <- train$CalendarYear - train$ModelYear

# Reformatting Test Set
#x_id1 <- I(test$ModelYear < 1997)
test[(test$ModelYear < 1997), c('ModelYear')] <- 1997
test$CalendarYear <- test$CalendarYear - 1997
test$ModelYear <- test$ModelYear - 1997
test$Age <- test$CalendarYear - test$ModelYear

## Additional Vars
# Train data
pos_nvvar1 <- as.integer(train$NVVar1>0) 
pos_nvvar2 <- as.integer(train$NVVar2>0) 
pos_nvvar3 <- as.integer(train$NVVar3>0) 
pos_nvvar4 <- as.integer(train$NVVar4>0) 

# Test data
t_pos_nvvar1 <- as.integer(test$NVVar1>0) 
t_pos_nvvar2 <- as.integer(test$NVVar2>0) 
t_pos_nvvar3 <- as.integer(test$NVVar3>0) 
t_pos_nvvar4 <- as.integer(test$NVVar4>0) 

transmake <- function(x) {
  if (x["Make"] %in% c("AU","K"))  {"A"}
  else if (x["Make"] %in% c("Y","X","BU")) {"B"}
  else if (x["Make"] %in% c("R","BH","AJ","AL","P","BF","AR","AQ","L")) {"C"}
  else {"D"}
  
}

# Train data Make
train$Makebin <- ""
train$Makebin <- apply(train,1,transmake)
train$Makebin <- as.factor(train$Makebin)

# Test Data Make binning
test$Makebin <- ""
test$Makebin <- apply(test,1,transmake)

new_data <- data.frame(train$CalendarYear, train$ModelYear, train$OrdCat, train$NVCat, train$M_Risk, train$Makebin,
                       train$Model_Cat, train$Age, train$Cat1, train$Cat2, train$Cat3, train$Cat4, train$Cat5, train$Cat6,
                       train$Cat7, train$Cat8, train$Cat9, train$Cat10, train$Cat11, train$Cat12,
                       var1, var2, var3, var4, var5, var6, var7, var8,
                       pos_nvvar1, pos_nvvar2, pos_nvvar3, pos_nvvar4,
                       train$Response)
names(new_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat', 'M_Risk', 'Makebin',  'Model_Cat', 'Age',
                      'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                      'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                      'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'var8',
                      'pos_nvvar1','pos_nvvar2','pos_nvvar3','pos_nvvar4',
                      'Response')

tst_data <- data.frame(test$CalendarYear, test$ModelYear, test$OrdCat, test$NVCat, test$Makebin, test$M_Risk,
                       test$Model_Cat, test$Age, test$Cat1, test$Cat2, test$Cat3, test$Cat4, test$Cat5, test$Cat6,
                       test$Cat7, test$Cat8, test$Cat9, test$Cat10, test$Cat11, test$Cat12, 
                       t_var1, t_var2, t_var3, t_var4, t_var5, t_var6, t_var7, t_var8,
                       t_pos_nvvar1, t_pos_nvvar2, t_pos_nvvar3, t_pos_nvvar4)
names(tst_data) <- c('CalendarYear', 'ModelYear', 'OrdCat', 'NVCat', 'Makebin',  'M_Risk', 'Model_Cat', 'Age',
                     'Cat1', 'Cat2', 'Cat3', 'Cat4', 'Cat5', 'Cat6',
                     'Cat7', 'Cat8', 'Cat9', 'Cat10', 'Cat11', 'Cat12', 
                     'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'var8',
                     'pos_nvvar1','pos_nvvar2','pos_nvvar3','pos_nvvar4')

#Additional Transformation

# Normalize Variables

# Split train set into trn and xcv
set.seed(12345)
ix <- rbinom(nrow(new_data), 1, .7)
trn <- new_data[ix==1,][,]
xcv <- new_data[ix==0,][,]

write.csv(new_data, file="alst_cln.csv", row.names=FALSE) 

if (var_sel == "Y") {
  model.step <- glm(Response ~ ., data=trn, family = binomial("logit"))
  step(model.step, direction="both")
}

# GLM
model.glm <- glm(formula = Response ~ CalendarYear + ModelYear + OrdCat + 
                   NVCat + M_Risk + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                   Cat9 + Cat10 + Cat11 + var1 + var5 + var8, family = binomial, 
                 data = trn)
pred <- predict(model.glm, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
      (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# GLM with Polynomial
for (i in 3:10) {
  model.glm.pol <- glm(formula = Response ~ poly(CalendarYear,2) + poly(ModelYear,4) + OrdCat + Makebin + 
                         NVCat + Cat3 + Cat5 + Cat7 + Cat8 + 
                         Cat9 + Cat10 + Cat11 + 
                         poly(var1,i) + poly(var5,i) + poly(var8,i) +
                         pos_nvvar1 + pos_nvvar2 + pos_nvvar3 + pos_nvvar4, family = binomial, data = trn)
  pred <- predict(model.glm.pol, newdata=xcv, type="response")
  # Loss Function
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                                           (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))))
}
model.glm.pol <- glm(formula = Response ~ poly(CalendarYear,2) + poly(ModelYear,4) + OrdCat + 
                       NVCat + poly(M_Risk, 2) + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                       Cat9 + Cat10 + Cat11 + 
                       poly(var1,5) + poly(var5,5) + poly(var8,5), family = binomial, data = trn)
pred <- predict(model.glm.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# GAM with Polynomial
for (i in 3:10) {
  model.gam.pol <- gam(formula = Response ~  OrdCat + s(Age, i) + 
                         NVCat + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                         Cat9 + Cat10 + Cat11 + 
                         s(var1,i) + s(var5,i) + s(var8,i) + 
                         pos_nvvar1 + pos_nvvar2 + pos_nvvar3 + pos_nvvar4 +
                         OrdCat*NVCat + Age*NVCat + Age*pos_nvvar3 + Age*OrdCat, 
                         family = binomial, data = trn)
  pred <- predict(model.gam.pol, newdata=xcv, type="response")
  print(c("Loss: ", -(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                                           (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))))
}
model.gam.pol <- gam(formula = Response ~  OrdCat + s(Age, 9) + 
                       NVCat + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                       Cat9 + Cat10 + Cat11 + 
                       s(var1,9) + s(var5,9) + s(var8,9) + 
                       pos_nvvar1 + pos_nvvar2 + pos_nvvar3 + pos_nvvar4 +
                       OrdCat*NVCat + Age*NVCat + Age*pos_nvvar3 + Age*OrdCat, family = binomial, data = trn)
pred <- predict(model.gam.pol, newdata=xcv, type="response")
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# SVM
svm.model <- svm(Response ~ CalendarYear + ModelYear + OrdCat + 
                   NVCat + M_Risk + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                   Cat9 + Cat10 + Cat11 + var1 + var5 + var8, 
                   kernel="radial", 
                   ranges=list(cost=c(0.001, 0.01, 0.1, 1, 5, 10, 100), gamma=c(0.5,1,2,3,4)),
                   data = trn)
summary(svm.model)
pred <- predict(svm.model, newdata=xcv, type="response") # n.valid post probs
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

## LDA
library(MASS)
model.lda1 <- lda(Response ~ CalendarYear + ModelYear + OrdCat + 
                    NVCat + M_Risk + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                    Cat9 + Cat10 + Cat11 + var1 + var5 + var8, data=trn) 
pred <- predict(model.lda1, xcv)$posterior[,2]
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

# GLMNET with Ridge, LASSO and PCA 
tr_x <- model.matrix(  ~ ., data = trn[,-ncol(trn)])[,-1]
tr_y <- trn$Response

vl_x <- model.matrix(  ~ ., data = xcv[,-ncol(xcv)])[,-1]
vl_y <- xcv$Response

#Ridge
grid <- 10^seq(10, -2, length=100)
ridge.mod <- glmnet(tr_x, tr_y, family=c("binomial"), alpha=0, lambda=grid)
plot(ridge.mod, xvar="lambda", label=T)

cv.out <- cv.glmnet(tr_x, tr_y, family=c("binomial"), alpha=0)
plot(cv.out)
bestlam <- cv.out$lambda.min
maxlam <- cv.out$lambda.1se

pred <- predict(ridge.mod, s=bestlam, newx=vl_x, type="response") # n.valid post probs
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

#Lasso
lasso.mod <- glmnet(tr_x, tr_y, family=c("binomial"), alpha=1, lambda=grid)
plot(lasso.mod, xvar="lambda", label=T)

cv.out <- cv.glmnet(tr_x, tr_y, family=c("binomial"), alpha=1)
plot(cv.out)
bestlam <- cv.out$lambda.min
maxlam <- cv.out$lambda.1se

pred <- predict(lasso.mod, s=bestlam, newx=vl_x, type="response") # n.valid post probs
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))

#Lasso
lasso.mod <- glmnet(tr_x, tr_y, family=c("binomial"), alpha=1, lambda=grid)
plot(lasso.mod, xvar="lambda", label=T)

cv.out <- cv.glmnet(tr_x, tr_y, family=c("binomial"), alpha=1)
plot(cv.out)
bestlam <- cv.out$lambda.min
maxlam <- cv.out$lambda.1se

pred <- predict(lasso.mod, s=bestlam, newx=vl_x, type="response") # n.valid post probs
roc1 <- roc(xcv$Response, pred)
plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
# Loss Function
-(1/nrow(xcv)) * sum(as.integer(as.character(xcv$Response)) * log(pred) + 
                       (1 - as.integer(as.character(xcv$Response))) * log(1 - pred))


############################################################
## Predicting the Test Set with training on the full set,. 
############################################################
model.final <- gam(formula = Response ~  OrdCat + s(Age, 7) + 
                       NVCat + Model_Cat + Cat3 + Cat5 + Cat7 + Cat8 + 
                       Cat9 + Cat10 + Cat11 + 
                       s(var1,7) + s(var5,7) + s(var8,7) + 
                       pos_nvvar1 + pos_nvvar2 + pos_nvvar3 + pos_nvvar4 +
                       OrdCat*NVCat + Age*NVCat + Age*pos_nvvar3 + Age*OrdCat, family = binomial, data = new_data)

# Impute Test Set For missing levels
# Cat6
tree_model_cat6 <- tree(Cat6 ~ ., data=new_data[,-ncol(new_data)])
tst_data[which(tst_data$Cat6 == "A"), c('Cat6')] <- 
            predict(tree_model_cat6, newdata = tst_data[which(tst_data$Cat6 == "A"),], type="class")

#M_Risk
model_M_Risk <- lm(M_Risk ~ ModelYear + OrdCat + Cat1 + Cat2 + Cat3 + 
                     Cat5 + Cat6 + Cat7 + Cat8 + Cat9 + var1 + var2 + var3 + var4 + 
                     var5 + var6 + var7, data=new_data[,-ncol(new_data)])

tst_missing_idx <- which(is.na(tst_data[,c('M_Risk')] == T))
tst_data[tst_missing_idx, c('M_Risk')] <- 
  predict(model_M_Risk, newdata = tst_data[tst_missing_idx,])
tst_data[(tst_data$M_Risk < 0), c('M_Risk')] <- 0

#
pred <- predict(model.final, newdata=tst_data, type="response")

sub <- data.frame(test$RowID, pred)
names(sub) <- c('RowID',  'ProbabilityOfResponse')
write.csv(sub, file="sub_1.csv", row.names=FALSE) 
