setwd("/Users/dipanjanpaul/Documents/Models/Kaggle/Springleaf")
require(xgboost)

mode <- c('regular')

train <- read.csv("train.csv", header=T)
test <- read.csv("test.csv",header=T)

#train <- train[,-1]
id <- test$ID
test <- test[,-1]

#train <- apply(train, c(1,2), as.numeric)
#test <- apply(test, c(1,2), as.numeric)

dtrain <- xgb.DMatrix(data.matrix(train[,feature.names]), label=train$target)

#train_M <- as.matrix(train)
test_M <- as.matrix(test)

param <- list("objective" = "binary:logistic", max.depth = 12, gamma = 2, eta = 0.001, colsample_bytree = .8,
              min_child_width = 5, "eval_metric" = "auc", subsample = .8)

if (mode == "xcv") {
  cv.nround <- 5
  cv.nfold <- 3
  
  bst.cv = xgb.cv(param=param, data = train_M, label = t_target, 
                  nfold = cv.nfold, nrounds = cv.nround)
}

bst = xgb.train(param=param, data = dtrain, nrounds = 800, verbose=0) 

#names <- dimnames(train_M)[[2]]
#imp_mat <- xgb.importance(names,model=bst)
#xgb.plot.importance(imp_mat[1:20])

pred <- predict(bst, test_M)
pred <- data.frame(id,pred)
names(pred) = c('id', 'target')

write.csv(pred,file='sub_xgb_r.csv', quote=FALSE,row.names=FALSE)