__author__ = 'dipanjanpaul'

import pandas as pd
import graphlab as gl
from numpy import *

def train():

    train = gl.SFrame.read_csv('train.csv')
    del train['"ID"']

    test = gl.SFrame.read_csv('test.csv')
    id = test['"ID"']
    del test['"ID"']

    model = gl.boosted_trees_classifier.create(train, target = '"target"', max_iterations=100,
                                               max_depth=14, row_subsample=.8, column_subsample=.8)

#    model = gl.boosted_trees_classifier.create(train, target = '"target"', max_iterations=800,
#                                               max_depth=9, step_size=.05, min_loss_reduction=1)

    output = model.predict(test)
    df = gl.SFrame([id,output])
    df.rename({'X1':'ID', 'X2':'target'})
    df.save("results.csv")

if __name__ == "__main__":
    train()
    print('Done')





