parm <- "none"
setwd("/Users/dipanjanpaul/Documents/Models/Kaggle/Springleaf")

train <- read.csv('train-5.csv', header=T)
test <- read.csv('test-4.csv', header=T)

#Removing redundant columns. These columns are a replication of VAR_008  
nam <- names(train) 
rmcols2 <- c(which(nam == "VAR_0009"), which(nam == "VAR_0010"), which(nam == "VAR_0011"),
             which(nam == "VAR_0012"), which(nam == "VAR_0043"), which(nam == "VAR_0044"),
             which(nam == "VAR_0207"), which(nam == "VAR_0208"), which(nam == "VAR_0213"), 
             which(nam == "VAR_0840"), which(nam == "VAR_0196"), which(nam == "VAR_0202"),
             which(nam == "VAR_0216"), which(nam == "VAR_0222"), which(nam == "VAR_0229"),
             which(nam == "VAR_0239"), which(nam == "VAR_0214"), which(nam == "VAR_0008"),
             which(nam == "VAR_0226"), which(nam == "VAR_0230"), which(nam == "VAR_0236"),
             which(nam == "VAR_0526"), which(nam == "VAR_0529"),
             which(nam == "VAR_0073"), which(nam == "VAR_0156"), which(nam == "VAR_0157"),
             which(nam == "VAR_0158"), which(nam == "VAR_0159"), which(nam == "VAR_0166"),
             which(nam == "VAR_0167"), which(nam == "VAR_0168"), which(nam == "VAR_0176"), 
             which(nam == "VAR_0177"), which(nam == "VAR_0178"), which(nam == "VAR_0179"))

train <- train[,-rmcols2]
test <- test[,-rmcols2]


for (i in (2:(ncol(train)-1))) {
  if (is.numeric(train[,i])) {
    train[which(is.na(train[,i])),i] <- median(train[-which(is.na(train[,i])),i])
    train[(which(train[,i] > 99999990)), i] <- median(train[,i])
    train[(which(train[,i] < -99999990)), i] <- median(train[,i])
  }    
}

for (i in (2:(ncol(test)-1))) {
  if (is.numeric(test[,i])) {
    test[which(is.na(test[,i])),i] <- median(test[-which(is.na(test[,i])),i])
    test[(which(test[,i] > 99999990)), i] <- median(test[,i])
    test[(which(test[,i] < -99999990)), i] <- median(test[,i])
  }    
}

nam <- names(train)

# Removing columns with 0 SD
rmcols1 <- which(apply(train,2,sd) == 0)
train <- train[,-rmcols1]
test <- test[,-rmcols1]

# Get the numeric Columns
numcols <- which(sapply(train[2:(ncol(train)-1)],is.numeric) == TRUE) + 1

train_dfo <- train[,-numcols]
#train_dfo[train_dfo==-1] = NA
#train_dfo[train_dfo==""] = NA
#train_dfo[train_dfo=="[]"] = NA

# Create a dateframe with numeric columns for PCA
train_df <- train[,numcols]
train_df_norm <- as.data.frame(apply(train_df, 2, function(x) (x - mean(x))/sd(x)))
rm(train)

test_dfo <- test[,-numcols]
#test_dfo[test_dfo==-1] = NA
#test_dfo[test_dfo==""] = NA
#test_dfo[test_dfo=="[]"] = NA
test_df <- test[,numcols]
test_df_norm <- as.data.frame(apply(test_df, 2, function(x) (x - mean(x))/sd(x)))
rm(test, test_df)

x <- cor(train_df_norm)
indx <- row(x) - col(x)
x[indx <= 0] <- 0
x[x != 1] <- 0
ln_cols <- names(which(colSums(x) == 1))

rmcols3 <- match(ln_cols, names(train_df))

train_df_norm <- train_df_norm[,-rmcols3]
train_df_mat <- as.matrix(train_df_norm)
rm(train_df_norm, train_df)

SS <- t(train_df_mat)%*%train_df_mat
SS.eigen <- eigen(SS,only.values=FALSE)

test_df_norm <- test_df_norm[,-rmcols3]
test_df_mat <- as.matrix(test_df_norm)
rm(test_df_norm)
gc()

V <- SS.eigen$vectors

train_Z <- train_df_mat %*% V
train_Z_df <- as.data.frame(train_Z[,1:300])
train <- cbind(train_dfo, train_Z_df)
target <- train$target
train <- train[,-which(names(train) == c('target'))]
train$target <- target

test_Z <- test_df_mat %*% V
test_Z_df <- as.data.frame(test_Z[,1:300])
test <- cbind(test_dfo, test_Z_df)

train$VAR_0342_FLAG <- ifelse((train$VAR_0342 %in% c('', '[]', '-1')), 1, 0 )
train$VAR_0354_FLAG <- ifelse((train$VAR_0354 %in% c('', '[]', '-1')), 1, 0 )
train$VAR_0404_FLAG <- ifelse((train$VAR_0404 %in% c('', '[]', '-1')), 1, 0 )
train$VAR_0466_FLAG <- ifelse((train$VAR_0466 %in% c('', '[]', '-1')), 1, 0 )
train$VAR_0467_FLAG <- ifelse((train$VAR_0467 %in% c('', '[]', '-1')), 1, 0 )
train$VAR_0493_FLAG <- ifelse((train$VAR_0493 %in% c('', '[]', '-1')), 1, 0 )

test$VAR_0342_FLAG <- ifelse((test$VAR_0342 %in% c('', '[]', '-1')), 1, 0 )
test$VAR_0354_FLAG <- ifelse((test$VAR_0354 %in% c('', '[]', '-1')), 1, 0 )
test$VAR_0404_FLAG <- ifelse((test$VAR_0404 %in% c('', '[]', '-1')), 1, 0 )
test$VAR_0466_FLAG <- ifelse((test$VAR_0466 %in% c('', '[]', '-1')), 1, 0 )
test$VAR_0467_FLAG <- ifelse((test$VAR_0467 %in% c('', '[]', '-1')), 1, 0 )
test$VAR_0493_FLAG <- ifelse((test$VAR_0493 %in% c('', '[]', '-1')), 1, 0 )

feature.names <- names(train)[2:(ncol(train)-1)]
for (f in feature.names) {
  if (class(train[[f]])=="factor") {
    levels <- unique(c(as.character(train[[f]]), as.character(test[[f]])))
    train[[f]] <- as.integer(factor(train[[f]], levels=levels))
    test[[f]]  <- as.integer(factor(test[[f]],  levels=levels))
  }
}

write.table(train,"train.csv",sep=',',col.names=T,row.names=F)
write.table(test,"test.csv",sep=",",col.names=T,row.names=F)

rm(list=ls())
gc()