__author__ = 'dipanjanpaul'

import pandas as pd
from datetime import *
from sklearn.ensemble import RandomForestRegressor
from sklearn import linear_model as lm
from sklearn.ensemble import AdaBoostRegressor
from sklearn.feature_extraction.text import TfidfTransformer
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm):

    results = open("results.csv", "wb")
    out_file_obj = csv.writer(results)
    out_file_obj.writerow(['id','units'])

    data_trn = (pd.read_csv('train_ext.csv',header=0))
    data_tst = (pd.read_csv('test_enh.csv',header=0))

    pred = pd.DataFrame()
    transformer = TfidfTransformer()

    items = data_trn.item_nbr.unique()

    for item in items:
        train = pd.DataFrame(data_trn.loc[data_trn.item_nbr == item,:])
        units = train.units.values

        train["store_nbr"] = train["store_nbr"].astype('category')
        train["station_nbr"] = train["station_nbr"].astype('category')

        train["wkday"] = map(lambda x: datetime.strptime(x,"%Y-%m-%d").weekday(), train["date"])
        train.loc[train.wkday > 4,:]["wkday"] = "W"
        train.loc[train.wkday <= 4,:]["wkday"] = "H"
        train["wkday"] = train["wkday"].astype('category')

        train.loc[train.day < 0,"day"] = train.loc[train.day < 0,"day"] + 7
        train.loc[train.day == 0,"day"] = 7
        train.loc[train.day < 4,"day"] = abs(train.loc[train.day < 4,"day"] - 7) 
        
        train["TS"] = train["TS"].astype('category')
        train["RA"] = train["RA"].astype('category')
        train["DZ"] = train["DZ"].astype('category')
        train["SN"] = train["SN"].astype('category')
        train["FG"] = train["FG"].astype('category')
        train["FG."] = train["FG."].astype('category')
        train["BR"] = train["BR"].astype('category')
        train["HZ"] = train["HZ"].astype('category')
        train["FZ"] = train["FZ"].astype('category')

        train["GR"] = train["GR"].astype('category')
        train["SG"] = train["SG"].astype('category')
        train["GS"] = train["GS"].astype('category')
        train["PL"] = train["PL"].astype('category')
        train["FU"] = train["FU"].astype('category')
        train["DU"] = train["DU"].astype('category')
        train["SS"] = train["SS"].astype('category')
        train["SQ"] = train["SQ"].astype('category')
        train["MI"] = train["MI"].astype('category')
        train["PR"] = train["PR"].astype('category')
        train["BC"] = train["BC"].astype('category')
        train["BL"] = train["BL"].astype('category')

        #train["tmax"]        =  train["tmax"]/(max(train["tmax"])-min(train["tmin"]))
        #train["tmin"]        =  train["tmin"]/(max(train["tmin"])-min(train["tmin"]))
        #train["tavg"]        =  train["tavg"]/(max(train["tavg"])-min(train["tavg"]))
        #train["dewpoint"]    =  train["dewpoint"]/(max(train["dewpoint"])-min(train["dewpoint"]))
        #train["wetbulb"]     =  train["wetbulb"]/(max(train["wetbulb"])-min(train["wetbulb"]))
        #train["snowfall"]    =  train["snowfall"]/(max(train["snowfall"])-min(train["snowfall"]))
        #train["preciptotal"] =  train["preciptotal"]/(max(train["preciptotal"])-min(train["preciptotal"]))
        #train["stnpressure"] =  train["stnpressure"]/(max(train["stnpressure"])-min(train["stnpressure"]))
        #train["sealevel"]    =  train["sealevel"]/(max(train["sealevel"])-min(train["sealevel"]))
        #train["resultdir"]   =  train["resultdir"]/(max(train["resultdir"])-min(train["resultdir"]))
        #train["avgspeed"]    =  train["avgspeed"]/(max(train["avgspeed"])-min(train["avgspeed"]))

        #train["tavg_c_to"]			 =   train["tavg_c_to"]/(max(train["tavg_c_to"])-min(train["tavg_c_to"]))
        #train["tavg_c_from"]         =   train["tavg_c_from"]/(max(train["tavg_c_from"])-min(train["tavg_c_from"]))
        #train["wetbulb_c_to"]        =   train["wetbulb_c_to"]/(max(train["wetbulb_c_to"])-min(train["wetbulb_c_to"]))
        #train["wetbulb_c_from"]      =   train["wetbulb_c_from"]/(max(train["wetbulb_c_from"])-min(train["wetbulb_c_to"]))
        #train["dewpoint_c_to"]       =   train["dewpoint_c_to"]/(max(train["dewpoint_c_to"])-min(train["dewpoint_c_from"]))
        #train["dewpoint_c_from"]     =   train["dewpoint_c_from"]/(max(train["dewpoint_c_from"])-min(train["dewpoint_c_from"]))
        #train["snowfall_c_to"]       =   train["snowfall_c_to"]/(max(train["snowfall_c_to"])-min(train["snowfall_c_to"]))
        #train["snowfall_c_from"]     =   train["snowfall_c_from"]/(max(train["snowfall_c_from"])-min(train["snowfall_c_from"]))
        #train["preciptotal_c_to"]    =   train["preciptotal_c_to"]/(max(train["preciptotal_c_to"])-min(train["preciptotal_c_to"]))
        #train["preciptotal_c_from"]  =   train["preciptotal_c_from"]/(max(train["preciptotal_c_from"])-min(train["preciptotal_c_from"]))

        #train = train.drop(["item_nbr","units", "date",
        #                        "GR","SG","GS","PL","FU","DU",
        #                    "SS", "SQ", "MI", "PR", "BC", "BL"],axis=1)

        train = train.drop(["item_nbr","units", "date", "tavg_c_from", "BR", "station_nbr",
                            "FG", "GR", "RA", "tavg", "BC", "MI",
                            "TS", "SQ", "day", "FG.", "SS"],axis=1)

        #train = transformer.fit_transform(train).toarray()
        
        test = pd.DataFrame(data_tst.loc[data_tst.item_nbr == item,:])
        test_id = test.id.values

        test["wkday"] = map(lambda x: datetime.strptime(x,"%Y-%m-%d").weekday(), test["date"])
        test.loc[test.wkday > 4,:]["wkday"] = "W"
        test.loc[test.wkday <= 4,:]["wkday"] = "H"
        test["wkday"] = test["wkday"].astype('category')
        
        test.loc[test.day < 0,"day"] = test.loc[test.day < 0,"day"] + 7
        test.loc[test.day == 0,"day"] = 7
        test.loc[test.day < 4,"day"] = abs(test.loc[test.day < 4,"day"] - 7) 

        test["store_nbr"] = test["store_nbr"].astype('category')
        test["station_nbr"] = test["station_nbr"].astype('category')
        
        test["TS"] = test["TS"].astype('category')
        test["RA"] = test["RA"].astype('category')
        test["DZ"] = test["DZ"].astype('category')
        test["SN"] = test["SN"].astype('category')
        test["FG"] = test["FG"].astype('category')
        test["FG."] = test["FG."].astype('category')
        test["BR"] = test["BR"].astype('category')
        test["HZ"] = test["HZ"].astype('category')
        test["FZ"] = test["FZ"].astype('category')

        test["GR"] = test["GR"].astype('category')
        test["SG"] = test["SG"].astype('category')
        test["GS"] = test["GS"].astype('category')
        test["PL"] = test["PL"].astype('category')
        test["FU"] = test["FU"].astype('category')
        test["DU"] = test["DU"].astype('category')
        test["SS"] = test["SS"].astype('category')
        test["SQ"] = test["SQ"].astype('category')
        test["MI"] = test["MI"].astype('category')
        test["PR"] = test["PR"].astype('category')
        test["BC"] = test["BC"].astype('category')
        test["BL"] = test["BL"].astype('category')
        
        #test["tmax"]        =  test["tmax"]/(max(test["tmax"])-min(test["tmin"])) + 3.0/8.0
        #test["tmin"]        =  test["tmin"]/(max(test["tmin"])-min(test["tmin"])) + 3.0/8.0
        #test["tavg"]        =  test["tavg"]/(max(test["tavg"])-min(test["tavg"])) + 3.0/8.0
        #test["dewpoint"]    =  test["dewpoint"]/(max(test["dewpoint"])-min(test["dewpoint"])) + 3.0/8.0
        #test["wetbulb"]     =  test["wetbulb"]/(max(test["wetbulb"])-min(test["wetbulb"])) + 3.0/8.0
        #test["snowfall"]    =  test["snowfall"]/(max(test["snowfall"])-min(test["snowfall"])) + 3.0/8.0
        #test["preciptotal"] =  test["preciptotal"]/(max(test["preciptotal"])-min(test["preciptotal"])) + 3.0/8.0
        #test["stnpressure"] =  test["stnpressure"]/(max(test["stnpressure"])-min(test["stnpressure"])) + 3.0/8.0
        #test["sealevel"]    =  test["sealevel"]/(max(test["sealevel"])-min(test["sealevel"])) + 3.0/8.0
        #test["resultdir"]   =  test["resultdir"]/(max(test["resultdir"])-min(test["resultdir"])) + 3.0/8.0
        #test["avgspeed"]    =  test["avgspeed"]/(max(test["avgspeed"])-min(test["avgspeed"])) + 3.0/8.0


        #test["tavg_c_to"]		    =   test["tavg_c_to"]/(max(test["tavg_c_to"])-min(test["tavg_c_to"])) + 3.0/8.0
        #test["tavg_c_from"]         =   test["tavg_c_from"]/(max(test["tavg_c_from"])-min(test["tavg_c_from"])) + 3.0/8.0
        #test["wetbulb_c_to"]        =   test["wetbulb_c_to"]/(max(test["wetbulb_c_to"])-min(test["wetbulb_c_to"])) + 3.0/8.0
        #test["wetbulb_c_from"]      =   test["wetbulb_c_from"]/(max(test["wetbulb_c_from"])-min(test["wetbulb_c_to"])) + 3.0/8.0
        #test["dewpoint_c_to"]       =   test["dewpoint_c_to"]/(max(test["dewpoint_c_to"])-min(test["dewpoint_c_from"])) + 3.0/8.0
        #test["dewpoint_c_from"]     =   test["dewpoint_c_from"]/(max(test["dewpoint_c_from"])-min(test["dewpoint_c_from"])) + 3.0/8.0
        #test["snowfall_c_to"]       =   test["snowfall_c_to"]/(max(test["snowfall_c_to"])-min(test["snowfall_c_to"])) + 3.0/8.0
        #test["snowfall_c_from"]     =   test["snowfall_c_from"]/(max(test["snowfall_c_from"])-min(test["snowfall_c_from"])) + 3.0/8.0
        #test["preciptotal_c_to"]    =   test["preciptotal_c_to"]/(max(test["preciptotal_c_to"])-min(test["preciptotal_c_to"])) + 3.0/8.0
        #test["preciptotal_c_from"]  =   test["preciptotal_c_from"]/(max(test["preciptotal_c_from"])-min(test["preciptotal_c_from"])) + 3.0/8.0

        #test = transformer.fit_transform(test).toarray()

        #test = test.drop(["item_nbr","id", "date",
        #                        "GR","SG","GS","PL","FU","DU",
        #                    "SS", "SQ", "MI", "PR", "BC", "BL"],axis=1)

        test = test.drop(["item_nbr", "id", "date", "tavg_c_from", "BR", "station_nbr",
                            "FG", "GR", "RA", "tavg", "BC", "MI",
                            "TS", "SQ", "day", "FG.", "SS"],axis=1)


        #train = gl.SFrame(train)
        #test = gl.SFrame(test)

        ## Let's train the model,.. This model will be trained for each item
        #model = gl.boosted_trees_regression.create(train,target='units',max_iterations=400,max_depth=8,
        #                                            step_size=.025,min_loss_reduction=1)

        model = lm.LinearRegression(fit_intercept=True, normalize=True)
        ##model = RandomForestRegressor(n_estimators=800, max_depth=7)
        model.fit(train,units)
        output = model.predict(test)
        output = np.array(map((lambda x: round(output[x])), range(len(output))))

        #for i in range(1,5):
        #    model2 = RandomForestRegressor(n_estimators=int(400 + i*.5*10), max_depth=8)
        #    model.fit(train,units)
        #    output = output + np.array(model.predict(test))

        #output = (output/5.0).round()


        #model2 = RandomForestRegressor(n_estimators=600, max_depth=6)
        #model2.fit(train,units)
        #output2 = np.array(model2.predict(test))

        #model3 = AdaBoostRegressor(n_estimators=400, learning_rate=0.01)
        #model3.fit(train,units)
        #output3 = np.array(model3.predict(test))

        #output = np.mean([output1,output2,output3],axis=0).round()

        logger.info("Completed Training")
        output = output.clip(0)

        out = pd.DataFrame()
        out["id"] = test_id
        out["units"] = output
        pred = pred.append(out,ignore_index=True)
        del(out)

    pred.columns = ["id","units"]
    pred.to_csv("results.csv",index=False)

if __name__ == "__main__":
    trainModel("none")