costals<-function(lamda,alpha) {
    
  ##This is the next interation code for the logistic regression using local code to 
  ##to minimize 
  ##the regularized cost function
  
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_g<-ld[good,][,]
  
  data<-matrix(nrow=nrow(ld_g),ncol=1)
  df<-data.frame(data)
  
  df[,1]<-1
  df[,2]<-ld_g$shopping_pt
  df[,3]<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df[,4]<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df[,5]<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df[,6]<-((as.numeric(ld_g$location) - mean(as.numeric(ld_g$location)))/(max(as.numeric(ld_g$location))-min(as.numeric(ld_g$location))))
  df[,7]<-as.numeric(ld_g$group_size)
  df[,8]<-as.numeric(ld_g$homeowner)
  df[,9]<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df[,10]<-((as.numeric(ld_g$car_value) - mean(as.numeric(ld_g$car_value)))/(max(as.numeric(ld_g$car_value))-min(as.numeric(ld_g$car_value))))
  df[,11]<-as.numeric(ld_g$risk_factor)
  df[,12]<-((as.numeric(ld_g$age_oldest) - mean(as.numeric(ld_g$age_oldest)))/(max(as.numeric(ld_g$age_oldest))-min(as.numeric(ld_g$age_oldest))))
  df[,13]<-((as.numeric(ld_g$age_youngest) - mean(as.numeric(ld_g$age_youngest)))/(max(as.numeric(ld_g$age_youngest))-min(as.numeric(ld_g$age_youngest))))
  df[,14]<-as.numeric(ld_g$married_couple)
  df[,15]<-as.numeric(ld_g$C_previous)
  df[,16]<-as.numeric(ld_g$A)
  df[,17]<-as.numeric(ld_g$B)
  df[,18]<-as.numeric(ld_g$C)
  df[,19]<-as.numeric(ld_g$D)
  df[,20]<-as.numeric(ld_g$E)
  df[,21]<-as.numeric(ld_g[,23])
  df[,22]<-as.numeric(ld_g$G)
  df[,23]<-as.numeric(ld_g$cost)
  df[,24]<-((as.numeric(ld_g$duration_previous) - mean(as.numeric(ld_g$duration_previous)))/(max(as.numeric(ld_g$duration_previous))-min(as.numeric(ld_g$duration_previous))))
    
  df<-as.matrix(df)
  
  set.seed(2233)
  theta<-matrix(rbind(rnorm(24,mean=1,sd=1)))
  
 
  m<-nrow(df)
  J<-rep(0)
  
  
  for (i in 1:100) {
    J[i]<- -(1/m)*(sum(y*log(1/(1+exp(-df%*%theta))) + (1-y)*(1-log(1/(1+exp(-df%*%theta)))))) + (lamda/(2*m))*sum(theta[2:23]^2)
    
    t1<-theta[1] - (alpha/m)*(t(df[,1])%*%(log(1/(1+exp(-df%*%theta)))-y))
    t2<-theta[2] - (alpha/m)*((t(df[,2])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[2])
    t3<-theta[3] - (alpha/m)*((t(df[,3])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[3])
    t4<-theta[4] - (alpha/m)*((t(df[,4])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[4])
    t5<-theta[5] - (alpha/m)*((t(df[,5])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[5])
    t6<-theta[6] - (alpha/m)*((t(df[,6])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[6])
    t7<-theta[7] - (alpha/m)*((t(df[,7])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[7])
    t8<-theta[8] - (alpha/m)*((t(df[,8])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[8])
    t9<-theta[9] - (alpha/m)*((t(df[,9])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[9])
    t10<-theta[10] - (alpha/m)*((t(df[,10])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[10])
    t11<-theta[11] - (alpha/m)*((t(df[,11])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[11])
    t12<-theta[12] - (alpha/m)*((t(df[,12])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[12])
    t13<-theta[13] - (alpha/m)*((t(df[,13])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[13])
    t14<-theta[14] - (alpha/m)*((t(df[,14])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[14])
    t15<-theta[15] - (alpha/m)*((t(df[,15])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[15])
    t16<-theta[16] - (alpha/m)*((t(df[,16])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[16])
    t17<-theta[17] - (alpha/m)*((t(df[,17])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[17])
    t18<-theta[18] - (alpha/m)*((t(df[,18])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[18])
    t19<-theta[19] - (alpha/m)*((t(df[,19])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[19])
    t20<-theta[20] - (alpha/m)*((t(df[,20])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[20])
    t21<-theta[21] - (alpha/m)*((t(df[,21])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[21])
    t22<-theta[22] - (alpha/m)*((t(df[,22])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[22])
    t23<-theta[23] - (alpha/m)*((t(df[,23])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[23])
    t24<-theta[24] - (alpha/m)*((t(df[,24])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda)*theta[24])
    
    theta<-matrix(rbind(t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23,t24))
      
  }
  
  ret<-list(J,theta)
  return(ret)
}
  