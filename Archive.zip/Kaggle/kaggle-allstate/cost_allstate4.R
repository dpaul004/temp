alssvm<-function() {
    
  library(kernlab)
  
  ##This is the next interation code for the logistic regression using SVM to 
  ##to minimize the regularized cost function
  
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_all<-ld[good,][,]
  
  
  set.seed(2335)
  ti<-rbinom(nrow(ld_all),size=1,prob=0.7)
  
  ld_g<-data.frame(ld_all[ti==1,])
  ld_tst<-data.frame(ld_all[ti==0,])
  
  df<-data.frame(matrix(nrow=nrow(ld_g),ncol=1))
  
  df$dur_prev<-((as.numeric(ld_g$duration_previous) - mean(as.numeric(ld_g$duration_previous)))/(max(as.numeric(ld_g$duration_previous))-min(as.numeric(ld_g$duration_previous))))
  df$shop_pt<-((as.numeric(ld_g$shopping_pt) - mean(as.numeric(ld_g$shopping_pt)))/(max(as.numeric(ld_g$shopping_pt))-min(as.numeric(ld_g$shopping_pt))))
  df$day<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df$time<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df$state<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df$hmownr<-as.numeric(ld_g$homeowner)
  df$car_age<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df$rsk_fac<-((as.numeric(ld_g$risk_factor) - mean(as.numeric(ld_g$risk_factor)))/(max(as.numeric(ld_g$risk_factor))-min(as.numeric(ld_g$risk_factor))))
  df$mar_cple<-as.numeric(ld_g$married_couple)
  df$c_prev<-((as.numeric(ld_g$C_previous) - mean(as.numeric(ld_g$C_previous)))/(max(as.numeric(ld_g$C_previous))-min(as.numeric(ld_g$C_previous))))
  df$A<-as.numeric(ld_g$A)
  df$B<-as.numeric(ld_g$B)
  df$C<-((as.numeric(ld_g$C) - mean(as.numeric(ld_g$C)))/(max(as.numeric(ld_g$C))-min(as.numeric(ld_g$C))))
  df$D<-((as.numeric(ld_g$D) - mean(as.numeric(ld_g$D)))/(max(as.numeric(ld_g$D))-min(as.numeric(ld_g$D))))
  df$E<-as.numeric(ld_g$E)
  df$F1<-((as.numeric(ld_g[,23]) - mean(as.numeric(ld_g[,23])))/(max(as.numeric(ld_g[,23]))-min(as.numeric(ld_g[,23]))))
  df$G<-((as.numeric(ld_g$G) - mean(as.numeric(ld_g$G)))/(max(as.numeric(ld_g$G))-min(as.numeric(ld_g$G))))
  df$cost<-((as.numeric(ld_g$cost) - mean(as.numeric(ld_g$cost)))/(max(as.numeric(ld_g$cost))-min(as.numeric(ld_g$cost))))
  df$shop_pt_time<-df$shop_pt * df$time

  y_tr<-(ld_g$record_type)
  x_tr<-as.matrix(df[,2:20])

  df_t<-data.frame(matrix(nrow=nrow(ld_tst),ncol=1))
  
  df_t$dur_prev<-((as.numeric(ld_tst$duration_previous) - mean(as.numeric(ld_tst$duration_previous)))/(max(as.numeric(ld_tst$duration_previous))-min(as.numeric(ld_tst$duration_previous))))
  df_t$shop_pt<-((as.numeric(ld_tst$shopping_pt) - mean(as.numeric(ld_tst$shopping_pt)))/(max(as.numeric(ld_tst$shopping_pt))-min(as.numeric(ld_tst$shopping_pt))))
  df_t$day<-((as.numeric(ld_tst$day) - mean(as.numeric(ld_tst$day)))/(max(as.numeric(ld_tst$day))-min(as.numeric(ld_tst$day))))
  df_t$time<-((as.numeric(ld_tst$time) - mean(as.numeric(ld_tst$time)))/(max(as.numeric(ld_tst$time))-min(as.numeric(ld_tst$time))))
  df_t$state<-((as.numeric(ld_tst$state) - mean(as.numeric(ld_tst$state)))/(max(as.numeric(ld_tst$state))-min(as.numeric(ld_tst$state))))
  df_t$hmownr<-as.numeric(ld_tst$homeowner)
  df_t$car_age<-((as.numeric(ld_tst$car_age) - mean(as.numeric(ld_tst$car_age)))/(max(as.numeric(ld_tst$car_age))-min(as.numeric(ld_tst$car_age))))
  df_t$rsk_fac<-((as.numeric(ld_tst$risk_factor) - mean(as.numeric(ld_tst$risk_factor)))/(max(as.numeric(ld_tst$risk_factor))-min(as.numeric(ld_tst$risk_factor))))
  df_t$mar_cple<-as.numeric(ld_tst$married_couple)
  df_t$c_prev<-((as.numeric(ld_tst$C_previous) - mean(as.numeric(ld_tst$C_previous)))/(max(as.numeric(ld_tst$C_previous))-min(as.numeric(ld_tst$C_previous))))
  df_t$A<-as.numeric(ld_tst$A)
  df_t$B<-as.numeric(ld_tst$B)
  df_t$C<-((as.numeric(ld_tst$C) - mean(as.numeric(ld_tst$C)))/(max(as.numeric(ld_tst$C))-min(as.numeric(ld_tst$C))))
  df_t$D<-((as.numeric(ld_tst$D) - mean(as.numeric(ld_tst$D)))/(max(as.numeric(ld_tst$D))-min(as.numeric(ld_tst$D))))
  df_t$E<-as.numeric(ld_tst$E)
  df_t$F1<-((as.numeric(ld_tst[,23]) - mean(as.numeric(ld_tst[,23])))/(max(as.numeric(ld_tst[,23]))-min(as.numeric(ld_tst[,23]))))
  df_t$G<-((as.numeric(ld_tst$G) - mean(as.numeric(ld_tst$G)))/(max(as.numeric(ld_tst$G))-min(as.numeric(ld_tst$G))))
  df_t$cost<-((as.numeric(ld_tst$cost) - mean(as.numeric(ld_tst$cost)))/(max(as.numeric(ld_tst$cost))-min(as.numeric(ld_tst$cost))))
  df_t$shop_pt_time<-df_t$shop_pt * df_t$time
  
##  df_t<-as.matrix(df_t)
  y_tst<-(ld_tst$record_type)
  x_tst<-as.matrix(df_t[,2:20])
    
  c_val<-2^7  
  j_tst_err<-vector()
  j_true_1<-vector()
  df_svm<-list()

  for (i in 1:length(c_val)) {
  
      df_svm[i]<-ksvm(x_tr, y_tr, type="C-svc",kernel='vanilladot',C=c_val[i],scaled=c())
    
      j_tst<-predict(df_svm[[i]],x_tst)
    
      x_m<-as.matrix(as.vector(j_tst))
      y_m<-as.matrix(y_tst)
    
      j_tst_err[i]<-sum((j_tst - y_tst)^2)/length(y_tst)
      j_true_1[i]<-(table((x_m == 1) & (y_m == 1) & (x_m == y_m))[2])/table(y_m==1)[2]
  }

  ret<-list(df_svm, c_val, j_tst_err, j_true_1)
  return(ret)
}
  