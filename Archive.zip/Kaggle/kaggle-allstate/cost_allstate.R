costals<-function(lamda) {
  
##This is the original code for the logistic regression using OPTIM to minimize 
##the regularized cost function
    
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_g<-ld[good,][,]
  
  data<-matrix(nrow=nrow(ld_g),ncol=1)
  df<-data.frame(data)
  
  df[,1]<-1
  df[,2]<-ld_g$shopping_pt
  df[,3]<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df[,4]<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df[,5]<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df[,6]<-((as.numeric(ld_g$location) - mean(as.numeric(ld_g$location)))/(max(as.numeric(ld_g$location))-min(as.numeric(ld_g$location))))
  df[,7]<-as.numeric(ld_g$group_size)
  df[,8]<-as.numeric(ld_g$homeowner)
  df[,9]<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df[,10]<-((as.numeric(ld_g$car_value) - mean(as.numeric(ld_g$car_value)))/(max(as.numeric(ld_g$car_value))-min(as.numeric(ld_g$car_value))))
  df[,11]<-as.numeric(ld_g$risk_factor)
  df[,12]<-((as.numeric(ld_g$age_oldest) - mean(as.numeric(ld_g$age_oldest)))/(max(as.numeric(ld_g$age_oldest))-min(as.numeric(ld_g$age_oldest))))
  df[,13]<-((as.numeric(ld_g$age_youngest) - mean(as.numeric(ld_g$age_youngest)))/(max(as.numeric(ld_g$age_youngest))-min(as.numeric(ld_g$age_youngest))))
  df[,14]<-as.numeric(ld_g$married_couple)
  df[,15]<-as.numeric(ld_g$C_previous)
  df[,16]<-as.numeric(ld_g$A)
  df[,17]<-as.numeric(ld_g$B)
  df[,18]<-as.numeric(ld_g$C)
  df[,19]<-as.numeric(ld_g$D)
  df[,20]<-as.numeric(ld_g$E)
  df[,21]<-as.numeric(ld_g[,23])
  df[,22]<-as.numeric(ld_g$G)
  df[,23]<-as.numeric(ld_g$cost)
  df[,24]<-((as.numeric(ld_g$duration_previous) - mean(as.numeric(ld_g$duration_previous)))/(max(as.numeric(ld_g$duration_previous))-min(as.numeric(ld_g$duration_previous))))
    
  df<-as.matrix(df)
  
  set.seed(2233)
  theta<-matrix(rbind(rnorm(24,mean=1,sd=1)))
  
  y<-cbind(ld_g$record_type)
  
  m<-nrow(df)
  
  fn<-function(theta) {
        
    -(1/m)*(sum(y*log(1/(1+exp(-df%*%theta))) + (1-y)*(1-log(1/(1+exp(-df%*%theta)))))) + (lamda/(2*m))*sum(theta[2:23]^2)
  }
  
  grad<-function(theta) {
          
    t1<-(1/m)*(t(df[,1])%*%(log(1/(1+exp(-df%*%theta)))-y))
    t2<-(1/m)*(t(df[,2])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[2]
    t3<-(1/m)*(t(df[,3])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[3]
    t4<-(1/m)*(t(df[,4])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[4]
    t5<-(1/m)*(t(df[,5])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[5]
    t6<-(1/m)*(t(df[,6])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[6]
    t7<-(1/m)*(t(df[,7])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[7]
    t8<-(1/m)*(t(df[,8])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[8]
    t9<-(1/m)*(t(df[,9])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[9]
    t10<-(1/m)*(t(df[,10])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[10]
    t11<-(1/m)*(t(df[,11])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[11]
    t12<-(1/m)*(t(df[,12])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[12]
    t13<-(1/m)*(t(df[,13])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[13]
    t14<-(1/m)*(t(df[,14])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[14]
    t15<-(1/m)*(t(df[,15])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[15]
    t16<-(1/m)*(t(df[,16])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[16]
    t17<-(1/m)*(t(df[,17])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[17]
    t18<-(1/m)*(t(df[,18])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[18]
    t19<-(1/m)*(t(df[,19])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[19]
    t20<-(1/m)*(t(df[,20])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[20]
    t21<-(1/m)*(t(df[,21])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[21]
    t22<-(1/m)*(t(df[,22])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[22]
    t23<-(1/m)*(t(df[,23])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[23]
    t24<-(1/m)*(t(df[,24])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[24]
    matrix(rbind(t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23,t24))
  }
  
  result<- optim(theta, fn, grad, method="BFGS", control=list(maxit=2000))
  return(result)
}
  