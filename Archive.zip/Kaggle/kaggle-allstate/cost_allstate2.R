alsglm<-function(cutoff) {
    
  ##This is the next interation code for the logistic regression using GLM to 
  ##to minimize 
  ##the regularized cost function
  
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_all<-ld[good,][,]
  
  
  set.seed(2335)
  ti<-rbinom(nrow(ld_all),size=1,prob=0.7)
  
  ld_g<-data.frame(ld_all[ti==1,])
  ld_tst<-data.frame(ld_all[ti==0,])
  
  df<-data.frame(matrix(nrow=nrow(ld_g),ncol=1))
  
  df[,1]<-((as.numeric(ld_g$duration_previous) - mean(as.numeric(ld_g$duration_previous)))/(max(as.numeric(ld_g$duration_previous))-min(as.numeric(ld_g$duration_previous))))
  df[,2]<-ld_g$shopping_pt
  df[,3]<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df[,4]<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df[,5]<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df[,6]<-((as.numeric(ld_g$location) - mean(as.numeric(ld_g$location)))/(max(as.numeric(ld_g$location))-min(as.numeric(ld_g$location))))
  df[,7]<-as.numeric(ld_g$group_size)
  df[,8]<-as.numeric(ld_g$homeowner)
  df[,9]<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df[,10]<-((as.numeric(ld_g$car_value) - mean(as.numeric(ld_g$car_value)))/(max(as.numeric(ld_g$car_value))-min(as.numeric(ld_g$car_value))))
  df[,11]<-as.numeric(ld_g$risk_factor)
  df[,12]<-((as.numeric(ld_g$age_oldest) - mean(as.numeric(ld_g$age_oldest)))/(max(as.numeric(ld_g$age_oldest))-min(as.numeric(ld_g$age_oldest))))
  df[,13]<-((as.numeric(ld_g$age_youngest) - mean(as.numeric(ld_g$age_youngest)))/(max(as.numeric(ld_g$age_youngest))-min(as.numeric(ld_g$age_youngest))))
  df[,14]<-as.numeric(ld_g$married_couple)
  df[,15]<-as.numeric(ld_g$C_previous)
  df[,16]<-as.numeric(ld_g$A)
  df[,17]<-as.numeric(ld_g$B)
  df[,18]<-as.numeric(ld_g$C)
  df[,19]<-as.numeric(ld_g$D)
  df[,20]<-as.numeric(ld_g$E)
  df[,21]<-as.numeric(ld_g[,23])
  df[,22]<-as.numeric(ld_g$G)
  df[,23]<-as.numeric(ld_g$cost)

  df<-as.matrix(df)
  y_tr<-cbind(ld_g$record_type)

  df_t<-data.frame(matrix(nrow=nrow(ld_tst),ncol=1))
  
  df_t[,1]<-((as.numeric(ld_tst$duration_previous) - mean(as.numeric(ld_tst$duration_previous)))/(max(as.numeric(ld_tst$duration_previous))-min(as.numeric(ld_tst$duration_previous))))
  df_t[,2]<-ld_tst$shopping_pt
  df_t[,3]<-((as.numeric(ld_tst$day) - mean(as.numeric(ld_tst$day)))/(max(as.numeric(ld_tst$day))-min(as.numeric(ld_tst$day))))
  df_t[,4]<-((as.numeric(ld_tst$time) - mean(as.numeric(ld_tst$time)))/(max(as.numeric(ld_tst$time))-min(as.numeric(ld_tst$time))))
  df_t[,5]<-((as.numeric(ld_tst$state) - mean(as.numeric(ld_tst$state)))/(max(as.numeric(ld_tst$state))-min(as.numeric(ld_tst$state))))
  df_t[,6]<-((as.numeric(ld_tst$location) - mean(as.numeric(ld_tst$location)))/(max(as.numeric(ld_tst$location))-min(as.numeric(ld_tst$location))))
  df_t[,7]<-as.numeric(ld_tst$group_size)
  df_t[,8]<-as.numeric(ld_tst$homeowner)
  df_t[,9]<-((as.numeric(ld_tst$car_age) - mean(as.numeric(ld_tst$car_age)))/(max(as.numeric(ld_tst$car_age))-min(as.numeric(ld_tst$car_age))))
  df_t[,10]<-((as.numeric(ld_tst$car_value) - mean(as.numeric(ld_tst$car_value)))/(max(as.numeric(ld_tst$car_value))-min(as.numeric(ld_tst$car_value))))
  df_t[,11]<-as.numeric(ld_tst$risk_factor)
  df_t[,12]<-((as.numeric(ld_tst$age_oldest) - mean(as.numeric(ld_tst$age_oldest)))/(max(as.numeric(ld_tst$age_oldest))-min(as.numeric(ld_tst$age_oldest))))
  df_t[,13]<-((as.numeric(ld_tst$age_youngest) - mean(as.numeric(ld_tst$age_youngest)))/(max(as.numeric(ld_tst$age_youngest))-min(as.numeric(ld_tst$age_youngest))))
  df_t[,14]<-as.numeric(ld_tst$married_couple)
  df_t[,15]<-as.numeric(ld_tst$C_previous)
  df_t[,16]<-as.numeric(ld_tst$A)
  df_t[,17]<-as.numeric(ld_tst$B)
  df_t[,18]<-as.numeric(ld_tst$C)
  df_t[,19]<-as.numeric(ld_tst$D)
  df_t[,20]<-as.numeric(ld_tst$E)
  df_t[,21]<-as.numeric(ld_tst[,23])
  df_t[,22]<-as.numeric(ld_tst$G)
  df_t[,23]<-as.numeric(ld_tst$cost)
  
  df_t<-as.matrix(df_t)
  y_tst<-(ld_tst$record_type)
    
  df_glm<-glm(y_tr ~ df, family=binomial)
  
  j_tr<-(predict(df_glm,newdata=data.frame(df),type="response"))
  j_tr_1 <- j_tr > cutoff
  j_tr[j_tr_1 == T]<-1
  j_tr[j_tr_1 == F]<-0
    
  j_tr_err<-sum((j_tr - y_tr)^2)/length(y_tr)
  
  j_tst<-(predict(df_glm,newdata=data.frame(df_t),na.action=na.omit, type="response"))
  
  j_tst<-j_tst[1:length(y_tst)]
  j_tst_1 <- j_tst > cutoff
  j_tst[j_tst_1 == T]<-1
  j_tst[j_tst_1 == F]<-0
  
  x_m<-as.matrix(as.vector(j_tst))
  y_m<-as.matrix(y_tst)
  
  j_tst_err<-sum((j_tst - y_tst)^2)/length(y_tst)
  j_true_1<-(table((x_m == 1) & (y_m == 1) & (x_m == y_m))[2])/table(y_m==1)[2]
  
  ret<-list(df_glm, j_tr_err, j_tst_err, j_true_1)
  return(ret)
}
  