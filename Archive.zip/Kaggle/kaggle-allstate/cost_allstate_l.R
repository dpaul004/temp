costals<-function(lamda) {
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_all<-ld[good,][,]
  
  set.seed(2335)
  ti<-rbinom(nrow(ld_all),size=1,prob=0.7)
  ld_g<-data.frame(ld_all[ti==1,])
  
  ld_t<-data.frame(ld_all[ti==0,])
  
  data<-matrix(nrow=nrow(ld_g),ncol=1)
  df<-data.frame(data)
  
  df[,1]<-1
  df[,2]<-ld_g$shopping_pt
  df[,3]<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df[,4]<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df[,4]<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df[,5]<-((as.numeric(ld_g$location) - mean(as.numeric(ld_g$location)))/(max(as.numeric(ld_g$location))-min(as.numeric(ld_g$location))))
  df[,6]<-as.numeric(ld_g$group_size)
  df[,7]<-as.numeric(ld_g$homeowner)
  df[,8]<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df[,9]<-as.numeric(ld_g$car_value)
  df[,10]<-as.numeric(ld_g$risk_factor)
  df[,11]<-((as.numeric(ld_g$age_oldest) - mean(as.numeric(ld_g$age_oldest)))/(max(as.numeric(ld_g$age_oldest))-min(as.numeric(ld_g$age_oldest))))
  df[,12]<-((as.numeric(ld_g$age_youngest) - mean(as.numeric(ld_g$age_youngest)))/(max(as.numeric(ld_g$age_youngest))-min(as.numeric(ld_g$age_youngest))))
  df[,13]<-as.numeric(ld_g$married_couple)
  df[,14]<-as.numeric(ld_g$C_previous)
  df[,15]<-as.numeric(ld_g$A)
  df[,16]<-as.numeric(ld_g$B)
  df[,17]<-as.numeric(ld_g$C)
  df[,18]<-as.numeric(ld_g$D)
  df[,19]<-as.numeric(ld_g$E)
  df[,20]<-as.numeric(ld_g[,23])
  df[,21]<-as.numeric(ld_g$G)
  df[,22]<-as.numeric(ld_g$cost)
  df[,23]<-ld_g$shopping_pt
  
  df<-as.matrix(df)
  
  theta<-matrix(rbind(rep(1,23)))
  
  y<-cbind(ld_g$record_type)
  
  m<-nrow(df)
  
  fn<-function(theta) {
        
    -(1/m)*(sum(y*log(1/(1+exp(-df%*%theta))) + (1-y)*(1-log(1/(1+exp(-df%*%theta)))))) + (lamda/(2*m))*sum(theta[2:23]^2)
  }
  
  grad<-function(theta) {
          
    t1<-(1/m)*(t(df[,1])%*%(log(1/(1+exp(-df%*%theta)))-y))
    t2<-(1/m)*(t(df[,2])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[2]
    t3<-(1/m)*(t(df[,3])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[3]
    t4<-(1/m)*(t(df[,4])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[4]
    t5<-(1/m)*(t(df[,5])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[5]
    t6<-(1/m)*(t(df[,6])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[6]
    t7<-(1/m)*(t(df[,7])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[7]
    t8<-(1/m)*(t(df[,8])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[8]
    t9<-(1/m)*(t(df[,9])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[9]
    t10<-(1/m)*(t(df[,10])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[10]
    t11<-(1/m)*(t(df[,11])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[11]
    t12<-(1/m)*(t(df[,12])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[12]
    t13<-(1/m)*(t(df[,13])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[13]
    t14<-(1/m)*(t(df[,14])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[14]
    t15<-(1/m)*(t(df[,15])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[15]
    t16<-(1/m)*(t(df[,16])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[16]
    t17<-(1/m)*(t(df[,17])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[17]
    t18<-(1/m)*(t(df[,18])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[18]
    t19<-(1/m)*(t(df[,19])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[19]
    t20<-(1/m)*(t(df[,20])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[20]
    t21<-(1/m)*(t(df[,21])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[21]
    t22<-(1/m)*(t(df[,22])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[22]
    t23<-(1/m)*(t(df[,23])%*%(log(1/(1+exp(-df%*%theta)))-y)) -(lamda/m)*theta[23]
    
    matrix(rbind(t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23))
  }
  
  result<- optim(theta, fn, grad, control=list(maxit=5000))
  
  theta<-result$par
  
  data_t<-matrix(nrow=nrow(ld_t),ncol=1)
  df_t<-data.frame(data_t)
  
  
  df_t[,1]<-1
  df_t[,2]<-ld_t$shopping_pt
  df_t[,3]<-((as.numeric(ld_t$day) - mean(as.numeric(ld_t$day)))/(max(as.numeric(ld_t$day))-min(as.numeric(ld_t$day))))
  df_t[,4]<-((as.numeric(ld_t$time) - mean(as.numeric(ld_t$time)))/(max(as.numeric(ld_t$time))-min(as.numeric(ld_t$time))))
  df_t[,4]<-((as.numeric(ld_t$state) - mean(as.numeric(ld_t$state)))/(max(as.numeric(ld_t$state))-min(as.numeric(ld_t$state))))
  df_t[,5]<-((as.numeric(ld_t$location) - mean(as.numeric(ld_t$location)))/(max(as.numeric(ld_t$location))-min(as.numeric(ld_t$location))))
  df_t[,6]<-as.numeric(ld_t$group_size)
  df_t[,7]<-as.numeric(ld_t$homeowner)
  df_t[,8]<-((as.numeric(ld_t$car_age) - mean(as.numeric(ld_t$car_age)))/(max(as.numeric(ld_t$car_age))-min(as.numeric(ld_t$car_age))))
  df_t[,9]<-as.numeric(ld_t$car_value)
  df_t[,10]<-as.numeric(ld_t$risk_factor)
  df_t[,11]<-((as.numeric(ld_t$age_oldest) - mean(as.numeric(ld_t$age_oldest)))/(max(as.numeric(ld_t$age_oldest))-min(as.numeric(ld_t$age_oldest))))
  df_t[,12]<-((as.numeric(ld_t$age_youngest) - mean(as.numeric(ld_t$age_youngest)))/(max(as.numeric(ld_t$age_youngest))-min(as.numeric(ld_t$age_youngest))))
  df_t[,13]<-as.numeric(ld_t$married_couple)
  df_t[,14]<-as.numeric(ld_t$C_previous)
  df_t[,15]<-as.numeric(ld_t$A)
  df_t[,16]<-as.numeric(ld_t$B)
  df_t[,17]<-as.numeric(ld_t$C)
  df_t[,18]<-as.numeric(ld_t$D)
  df_t[,19]<-as.numeric(ld_t$E)
  df_t[,20]<-as.numeric(ld_t[,23])
  df_t[,21]<-as.numeric(ld_t$G)
  df_t[,22]<-as.numeric(ld_t$cost)
  df_t[,23]<-ld_t$shopping_pt
  
  df_t<-as.matrix(df_t)
  y_t<-cbind(ld_t$record_type)
  
  Jtrain<-
  
  
  
  return(result)
}
  