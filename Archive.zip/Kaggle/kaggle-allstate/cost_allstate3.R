alsglm<-function(cutoff) {
    
  ##This is the next interation code for the logistic regression using GLM to 
  ##to minimize 
  ##the regularized cost function
  
  setwd("~/Kaggle/Allstate")
  ld<-read.csv('train.csv')
  
  good<-complete.cases(ld)
  ld_all<-ld[good,][,]
  
  
  set.seed(2335)
  ti<-rbinom(nrow(ld_all),size=1,prob=0.7)
  
  ld_g<-data.frame(ld_all[ti==1,])
  ld_tst<-data.frame(ld_all[ti==0,])
  
  df<-data.frame(matrix(nrow=nrow(ld_g),ncol=1))
  
  df$dur_prev<-((as.numeric(ld_g$duration_previous) - mean(as.numeric(ld_g$duration_previous)))/(max(as.numeric(ld_g$duration_previous))-min(as.numeric(ld_g$duration_previous))))
  df$shop_pt<-ld_g$shopping_pt
  df$day<-((as.numeric(ld_g$day) - mean(as.numeric(ld_g$day)))/(max(as.numeric(ld_g$day))-min(as.numeric(ld_g$day))))
  df$time<-((as.numeric(ld_g$time) - mean(as.numeric(ld_g$time)))/(max(as.numeric(ld_g$time))-min(as.numeric(ld_g$time))))
  df$state<-((as.numeric(ld_g$state) - mean(as.numeric(ld_g$state)))/(max(as.numeric(ld_g$state))-min(as.numeric(ld_g$state))))
  df$loc<-((as.numeric(ld_g$location) - mean(as.numeric(ld_g$location)))/(max(as.numeric(ld_g$location))-min(as.numeric(ld_g$location))))
  df$grp_sz<-as.numeric(ld_g$group_size)
  df$hmownr<-as.numeric(ld_g$homeowner)
  df$car_age<-((as.numeric(ld_g$car_age) - mean(as.numeric(ld_g$car_age)))/(max(as.numeric(ld_g$car_age))-min(as.numeric(ld_g$car_age))))
  df$car_val<-((as.numeric(ld_g$car_value) - mean(as.numeric(ld_g$car_value)))/(max(as.numeric(ld_g$car_value))-min(as.numeric(ld_g$car_value))))
  df$rsk_fac<-as.numeric(ld_g$risk_factor)
  df$age_oldst<-((as.numeric(ld_g$age_oldest) - mean(as.numeric(ld_g$age_oldest)))/(max(as.numeric(ld_g$age_oldest))-min(as.numeric(ld_g$age_oldest))))
  df$age_yngst<-((as.numeric(ld_g$age_youngest) - mean(as.numeric(ld_g$age_youngest)))/(max(as.numeric(ld_g$age_youngest))-min(as.numeric(ld_g$age_youngest))))
  df$mar_cple<-as.numeric(ld_g$married_couple)
  df$c_prev<-as.numeric(ld_g$C_previous)
  df$A<-as.numeric(ld_g$A)
  df$B<-as.numeric(ld_g$B)
  df$C<-as.numeric(ld_g$C)
  df$D<-as.numeric(ld_g$D)
  df$E<-as.numeric(ld_g$E)
  df$F1<-as.numeric(ld_g[,23])
  df$G<-as.numeric(ld_g$G)
  df$cost<-as.numeric(ld_g$cost)

##  df<-as.matrix(df)
  y_tr<-cbind(ld_g$record_type)

  df_t<-data.frame(matrix(nrow=nrow(ld_tst),ncol=1))
  
  df_t$dur_prev<-((as.numeric(ld_tst$duration_previous) - mean(as.numeric(ld_tst$duration_previous)))/(max(as.numeric(ld_tst$duration_previous))-min(as.numeric(ld_tst$duration_previous))))
  df_t$shop_pt<-ld_tst$shopping_pt
  df_t$day<-((as.numeric(ld_tst$day) - mean(as.numeric(ld_tst$day)))/(max(as.numeric(ld_tst$day))-min(as.numeric(ld_tst$day))))
  df_t$time<-((as.numeric(ld_tst$time) - mean(as.numeric(ld_tst$time)))/(max(as.numeric(ld_tst$time))-min(as.numeric(ld_tst$time))))
  df_t$state<-((as.numeric(ld_tst$state) - mean(as.numeric(ld_tst$state)))/(max(as.numeric(ld_tst$state))-min(as.numeric(ld_tst$state))))
  df_t$loc<-((as.numeric(ld_tst$location) - mean(as.numeric(ld_tst$location)))/(max(as.numeric(ld_tst$location))-min(as.numeric(ld_tst$location))))
  df_t$grp_sz<-as.numeric(ld_tst$group_size)
  df_t$hmownr<-as.numeric(ld_tst$homeowner)
  df_t$car_age<-((as.numeric(ld_tst$car_age) - mean(as.numeric(ld_tst$car_age)))/(max(as.numeric(ld_tst$car_age))-min(as.numeric(ld_tst$car_age))))
  df_t$car_val<-((as.numeric(ld_tst$car_value) - mean(as.numeric(ld_tst$car_value)))/(max(as.numeric(ld_tst$car_value))-min(as.numeric(ld_tst$car_value))))
  df_t$rsk_fac<-as.numeric(ld_tst$risk_factor)
  df_t$age_oldst<-((as.numeric(ld_tst$age_oldest) - mean(as.numeric(ld_tst$age_oldest)))/(max(as.numeric(ld_tst$age_oldest))-min(as.numeric(ld_tst$age_oldest))))
  df_t$age_yngst<-((as.numeric(ld_tst$age_youngest) - mean(as.numeric(ld_tst$age_youngest)))/(max(as.numeric(ld_tst$age_youngest))-min(as.numeric(ld_tst$age_youngest))))
  df_t$mar_cple<-as.numeric(ld_tst$married_couple)
  df_t$c_prev<-as.numeric(ld_tst$C_previous)
  df_t$A<-as.numeric(ld_tst$A)
  df_t$B<-as.numeric(ld_tst$B)
  df_t$C<-as.numeric(ld_tst$C)
  df_t$D<-as.numeric(ld_tst$D)
  df_t$E<-as.numeric(ld_tst$E)
  df_t$F1<-as.numeric(ld_tst[,23])
  df_t$G<-as.numeric(ld_tst$G)
  df_t$cost<-as.numeric(ld_tst$cost)
  
##  df_t<-as.matrix(df_t)
  y_tst<-(ld_tst$record_type)
    
#   df_glm<-glm(y_tr ~ dur_prev + shop_pt + day + time + state + loc + grp_sz
#               + hmownr + car_age + car_val + rsk_fac + age_oldst 
#               + age_yngst + mar_cple + c_prev + A + B + C + D + E + F1
#               + G + cost, data=df, family=binomial)

  df_glm<-glm(y_tr ~ dur_prev + shop_pt + day + time + state 
              + hmownr + car_age + rsk_fac + mar_cple + c_prev 
              + A + B + C + D + E + F1
              + G + cost
              + shop_pt * time, data=df, family=binomial)
  
  j_tr<-(predict(df_glm,newdata=data.frame(df),type="response"))
  j_tr_1 <- j_tr > cutoff
  j_tr[j_tr_1 == T]<-1
  j_tr[j_tr_1 == F]<-0
    
  j_tr_err<-sum((j_tr - y_tr)^2)/length(y_tr)
  
  j_tst<-(predict(df_glm,newdata=data.frame(df_t),na.action=na.omit, type="response"))
  
  j_tst<-j_tst[1:length(y_tst)]
  j_tst_1 <- j_tst > cutoff
  j_tst[j_tst_1 == T]<-1
  j_tst[j_tst_1 == F]<-0
  
  x_m<-as.matrix(as.vector(j_tst))
  y_m<-as.matrix(y_tst)
  
  j_tst_err<-sum((j_tst - y_tst)^2)/length(y_tst)
  j_true_1<-(table((x_m == 1) & (y_m == 1) & (x_m == y_m))[2])/table(y_m==1)[2]
  
  ret<-list(df_glm, j_tr_err, j_tst_err, j_true_1)
  return(ret)
}
  