#!bin/bash

awk -F '","' 'BEGIN {FS=",";OFS=","} {if ($1 < 20) print}' finaldata.csv > testdata.csv
