setwd("~/Documents/Models/Kaggle/Telematics")
library(gbm)
library(randomForest)
library(caret)

dt<-read.csv("finaldata.csv",strip.white=T,header=T)
##dt<-read.csv("testdata.csv",strip.white=T,header=F)

##good<-complete.cases(dt)
##dt[which(good==F),72]<-0

pdata<-split(dt,dt[,1],drop=T)
rm(dt)

sub_gbm<-vector("list",5000)
sub_rf<-vector("list",5000)
##sub_rf1<-vector("list",5000)
sub_comb<-vector("list",5000)

i=1

l<-names(pdata)

for (item in l) {
  
  print(item)
  
  s<-sample(l[l != item],10,replace=F)
  train_item<-pdata[[which(names(pdata)==item)]]
  train_item$y<-1
  
  train_item_oth<-do.call("rbind",pdata[s])
  train_item_oth$y<-0
  
  subset<-rbinom(nrow(train_item_oth),1,0.15)
  train_item_oth<-train_item_oth[subset,][,]
  
  train<-rbind(train_item,train_item_oth)
  optcol<-c(1,2)
  
  gbm1<-gbm(y~.,data=train[,-optcol],distribution="bernoulli",
            keep.data=F,verbose=F,n.cores=2,n.trees=2000,
            shrinkage=0.01,interaction.depth=3,n.minobsinnode = 10)
  
  pred_gbm<-round(predict(gbm1,train_item[,-optcol],type="response",n.trees=2000),4)
  
  rfm<-randomForest(y~.,data=train[,-optcol])
  pred_rfm<-round(predict(rfm,newdata=train_item[,-optcol]),4)
  
##  rfm1<-train(y~.,data=train[,-optcol],method="rf",mtry=5)
##  pred_rfm1<-round(predict(rfm1,newdata=train_item[,-optcol]),4)
  
  pred_comb<-round((pred_gbm/2 + pred_rfm/2),4)  
  
  s<-data.frame(train_item[,1:2])
  s[,3]<-pred_gbm
  s<-s[order(s[,2]),]
  s[,1]<-paste0(s[,1],'_',s[,2])
  s<-s[,-2]  
  sub_gbm[[i]]<-s
  rm(s)
  
  s<-data.frame(train_item[,1:2])
  s[,3]<-pred_rfm
  s<-s[order(s[,2]),]
  s[,1]<-paste0(s[,1],'_',s[,2])
  s<-s[,-2] 
  sub_rf[[i]]<-s
  rm(s)
  
##  s<-data.frame(train_item[,1:2])
##  s[,3]<-pred_rfm1
##  s<-s[order(s[,2]),]
##  s[,1]<-paste0(s[,1],'_',s[,2])
##  s<-s[,-2] 
##  sub_rf1[[i]]<-s
##  rm(s)
  
  s<-data.frame(train_item[,1:2])
  s[,3]<-pred_comb
  s<-s[order(s[,2]),]
  s[,1]<-paste0(s[,1],'_',s[,2])
  s<-s[,-2]
  sub_comb[[i]]<-s
  rm(s)
  i<-i+1
}

sub_gbm<-sub_gbm[1:(i-1)]
submission_gbm<-do.call("rbind",sub_gbm)
names(submission_gbm)<-c("driver_trip","prob")

sub_rf<-sub_rf[1:(i-1)]
submission_rf<-do.call("rbind",sub_rf)
names(submission_rf)<-c("driver_trip","prob")

##sub_rf1<-sub_rf1[1:(i-1)]
##submission_rf1<-do.call("rbind",sub_rf1)
##names(submission_rf1)<-c("driver_trip","prob")

sub_comb<-sub_gbm[1:(i-1)]
submission_comb<-do.call("rbind",sub_comb)
names(submission_comb)<-c("driver_trip","prob")

write.csv(submission_gbm, "/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/submission_gbm.csv", row.names=F, quote=F)
write.csv(submission_rf, "/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/submission_rf.csv", row.names=F, quote=F)
##write.csv(submission_rf1, "/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/submission_rf1.csv", row.names=F, quote=F)
write.csv(submission_comb, "/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/submission_comb.csv", row.names=F, quote=F)
