dataprep<-function(infile,driver) {
  trip<-read.csv(infile,strip.white=T,header=T)
  r<-nrow(trip)
  span<-3
  
  drive<-strsplit(unlist(infile),"[.]")[[1]][1]
  
  trip3<-trip[which(as.integer(rownames(trip))%%span==0),]
  r3<-nrow(trip3)
  
  dr_lm<-lm(y~x,data=trip3)
  dr_lm$coefficients[which(is.na(dr_lm$coefficients))]<-0
  
  int_dis<-sqrt(diff(trip3$x,1,1)^2 + diff(trip3$y,1,1)^2)
  tot_dis<-sum(int_dis)
  air_dis<-(sqrt(diff(trip$x,(r-1),1)^2 + diff(trip$y,(r-1),1)^2))
  tot_stop<-ifelse(is.na(table(int_dis < 0.08)[2]),0,table(int_dis < 0.08)[[2]])
  
  speed<-3.6*sqrt(diff(trip3$x,1,1)^2 + diff(trip3$y,1,1)^2)/span
  speed[which(speed > 120)] <- 120
  speed_dis<-hist(speed,seq(0,120,10),plot=F)$counts
  
  accl<-round(diff(speed,1,1),4)
  accl[which(accl < -30)] <- -30
  accl[which(accl >  30)] <- 30
  accl_dis<-hist(accl,seq(-30,30,5),plot=F)$counts
 
  
  turn<-atan(diff(trip3$y,1,1)/diff(trip3$x,1,1))
  turn<-diff(turn,1,1)
  
  turn_pts<-which(abs(turn) > 2)
  if (length(turn_pts) > 0) {
    turn_pt_med_speed<-median(unlist(lapply(turn_pts, function(x) mean(speed[(ifelse((x-4) < 1,1,(x-4))):x]))))
  } else {
    turn_pt_med_speed<-0
  }
  
  if (sum(is.na(turn)) > 0) {
    turn<-(turn[-which(is.na(turn))])
  }
  turn_dis<-hist(turn,seq(-pi,pi,pi/10),plot=F)$counts
  
  features<-c(driver,drive,turn_dis,speed_dis,accl_dis,tot_dis,tot_stop,air_dis,mean(speed),
              median(speed),max(speed),length(turn_pts),
              turn_pt_med_speed,dr_lm$coefficients[1],dr_lm$coefficients[2])
  
  return(as.numeric(features))
}