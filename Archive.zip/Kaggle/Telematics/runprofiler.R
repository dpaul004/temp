#!/usr/bin/Rscript
## This script will be executed from a scheduled shell script
source('~/Documents/Models/Kaggle/Telematics/RunPathProf.R')
