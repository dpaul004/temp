import pandas as pd
from pandas import DataFrame
import csv
from sklearn import datasets, linear_model
from sklearn.ensemble import RandomForestClassifier
import sys
from numpy import *
import numpy as np
import random
    
def model(mode,forest):
    if (mode=='train'):
        data=(pd.read_csv('testdata.csv',header=-1))
    elif (mode=='test'):
        data=(pd.read_csv('finaldata.csv',header=0))
     
    null_locx=where(data.isnull())
    data.ix[null_locx[0],null_locx[1]]=0   
    
    driver_list=data.ix[:,0].unique()
    
    for item in driver_list:
        data_curr=data[data.ix[:,0]==item]
        data_curr['y']=1
        l=random.sample(driver_list,5)
        
        data_oth=DataFrame(concatenate([data[data.ix[:,0]==i] for i in l],axis=0))
        data_oth['y']=0
        
        data_all=data_curr.append(data_oth)
        data_all=data_all.drop([0,1],axis=1)
        data_v=data_all.values
        
        forest=RandomForestClassifier(n_estimators=100)
        forest=forest.fit(data_v[0::,:71],data_v[0::,71])
        
        ids=data_curr.ix[::,0:1].apply(lambda row: '_'.join(map(str,row)),axis=1)
        data_curr_all=data_curr.drop([0,1,'y'],axis=1)
        data_curr_all_v=data_curr_all.values
        
        output=forest.predict(data_curr_all_v).astype(int)
        
    out_file=open('Titanic_out.csv','wb')
    out_file_obj=csv.writer(out_file)
    out_file_obj.writerow(['PassengerId','Survived'])
    out_file_obj.writerows(zip(ids,output))
    out_file.close()     

##    type(train_X)  
##    size(train_X), gives the total number of elements in an array

##    train_X.size gives total element in the array  
##    train_X.describe() works for DataFrames etc.
  
##    y=np.ravel(train_Y)

    
if __name__ == "__main__":
    print "DL 400 Session 2 Module 1"
    import pandas as pd
    from pandas import DataFrame
    import csv
    from sklearn import datasets, linear_model
    from sklearn.ensemble import RandomForestClassifier
    import sys
    from numpy import *
    import numpy as np
    
	
##    parm = sys.argv[1]
##    mode=parm[0:1]
    forest=model('train',NaN)
    model('test',forest)