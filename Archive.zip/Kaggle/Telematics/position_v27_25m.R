#source("position_v27_25m.R")
library(parallel)
nbCores=detectCores()-1
set.seed(0)

dirInit = ""
m_interp = 25
cap_pos = 10000
  
GetAngle <- function(i, dirPath) 
{
  angle_all=rep(0,1)
  trip = read.csv(paste0(dirPath, i, ".csv"))
  
  coords <- as.data.frame(trip)
  
  distance_df = as.data.frame(
    cbind(c(0,cumsum(sqrt(diff(trip$x,1,1)^2 + diff(trip$y,1,1)^2))),trip$x,trip$y))
  names(distance_df) = c("dist_cumul","x","y")
  
  dist_max = distance_df$dist_cumul[length(distance_df$dist_cumul)]
  xout = seq (0,dist_max,by=m_interp)
  
  if (length(xout) >= 70) 
  {
    x_interp = approx(distance_df$dist_cumul,distance_df$x, xout)
    y_interp = approx(distance_df$dist_cumul,distance_df$y, xout)
    
    trip_interp = as.data.frame(cbind(x_interp$y,y_interp$y))
    names(trip_interp)=c("x","y")
    rhos = sqrt(diff(trip_interp$x,1,1)^2 + diff(trip_interp$y,1,1)^2)
    N = dim(trip_interp)[1]-1
    trajs = cbind(diff(trip_interp$x,1,1),diff(trip_interp$y,1,1))
    trajscal=rowSums(trajs[1:(N-2),]*trajs[3:N,])
    rhos2 = sqrt(rowSums((trajs[1:(N-2),]+trajs[3:N,])^2))
    angle_inst = acos(trajscal / (rhos[1:(N-2)]*rhos[3:N]))
    angle_inst[is.na(angle_inst)]=0
    angle_inst= c(0,angle_inst * (1 + -2 * 
                                    ((diff(trip_interp$y[2:(N+1)],1,1)*diff(trip_interp$x[1:N],1,1) -
                                        diff(trip_interp$x[2:(N+1)],1,1)*diff(trip_interp$y[1:N],1,1) <0))))
    
    angle_inst[angle_inst>pi]=angle_inst[angle_inst>pi]-2*pi
    angle_all = cumsum(abs(angle_inst))
  }
  return = angle_all
}

GetSimilarity <- function(j, angle_all, Ni, anglecumi)
{
  anglecumj = angle_all[[j]]
  Nj = length(anglecumj)
  if (Nj>100) 
  {
    anglecumj=anglecumj[20:(Nj-20)]
    Nj=Nj-40
  }
  N = min(Ni,Nj)
  res_temp = 0
  if (N>70)
  {
    varx_1=0
    varx_2=0
    angleabs = cumsum(abs(diff(anglecumi)))
    angleabsinv = cumsum(abs(diff(anglecumi[Ni:1])))

    Nbis = which(angleabs>(4*pi))
    
    if (length(Nbis)>0)
    {
      if (min(Nbis)<N)
      {
        N = max(min(Nbis),70)
        a1 = var(pmin(anglecumi[1:N]+anglecumj[1:N],
                      anglecumi[1:N]+anglecumj[1:N]+2*pi,
                      anglecumi[1:N]+anglecumj[1:N]-2*pi))
        
        a2 = var(pmin(anglecumi[1:N]-anglecumj[1:N],
                      anglecumi[1:N]-anglecumj[1:N]+2*pi,
                      anglecumi[1:N]-anglecumj[1:N]-2*pi))
        
        a3 = var(pmin(anglecumi[1:N]+anglecumj[Nj:(Nj-N+1)],
                      anglecumi[1:N]+anglecumj[Nj:(Nj-N+1)]+2*pi,
                      anglecumi[1:N]+anglecumj[Nj:(Nj-N+1)]-2*pi))
        
        a4 = var(pmin(anglecumi[1:N]-anglecumj[Nj:(Nj-N+1)],
                      anglecumi[1:N]-anglecumj[Nj:(Nj-N+1)]+2*pi,
                      anglecumi[1:N]-anglecumj[Nj:(Nj-N+1)]-2*pi))
        
        
        varx_1 = var(anglecumi[1:N]) / min(a1,a2,a3,a4)#*sqrt(sqrt(angleabs))
      }
    }
    
    Nbis = which(angleabsinv>(4*pi))
    
    if (length(Nbis)>0)
    {
      if (min(Nbis)<N)
      {
        N = max(min(Nbis),70)
        
        a5 = var(pmin(anglecumi[Ni:(Ni-N+1)]-anglecumj[Nj:(Nj-N+1)],
                      anglecumi[Ni:(Ni-N+1)]-anglecumj[Nj:(Nj-N+1)]+2*pi,
                      anglecumi[Ni:(Ni-N+1)]-anglecumj[Nj:(Nj-N+1)]-2*pi))
        
        a6 = var(pmin(anglecumi[Ni:(Ni-N+1)]+anglecumj[Nj:(Nj-N+1)],
                      anglecumi[Ni:(Ni-N+1)]+anglecumj[Nj:(Nj-N+1)]+2*pi,
                      anglecumi[Ni:(Ni-N+1)]+anglecumj[Nj:(Nj-N+1)]-2*pi))
        
        varx_2 = var(anglecumi[Ni:(Ni-N+1)]) / min(a5,a6)#*sqrt(sqrt(angleabsinv))
      }
    }
    
    if (is.na(varx_1)) varx_1 =0
    if (is.na(varx_2)) varx_2 =0
    res_temp = sqrt(max (varx_1, varx_2))
  }
  return <- res_temp/15
}

drivers = list.files(paste0(dirInit,"drivers/"))

############# TEST PART
randdrivers = drivers
angle_all_test = list()
res_test = matrix(0,length(randdrivers),length(randdrivers))
for(driver in randdrivers)
{
  print (driver)
  dirPath = paste0(
    dirInit, "drivers/", driver, '/')
  angle_all_test = c(angle_all_test,as.data.frame(GetAngle(1, dirPath)))
}
size_test = length(angle_all_test)
for (i in 1:(size_test-1))
{
  print(randdrivers[i])
  anglecumi = angle_all_test[[i]]
  #anglecumabsi = angle_abs_all[[i]]diff(
  Ni = length(anglecumi)

  #Nmin1=min(which(angleabs>10))
  #Nmin2=min(which(angleabsinv>10))
  res_temp = unlist(mclapply((i+1):size_test, 
                             GetSimilarity, angle_all_test, Ni, anglecumi,
                             mc.cores=nbCores))
  res_test[i,(i+1):size_test] = res_temp
  res_test[,i]=res_test[i,]
}
restest = do.call(pmax, lapply(1:nrow(res_test), function(i)res_test[i,]))
res_test_log = sapply(1:nrow(res_test), function(i)
  randdrivers[which(res_test[i,]==max(res_test[i,]))[1]])

result = cbind(randdrivers, pnorm(restest))
log_test = as.data.frame(cbind(result, res_test_log))
names(log_test) = c("driver","prob","driver2")

colnames(log_test) = c("driver_trip","prob","similarity")
write.csv(log_test, 
          paste0(dirInit, "log_position_v27_",m_interp,
                 "m_CAPPED",cap_pos*m_interp,"M_test.csv"), row.names=F, quote=F)

################ END TEST

getSimilarityRes <-function  (driver, dirInit)
{
  print(driver)
  dirPath = paste0(dirInit,"drivers/", driver, '/')
  
  angle_all = lapply(1:200, GetAngle, dirPath)
  
  res=matrix(0,200,200)
  
  for (i in 1:200)
  {
    anglecumi = angle_all[[i]]
    Ni = length(anglecumi)
    
    res_temp = 0

    if (Ni>70)
    {
      res_temp1 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-5, anglecumi[5:Ni])
      res_temp2 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-5, anglecumi[1:(Ni-5)])
      res_temp = pmax(res_temp,res_temp1,res_temp2)
    }
    if (Ni>70)
    {
      res_temp1 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-10, anglecumi[10:Ni])
      res_temp2 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-10, anglecumi[1:(Ni-10)])
      res_temp = pmax(res_temp,res_temp1,res_temp2)
    }
    if (Ni>70)
    {
      res_temp1 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-20, anglecumi[20:Ni])
      res_temp2 = sapply ((1:200)[-i], GetSimilarity, angle_all, Ni-20, anglecumi[1:(Ni-20)])
      res_temp = pmax(res_temp,res_temp1,res_temp2)
    }
    
    #res_temp = sapply ((i+1):200, GetSimilarity, angle_all, Ni, anglecumi)
    res[i,((1:200)[-i])] = pmax(res[i,((1:200)[-i])],res_temp)
  }
  res2 = do.call(pmax, lapply(1:nrow(res), function(i) pmax(res[i,],res[,i])))
  res2_log = sapply(1:nrow(res), function(i)which(res[i,]==max(res[i,]))[1])
  
  labels = sapply(1:200, function(x) paste0(driver,'_', x))
  result = rbind(labels, pnorm(res2))
  log = rbind(result, res2_log)
  
}

result = mclapply(drivers,getSimilarityRes,dirInit,mc.cores=nbCores)
log = matrix(unlist(result),ncol=3,byrow=TRUE)
colnames(log) = c("driver_trip","prob","similarity")
write.csv(log, 
          paste0(dirInit,"log_position_v27_",m_interp,
                 "m_CAPPED",cap_pos*m_interp,"M.csv"), row.names=F, quote=F)


