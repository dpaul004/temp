source('~/Documents/Models/Kaggle/Telematics/PathProf.R')

drivers<-list.files("/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/drivers")

ret_list<-vector("list",200*length(drivers)+1000)
prepData<-data.frame()

i=1

for (item in drivers) {
  print(item)
  wk_dir<-paste0("/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/drivers/",item)
  setwd(wk_dir)
  file_list<-list.files()
  
  for (fl in file_list) {
    ret<-dataprep(fl,item)
    ret_list[i]<-data.frame(ret)  
    i<-i+1
  }
}

ret_list<-ret_list[1:(i-1)]
prepData<-do.call("rbind",ret_list)


write.csv(prepData, "/Users/dipanjanpaul/Documents/Models/Kaggle/Telematics/finaldata.csv", row.names=F, quote=F)

  