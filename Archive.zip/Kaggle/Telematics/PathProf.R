dataprep<-function(infile,driver) {
  trip<-read.csv(infile,strip.white=T,header=T)
  r<-nrow(trip)
  
  drive<-strsplit(unlist(infile),"[.]")[[1]][1]
  
  trip[(((trip$x == 0) | (trip$y == 0))),c("Quad")]<-0
  trip[(((trip$x > 0) & (trip$y > 0))),c("Quad")]<-1 
  trip[(((trip$x < 0) & (trip$y > 0))),c("Quad")]<-2 
  trip[(((trip$x < 0) & (trip$y < 0))),c("Quad")]<-3
  trip[(((trip$x > 0) & (trip$y < 0))),c("Quad")]<-4
  
  trip3<-trip[which(as.integer(rownames(trip))%%3==0),]
  r3<-nrow(trip3)
  
  quad_dis<-trip3$Quad[which(trip$Quad==max(trip3$Quad))][1]
  
  int_dis<-sqrt(diff(trip3$x,1,1)^2 + diff(trip3$y,1,1)^2)
  speed<-3.6*int_dis/3
  accl<-diff(speed,1,1)
  
  speed_mean<-ifelse(length(speed) < 2, 0, mean(speed))
  speed_sd<-ifelse(length(speed) < 2, 0, sd(speed))
  speed_mad<-ifelse(length(speed) < 2, 0, mad(speed))
  
  accl_mean<-ifelse(length(accl) < 2, 0, mean(accl))
  accl_sd<-ifelse(length(accl) < 2, 0, sd(accl))
  accl_mad<-ifelse(length(accl) < 2, 0, mad(accl))
  
  speed_dis<-quantile(speed,seq(0.05,1,by=0.05))
  accl_dis<-quantile(accl,seq(0.05,1,by=0.05))
  
  tot_dis<-sum(int_dis)/1000
  air_dis<-(sqrt(diff(trip$x,(r-1),1)^2 + diff(trip$y,(r-1),1)^2))/1000
  tot_stop<-ifelse(is.na(table(int_dis < 0.08)[2]),0,table(int_dis < 0.08)[[2]])
  tot_time<-dim(trip)[1]/60
  
  turn<-(diff(trip3$y,1,1)/diff(trip3$x,1,1))
  turn[is.na(turn)]<-0
  turn[abs(turn)==Inf]<-0
  turn_dis<-quantile(turn,seq(.05,1,by = 0.05))
  
  turn_mean<-ifelse(length(turn) < 2, 0, mean(turn))
  turn_sd<-ifelse(length(turn) < 2, 0, sd(turn))
  turn_mad<-ifelse(length(turn) < 2, 0, mad(turn))
  
  turn_a<-atan(diff(trip3$y,1,1)/diff(trip3$x,1,1))
  turn_a[is.na(turn_a)]<-0
  turn_a[abs(turn_a)==Inf]<-0
  turn_a_dis<-diff(turn_a,1,1)
  
  turn_pts<-which(abs(turn_a) > 1.56)
  if (length(turn_pts) > 0) {
    turn_pt_med_speed<-quantile(unlist(lapply(turn_pts, function(x) mean(speed[(ifelse((x-3) < 1,1,(x-3))):x]))))
  } else {
    turn_pt_med_speed<-0
  }
  
##  stop_tm<-sqrt(diff(trip$x,3,1)^2 + diff(trip$y,3,1)^2)
##  stop_pct<-sum(stop_tm < 0.25)/length(stop_tm)
  
  dr_lm<-lm(y~x,data=trip3)
  dr_lm$coefficients[which(is.na(dr_lm$coefficients))]<-0
  
  features<-c(driver,drive,quad_dis,turn_dis,speed_dis,accl_dis,tot_stop,turn_pt_med_speed,
              speed_mean,speed_sd,speed_mad,accl_mean,accl_sd,accl_mad,
              turn_mean,turn_sd,turn_mad,tot_time,
              tot_dis,air_dis,dr_lm$coefficients[1],dr_lm$coefficients[2])
  
  return(round(as.numeric(features),6))
}