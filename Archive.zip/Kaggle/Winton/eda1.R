library(tree)
library(clue)
library(tseries)

parm <- "none"
setwd("~/Documents/Models/Kaggle/Winton")

train <- read.csv('train-7.csv', header=T)
test <- read.csv('test-5.csv', header=T)

train_vars <- train[,c(2:147,210:211)]
test_vars <- test[,c(2:147)]

# Outlier Capping prior to imputation - train set
train_vars$Feature_3[which(train_vars$Feature_3 < -1.5)] <- -1.5
train_vars$Feature_3[which(train_vars$Feature_3 > 3.25)] <- 3.25
train_vars$Feature_4[which(train_vars$Feature_4 < -1.75)] <- -1.75
train_vars$Feature_6[which(train_vars$Feature_6 > 3)] <- 3
train_vars$Feature_9[which(train_vars$Feature_9 > 20)] <- 20
train_vars$Feature_14[which(train_vars$Feature_14 < .5)] <- .5
train_vars$Feature_14[which(train_vars$Feature_14 > 2.5)] <- 2.5
train_vars$Feature_15[which(train_vars$Feature_15 > 15)] <- 15
train_vars$Feature_17[which(train_vars$Feature_17 > 1.25)] <- 1.25
train_vars$Feature_21[which(train_vars$Feature_21 > 3.125)] <- 3.125
train_vars$Feature_22[which(train_vars$Feature_22 < -4.10)] <- -4.10
train_vars$Feature_23[which(train_vars$Feature_23 < -1.09)] <- -1.09
train_vars$Feature_25[which(train_vars$Feature_25 >  1.06)] <- 1.06

# Outlier Capping prior to imputation - test set
test_vars$Feature_3[which(test_vars$Feature_3 < -1.5)] <- -1.5
test_vars$Feature_3[which(test_vars$Feature_3 > 3.25)] <- 3.25
test_vars$Feature_4[which(test_vars$Feature_4 < -1.75)] <- -1.75
test_vars$Feature_6[which(test_vars$Feature_6 > 3)] <- 3
test_vars$Feature_9[which(test_vars$Feature_9 > 20)] <- 20
test_vars$Feature_14[which(test_vars$Feature_14 < .5)] <- .5
test_vars$Feature_14[which(test_vars$Feature_14 > 2.5)] <- 2.5
test_vars$Feature_15[which(test_vars$Feature_15 > 15)] <- 15
test_vars$Feature_17[which(test_vars$Feature_17 > 1.25)] <- 1.25
test_vars$Feature_21[which(test_vars$Feature_21 > 3.125)] <- 3.125
test_vars$Feature_22[which(test_vars$Feature_22 < -4.10)] <- -4.10
test_vars$Feature_23[which(test_vars$Feature_23 < -1.09)] <- -1.09
test_vars$Feature_25[which(test_vars$Feature_25 >  1.06)] <- 1.06

# Imputing Missing Values,..
num_cols <- ncol(train_vars) - 2
impute_cols <- which(colSums(apply(train_vars,2,is.na)) != 0)

for (i in (1:length(impute_cols))) {
#  print(c('Imputing: ', names(train_vars[impute_cols[i]])))
  trn_missing_idx <- which(is.na(train_vars[,impute_cols[i]]) == T)
  tst_missing_idx <- which(is.na(test_vars[,impute_cols[i]]) == T)
  
  if (length(trn_missing_idx) < .6 * length(train_vars[,impute_cols[i]])) {
    print(c('Imputing with DT: ', names(train_vars[impute_cols[i]])))
    tree_model <- tree(train_vars[,impute_cols[i]] ~., data=train_vars[,(1:num_cols)])
    train_vars[trn_missing_idx,impute_cols[i]] <- 
        predict(tree_model, newdata = train_vars[trn_missing_idx,])
    test_vars[tst_missing_idx,impute_cols[i]] <- 
      predict(tree_model, newdata = test_vars[tst_missing_idx,])
  } else {
    print(c('Imputing with means: ', names(train_vars[impute_cols[i]])))
    train_vars[trn_missing_idx,impute_cols[i]] <- 
      mean(c(train_vars[-trn_missing_idx,impute_cols[i]], test_vars[-tst_missing_idx,impute_cols[i]]))
    test_vars[tst_missing_idx,impute_cols[i]] <- 
      mean(c(train_vars[-trn_missing_idx,impute_cols[i]], test_vars[-tst_missing_idx,impute_cols[i]]))
  }
     
#  train_vars[,c(paste(names(train_vars[impute_cols[i]]),"_IMP_F",sep=""))] <- 0
#  train_vars[trn_missing_idx,c(paste(names(train_vars[impute_cols[i]]),"_IMP_F",sep=""))] <- 1
  
#  test_vars[,c(paste(names(test_vars[impute_cols[i]]),"_IMP_F",sep=""))] <- 0
#  test_vars[tst_missing_idx,c(paste(names(test_vars[impute_cols[i]]),"_IMP_F",sep=""))] <- 1
}

#Var Transformation - train and set
train_vars$Feature_6 <- sign(train_vars$Feature_6) * log(abs(train_vars$Feature_6) + 0.01)
test_vars$Feature_6 <- sign(test_vars$Feature_6) * log(abs(test_vars$Feature_6) + 0.01)

brks <- quantile(c(train_vars$Feature_7, test_vars$Feature_7),seq(0,1,.05))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_7,breaks=brks))
train_vars$Feature_7 <- temp
temp <- (.bincode(test_vars$Feature_7,breaks=brks))
test_vars$Feature_7 <- temp

brks <- quantile(c(train_vars$Feature_8, test_vars$Feature8),seq(0,1,.33))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_8,breaks=brks))
train_vars$Feature_8 <- temp
temp <- (.bincode(test_vars$Feature_8,breaks=brks))
test_vars$Feature_8 <- temp

train_vars$Feature_9 <- (round(train_vars$Feature_9))
train_vars$Feature_11 <- sign(train_vars$Feature_11) * log(abs(train_vars$Feature_11) + 0.0001)
test_vars$Feature_9 <- (round(test_vars$Feature_9))
test_vars$Feature_11 <- sign(test_vars$Feature_11) * log(abs(test_vars$Feature_11) + 0.0001)

brks <- quantile(c(train_vars$Feature_12, test_vars$Feature_12), seq(0,1,.1))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_12,breaks=brks))
train_vars$Feature_12 <- temp
temp <- (.bincode(test_vars$Feature_12,breaks=brks))
test_vars$Feature_12 <- temp

train_vars$Feature_13 <- (round(train_vars$Feature_13))
train_vars$Feature_15 <- sqrt(train_vars$Feature_15)
train_vars$Feature_18 <- sign(train_vars$Feature_18) * log(abs(train_vars$Feature_18) + 0.001)
train_vars$Feature_20 <- (round(train_vars$Feature_20))
train_vars$Feature_24 <- sign(train_vars$Feature_24) * log(abs(train_vars$Feature_24) + 0.01)

test_vars$Feature_13 <- (round(test_vars$Feature_13))
test_vars$Feature_15 <- sqrt(test_vars$Feature_15)
test_vars$Feature_18 <- sign(test_vars$Feature_18) * log(abs(test_vars$Feature_18) + 0.001)
test_vars$Feature_20 <- (round(test_vars$Feature_20))
test_vars$Feature_24 <- sign(test_vars$Feature_24) * log(abs(test_vars$Feature_24) + 0.01)

km_df_main <- rbind(train_vars[,1:25], test_vars[,1:25])
km_df_ret <- rbind(train_vars[,28:146], test_vars[,28:146])

km_main <- kmeans(km_df_main, centers=20, nstart=20, iter.max=50)
km_train <- as.factor(cl_predict(km_main, newdata=train_vars[,1:25]))

km_dly_ret <- kmeans(train_vars[,28:146], 50, nstart=20, iter.max=50)
km_trn_dly <- as.factor(cl_predict(km_dly_ret, newdata=train_vars[,28:146]))

# Interaction and Additional Variables - train set
day_1_int <- apply(train_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_1_coeff <- apply(train_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_int <- apply(train_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_coeff <- apply(train_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_3_int <- apply(train_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])
day_3_coeff <- apply(train_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])

#arr <- array(0,c(20,25,20))
#for (i in (1:20)) {
#  km_model <- kmeans(train_vars[,1:25], centers=20, iter.max=50)
#  arr[,,i] <- km_model$center
#}

#km_centers <- apply(arr, 1:2, mean)

train_temp <- data.frame(km_train, train_vars, day_1_int, day_1_coeff, day_2_int, day_2_coeff, 
                         day_3_int, day_3_coeff, train$Ret_PlusOne, train$Ret_PlusTwo)

names(train_temp)[156:157] <- c("Ret_PlusOne", "Ret_PlusTwo")
#write.table(train_temp, "W_R+.csv",sep=',',col.names=T,row.names=F)

# Interaction and Additional Variables - test variables
day_1_int <- apply(test_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_1_coeff <- apply(test_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_int <- apply(test_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_coeff <- apply(test_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_3_int <- apply(test_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])
day_3_coeff <- apply(test_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])


x <- array()
for (i in (1:1000)) {
  i <- 2000 + i
  Y <- cos(t(train_vars[i,28:146]))
  m <- lowess(Y ~ 1:119)
#  m <- arima(Y,order=c(1,0,1))
#  plot(t(train[i,148:207]), col="red")
#  lines(t(train[i,148:207]), col="red")
#  lines(unclass(predict(m, 60)$pred), col='blue') 
  x[i-2000] <- (summary(unlist(abs((unclass(predict(m, 60)$pred) - train[i,148:207])/train[i,148:207])))[3])
}
hist(x,breaks=seq(0,5,.05))

km_test <- as.factor(cl_predict(km_final, newdata=test_vars[,1:25]))
Id <- test$Id


test_temp <- data.frame(Id, km_test, test_vars, day_1_int, day_1_coeff, day_2_int, day_2_coeff, 
                         day_3_int, day_3_coeff)

test_temp$Ret_PlusOne = NA
test_temp$Ret_PlusTwo = NA

for (i in (1:20)) {
  df <- train_temp[train_temp$km_train == i,]
  
  if (i == 1) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusOne + Ret_15 + Ret_21 + Ret_22 + Ret_42 + Ret_43 + Ret_49 + Ret_51 
                  + Ret_55 + Ret_58 + Ret_59 + Ret_66 
                  + Ret_71 + Ret_73 + Ret_77 + Ret_79 + Ret_83 + Ret_89 + Ret_92 + Ret_94 
                  + Ret_105 + Ret_114 + Ret_120 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_3 + Ret_29 + Ret_44 + Ret_45 + Ret_49 + Ret_53 + Ret_54 + Ret_65 
                  + Ret_72 + Ret_77 + Ret_86 + Ret_91 + Ret_94 + Ret_96 + Ret_105 + Ret_106 + Ret_118, data=df)
    
  } else if (i == 2) {
    model_1 <- lm(Ret_PlusOne ~ Ret_22 + Ret_27 + Ret_40 + Ret_54 + Ret_71 + Ret_72 + Ret_88 
                  + Ret_90 + Ret_94 + Ret_98 + Ret_104 + Ret_105 + Ret_106 + Ret_112, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_14 + Ret_21 + Ret_26 + Ret_39 + Ret_44 + Ret_59 + Ret_67 + Ret_69 + Ret_77 + Ret_88 
                  + Ret_90 + Ret_91 + Ret_107 + Ret_118, data=df)
    
  } else if (i == 3) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusOne + Ret_6 + Ret_10 + Ret_18 + Ret_34 + Ret_42 + Ret_44 
                  + Ret_49 + Ret_67 + Ret_72 + Ret_75 + Ret_80 + Ret_100 + Ret_106 + Ret_109 + Ret_117 + Ret_118, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_15 + Ret_16 + Ret_25 + Ret_30 + Ret_33 + Ret_35 + Ret_38 + Ret_40 + Ret_47 + Ret_54 
                  + Ret_59 + Ret_68 + Ret_72 + Ret_75 + Ret_79 + Ret_93 + Ret_101 + Ret_103 + Ret_110 + day_2_int, data=df)
    
  } else if (i == 4) {
    model_1 <- lm(Ret_PlusOne ~ Feature_22 + Ret_MinusTwo + Ret_2 + Ret_5 + Ret_14 + Ret_17 + Ret_21 + Ret_31 + Ret_33 
                  + Ret_34 + Ret_35 + Ret_39 + Ret_41 + Ret_47 + Ret_54 + Ret_55 + Ret_56 + Ret_57 + Ret_61 + Ret_70 + Ret_76 + Ret_82 + Ret_83 
                  + Ret_88 + Ret_92 + Ret_99 + Ret_100 + Ret_106 + Ret_109 + Ret_114 + Ret_115 + Ret_120, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_21 + Ret_33 + Ret_35 + Ret_60 + Ret_65 + Ret_76 + Ret_79 
                  + Ret_82 + Ret_88 + Ret_92 + Ret_119, data=df)
    
  } else if (i == 5) {
    model_1 <- lm(Ret_PlusOne ~ Ret_3 + Ret_12 + Ret_27 + Ret_28 + Ret_34 + Ret_53 
                  + Ret_54 + Ret_70 + Ret_71 + Ret_72 + Ret_73 + Ret_99, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_14 + Ret_44 + Ret_52 + Ret_54 + Ret_67 + Ret_69 
                  + Ret_70 + Ret_71 + Ret_75 + Ret_91 + Ret_97 + Ret_107 + Ret_113 + Ret_114 + Ret_115 + Ret_118, data=df)
    
  } else if (i == 6) {
    model_1 <- lm(Ret_PlusOne ~ Ret_11 + Ret_13 + Ret_22 + Ret_28 + Ret_49 + Ret_57 + Ret_58 + Ret_66 + Ret_72 + Ret_81 
                  + Ret_84 + Ret_104 + Ret_108 + Ret_111 + Ret_114 + Ret_117 + day_1_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_10 + Ret_44 + Ret_49 + Ret_50 
                  + Ret_65 + Ret_86 + Ret_91 + Ret_94 + Ret_96 + Ret_105 + Ret_106 + Ret_113 + Ret_118, data=df)
    
  } else if (i == 7) {
    model_1 <- lm(Ret_PlusOne ~ Ret_10 + Ret_17 + Ret_40 + Ret_49 + Ret_50 + Ret_68 + Ret_79 + Ret_80 
                  + Ret_85 + Ret_87 + Ret_91 + Ret_105 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_6 + Ret_22 + Ret_25 + Ret_27 + Ret_30 + Ret_38 + Ret_49 + Ret_54 
                  + Ret_55 + Ret_66 + Ret_83 + Ret_89 + Ret_92 + Ret_102 + Ret_103, data=df)
    
  } else if (i == 8) {
    model_1 <- lm(Ret_PlusOne ~ Feature_11 + Ret_8 + Ret_9 + Ret_10 + Ret_17 + Ret_25 + Ret_39 + Ret_55 
                  + Ret_56 + Ret_59 + Ret_60 + Ret_62 + Ret_66 + Ret_70 + Ret_71 + Ret_84 + Ret_85 + Ret_88 
                  + Ret_94 + Ret_97 + Ret_104 + Ret_112 + Ret_113 + Ret_115 + Ret_116 + Ret_118, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_10 + Ret_12 + Ret_15 + Ret_26 + Ret_32 + Ret_34 + Ret_41 + Ret_55 
                  + Ret_58 + Ret_59 + Ret_67 + Ret_69 + Ret_70 + Ret_76 + Ret_92 + Ret_94 + Ret_97 + Ret_101 + Ret_103 
                  + Ret_106 + Ret_107 + Ret_109 + Ret_110 + Ret_114, data=df)
    
  } else if (i == 9) {
    model_1 <- lm(Ret_PlusOne ~ Ret_8 + Ret_10 + Ret_11 + Ret_13 + Ret_20 + Ret_29 + Ret_37 
                  + Ret_42 + Ret_54 + Ret_55 + Ret_59 + Ret_64 + Ret_65 + Ret_79 + Ret_86 
                  + Ret_92 + Ret_97 + Ret_102 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_6 + Ret_22 + Ret_30 + Ret_34 + Ret_43 + Ret_46 + Ret_49 + Ret_50 + Ret_53 
                  + Ret_58 + Ret_66 + Ret_71 + Ret_94 + Ret_114 + Ret_116 + Ret_119 + Ret_120 + day_1_int, data=df)
    
  } else if (i == 10) {
    model_1 <- lm(Ret_PlusOne ~ Ret_6 + Ret_11 + Ret_12 + Ret_14 + Ret_19 + Ret_26 + Ret_34 
                  + Ret_36 + Ret_37 + Ret_44 + Ret_50 + Ret_54 + Ret_56 + Ret_64 + Ret_66 + Ret_67 + Ret_68 
                  + Ret_73 + Ret_74 + Ret_76 + Ret_77 + Ret_80 + Ret_82 + Ret_86 + Ret_91 + Ret_95 + Ret_99 
                  + Ret_100 + Ret_101 + Ret_102 + Ret_120 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusTwo + Ret_8 + Ret_12 + Ret_17 + Ret_22 + Ret_32 + Ret_37 + Ret_47 + Ret_57 
                  + Ret_62 + Ret_75 + Ret_76 + Ret_81 + Ret_82 + Ret_85 + Ret_88 + Ret_93 + Ret_94 + Ret_99 + Ret_100 + Ret_101 + Ret_103 
                  + Ret_107 + Ret_108 + Ret_117 + Ret_118 + day_1_int + day_2_int, data=df)
    
  } else if (i == 11) {
    model_1 <- lm(+ Ret_PlusOne ~ Ret_6 + Ret_9 + Ret_10 + Ret_14 + Ret_21 + Ret_26 + Ret_32 + Ret_35 + Ret_39 + Ret_42 
                  + Ret_49 + Ret_56 + Ret_57 + Ret_62 + Ret_66 + Ret_81 + Ret_84 + Ret_87 
                  + Ret_91 + Ret_95 + Ret_98 + Ret_101 + Ret_117 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_6 + Ret_9 + Ret_21 + Ret_22 + Ret_25 + Ret_32 + Ret_34 + Ret_40 + Ret_45 + Ret_47 
                  + Ret_54 + Ret_66 + Ret_71 + Ret_72 + Ret_73 + Ret_74 + Ret_76 + Ret_77 + Ret_81 + Ret_87 + Ret_89 + Ret_102 + Ret_104 
                  + Ret_111 + Ret_113 + Ret_116 + Ret_118, data=df)
    
  } else if (i == 12) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusOne + Ret_12 + Ret_13 + Ret_26 + Ret_34 
                  + Ret_54 + Ret_60 + Ret_70 + Ret_80 + Ret_84 + Ret_86 + Ret_99 + Ret_101 
                  + Ret_113 + Ret_117 + Ret_118 + Ret_119 + day_1_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_7 + Ret_14 + Ret_25 + Ret_32 + Ret_33 + Ret_34 + Ret_39 + Ret_41 + Ret_44 + Ret_60 
                  + Ret_68 + Ret_69 + Ret_70 + Ret_72 + Ret_80 + Ret_94 + Ret_105 + Ret_115 + Ret_119, data=df)
    
  } else if (i == 13) {
    model_1 <- lm(Ret_PlusOne ~ Ret_12 + Ret_24 + Ret_47 + Ret_50 + Ret_72 + Ret_78 + Ret_88 + Ret_92 
                  + Ret_93 + Ret_101 + Ret_104 + Ret_107 + Ret_112 + Ret_117 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_15 + Ret_17 + Ret_27 + Ret_29 + Ret_33 + Ret_34 + Ret_35 + Ret_59 + Ret_60 + Ret_69 + Ret_79 
                  + Ret_81 + Ret_82 + Ret_88 + Ret_92, data=df)
    
  } else if (i == 14) {
    model_1 <- lm(Ret_PlusOne ~ Feature_3 + Ret_2 + Ret_11 + Ret_36 + Ret_38 + Ret_43 + Ret_44 + Ret_46 + Ret_48 
                  + Ret_54 + Ret_58 + Ret_59 + Ret_60 + Ret_64 + Ret_66 + Ret_71 + Ret_79 + Ret_84 + Ret_88 
                  + Ret_90 + Ret_93 + Ret_100 + Ret_107 + Ret_108 + Ret_112 + day_2_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_16 + Ret_25 + Ret_30 + Ret_33 + Ret_39 + Ret_47 + Ret_48 + Ret_62 + Ret_83 + Ret_85 + Ret_90 
                  + Ret_91 + Ret_94 + Ret_95 + Ret_96 + Ret_101 + Ret_105 + Ret_106 + Ret_109 + Ret_110 + day_2_int, data=df)
    
  } else if (i == 15) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusOne + Ret_2 + Ret_3 + Ret_4 + Ret_17 + Ret_19 + Ret_22 + Ret_26 + Ret_37 
                  + Ret_43 + Ret_49 + Ret_55 + Ret_61 + Ret_63 + Ret_65 + Ret_76 + Ret_80 + 
                    Ret_84 + Ret_101 + Ret_111 + Ret_113 + Ret_115, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_7 + Ret_11 + Ret_12 + Ret_14 + Ret_17 + Ret_21 + Ret_26 + Ret_32 + Ret_34 + Ret_35 
                  + Ret_42 + Ret_49 + Ret_50 + Ret_57 + Ret_58 + Ret_59 + Ret_60 + Ret_65 + Ret_67 + Ret_68 
                  + Ret_70 + Ret_77 + Ret_89 + Ret_94 + Ret_98 + Ret_106 + Ret_112 + Ret_118 + Ret_119 + Ret_120, data=df)
    
  } else if (i == 16) {
    model_1 <- lm(Ret_PlusOne ~ Feature_1 + Ret_3 + Ret_16 + Ret_26 + Ret_29 + Ret_31 + Ret_42 + Ret_46 + Ret_47 
                  + Ret_48 + Ret_58 + Ret_65 + Ret_68 + Ret_74 + Ret_78 + Ret_81 + Ret_86 
                  + Ret_89 + Ret_100 + Ret_103 + Ret_117, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_4 + Ret_5 + Ret_11 + Ret_13 + Ret_17 + Ret_19 + Ret_22 + Ret_32 + Ret_36 + Ret_44 + Ret_49 
                  + Ret_51 + Ret_57 + Ret_58 + Ret_67 + Ret_68 + Ret_81 + Ret_91 + Ret_92 + Ret_98 + Ret_108 
                  + Ret_113 + Ret_114 + Ret_117, data=df)
    
  } else if (i == 17) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusTwo + Ret_4 + Ret_9 + Ret_23 + Ret_26 + Ret_29 + Ret_33 + Ret_35 + Ret_52 
                  + Ret_54 + Ret_60 + Ret_63 + Ret_71 + Ret_79 + Ret_88 + Ret_90 + Ret_92 + Ret_104 
                  + Ret_110 + Ret_116 + Ret_118, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_5 + Ret_11 + Ret_14 + Ret_19 + Ret_32 + Ret_48 + Ret_50 + Ret_52 + Ret_61 + Ret_67 + Ret_70 + Ret_81 
                  + Ret_84 + Ret_90 + Ret_91 + Ret_94 + Ret_97 + Ret_101 + Ret_106 + Ret_118, data=df)
    
  } else if (i == 18) {
    model_1 <- lm(Ret_PlusOne ~ Ret_2 + Ret_3 + Ret_4 + Ret_21 + Ret_34 + Ret_40 + Ret_42 + Ret_43 + Ret_46 + Ret_60 + Ret_66 
                  + Ret_73 + Ret_76 + Ret_77 + Ret_82 + Ret_85 + Ret_92 + Ret_93, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_5 + Ret_8 + Ret_12 + Ret_13 + Ret_14 + Ret_19 + Ret_21 + Ret_26 + Ret_28 
                  + Ret_33 + Ret_35 + Ret_47 + Ret_67 + Ret_76 + Ret_83 + Ret_93 + Ret_99 + Ret_101 
                  + Ret_103 + Ret_104 + Ret_107 + Ret_113 + Ret_119 + day_2_int, data=df)
    
  } else if (i == 19) {
    model_1 <- lm(Ret_PlusOne ~ Ret_9 + Ret_13 + Ret_28 + Ret_29 + Ret_31 + Ret_33 + Ret_39 + Ret_40 
                  + Ret_47 + Ret_56 + Ret_77 + Ret_86 + Ret_92 + Ret_103 + Ret_117 + Ret_119 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Feature_23 + Ret_11 + Ret_33 + Ret_34 + Ret_35 + Ret_44 + Ret_59 + Ret_61 + Ret_65 + Ret_79 
                  + Ret_82 + Ret_87 + Ret_88 + Ret_92 + Ret_95 + Ret_101 + Ret_103 + Ret_117 + Ret_119 + Ret_120, data=df)
    
  } else if (i == 20) {
    model_1 <- lm(Ret_PlusOne ~ Ret_MinusTwo + Ret_2 + Ret_8 + Ret_28 + Ret_39 + Ret_40 + Ret_46 + Ret_47 
                  + Ret_53 + Ret_60 + Ret_71 + Ret_92 + Ret_94 + Ret_106 + Ret_107 + Ret_109 + Ret_119 + day_2_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_8 + Ret_18 + Ret_28 + Ret_35 + Ret_45 + Ret_53 + Ret_60 + Ret_69 + Ret_77 
                  + Ret_80 + Ret_104 + Ret_110 + Ret_116 + Ret_120, data=df)
    
  } 
  
  test_temp[test_temp$km_test == i, c('Ret_PlusOne')] <- predict(model_1, newdata=test_temp[test_temp$km_test == i,])
  test_temp[test_temp$km_test == i, c('Ret_PlusTwo')] <- predict(model_2, newdata=test_temp[test_temp$km_test == i,])
}

write.table(train_temp, "W_R+.csv",sep=',',col.names=T,row.names=F)
#rm(train_temp)

df <- data.frame(train_vars[,-c(grep("_F", names(train_vars)))],  )
dly_df <- apply(train_vars, 2, function(r) rep(r, each=60))
tm_id <- rep((1:60), nrow(train))
dly_tgt <- unlist(apply(train[,c(148:207)], 1, function(z) list(t(z))))

train_temp <- data.frame(train_vars, day_1_int, day_1_coeff, day_2_int, day_2_coeff, day_3_int, 
                         day_3_coeff, 
                         train$Ret_PlusOne, train$Ret_PlusTwo)
names(train_temp)[155:156] <- c("Ret_PlusOne", "Ret_PlusTwo")

spl <- rbinom(nrow(train_temp), 1, .7)
trn <- train_temp[spl==1,]
tst <- train_temp[spl==0,]

#model <- lm(train.Ret_PlusOne ~ ., data=trn)
#var_sel <- step(model, direction="both")

ids <- unlist(lapply(train$Id,function(z) paste((rep(z,each=60)),"_",sep="",rep(1:60))))


### Arima Model ,..
