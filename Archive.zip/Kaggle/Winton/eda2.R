library(tree)
library(clue)
library(tseries)

parm <- "eda"
setwd("~/Documents/Models/Kaggle/Winton")

train <- read.csv('train-7.csv', header=T)
test <- read.csv('test_2.csv', header=T)

train_vars <- train[,c(2:147,210:211)]
test_vars <- test[,c(2:147)]

# Outlier Capping prior to imputation - train set
train_vars$Feature_3[which(train_vars$Feature_3 < -1.5)] <- -1.5
train_vars$Feature_3[which(train_vars$Feature_3 > 3.25)] <- 3.25
train_vars$Feature_4[which(train_vars$Feature_4 < -1.75)] <- -1.75
train_vars$Feature_6[which(train_vars$Feature_6 > 3)] <- 3
train_vars$Feature_9[which(train_vars$Feature_9 > 20)] <- 20
train_vars$Feature_14[which(train_vars$Feature_14 < .5)] <- .5
train_vars$Feature_14[which(train_vars$Feature_14 > 2.5)] <- 2.5
train_vars$Feature_15[which(train_vars$Feature_15 > 15)] <- 15
train_vars$Feature_17[which(train_vars$Feature_17 > 1.25)] <- 1.25
train_vars$Feature_21[which(train_vars$Feature_21 > 3.125)] <- 3.125
train_vars$Feature_22[which(train_vars$Feature_22 < -4.10)] <- -4.10
train_vars$Feature_23[which(train_vars$Feature_23 < -1.09)] <- -1.09
train_vars$Feature_25[which(train_vars$Feature_25 >  1.06)] <- 1.06

# Outlier Capping prior to imputation - test set
test_vars$Feature_3[which(test_vars$Feature_3 < -1.5)] <- -1.5
test_vars$Feature_3[which(test_vars$Feature_3 > 3.25)] <- 3.25
test_vars$Feature_4[which(test_vars$Feature_4 < -1.75)] <- -1.75
test_vars$Feature_6[which(test_vars$Feature_6 > 3)] <- 3
test_vars$Feature_9[which(test_vars$Feature_9 > 20)] <- 20
test_vars$Feature_14[which(test_vars$Feature_14 < .5)] <- .5
test_vars$Feature_14[which(test_vars$Feature_14 > 2.5)] <- 2.5
test_vars$Feature_15[which(test_vars$Feature_15 > 15)] <- 15
test_vars$Feature_17[which(test_vars$Feature_17 > 1.25)] <- 1.25
test_vars$Feature_21[which(test_vars$Feature_21 > 3.125)] <- 3.125
test_vars$Feature_22[which(test_vars$Feature_22 < -4.10)] <- -4.10
test_vars$Feature_23[which(test_vars$Feature_23 < -1.09)] <- -1.09
test_vars$Feature_25[which(test_vars$Feature_25 >  1.06)] <- 1.06

# Imputing Missing Values,..
num_cols <- ncol(train_vars) - 2
impute_cols <- which(colSums(apply(train_vars,2,is.na)) != 0)

for (i in (1:length(impute_cols))) {
#  print(c('Imputing: ', names(train_vars[impute_cols[i]])))
  trn_missing_idx <- which(is.na(train_vars[,impute_cols[i]]) == T)
  tst_missing_idx <- which(is.na(test_vars[,impute_cols[i]]) == T)
  
  if (length(trn_missing_idx) < .6 * length(train_vars[,impute_cols[i]])) {
    print(c('Imputing with DT: ', names(train_vars[impute_cols[i]])))
    tree_model <- tree(train_vars[,impute_cols[i]] ~., data=train_vars[,(1:num_cols)])
    train_vars[trn_missing_idx,impute_cols[i]] <- 
        predict(tree_model, newdata = train_vars[trn_missing_idx,])
    test_vars[tst_missing_idx,impute_cols[i]] <- 
      predict(tree_model, newdata = test_vars[tst_missing_idx,])
  } else {
    print(c('Imputing with means: ', names(train_vars[impute_cols[i]])))
    train_vars[trn_missing_idx,impute_cols[i]] <- 
      mean(c(train_vars[-trn_missing_idx,impute_cols[i]], test_vars[-tst_missing_idx,impute_cols[i]]))
    test_vars[tst_missing_idx,impute_cols[i]] <- 
      mean(c(train_vars[-trn_missing_idx,impute_cols[i]], test_vars[-tst_missing_idx,impute_cols[i]]))
  }
}

#Var Transformation - train and set
train_vars$Feature_6 <- sign(train_vars$Feature_6) * log(abs(train_vars$Feature_6) + 0.01)
test_vars$Feature_6 <- sign(test_vars$Feature_6) * log(abs(test_vars$Feature_6) + 0.01)

brks <- quantile(c(train_vars$Feature_7, test_vars$Feature_7),seq(0,1,.05))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_7,breaks=brks))
train_vars$Feature_7 <- temp
temp <- (.bincode(test_vars$Feature_7,breaks=brks))
test_vars$Feature_7 <- temp

brks <- quantile(c(train_vars$Feature_8, test_vars$Feature8),seq(0,1,.33))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_8,breaks=brks))
train_vars$Feature_8 <- temp
temp <- (.bincode(test_vars$Feature_8,breaks=brks))
test_vars$Feature_8 <- temp

train_vars$Feature_9 <- (round(train_vars$Feature_9))
train_vars$Feature_11 <- sign(train_vars$Feature_11) * log(abs(train_vars$Feature_11) + 0.0001)
test_vars$Feature_9 <- (round(test_vars$Feature_9))
test_vars$Feature_11 <- sign(test_vars$Feature_11) * log(abs(test_vars$Feature_11) + 0.0001)

brks <- quantile(c(train_vars$Feature_12, test_vars$Feature_12), seq(0,1,.1))
brks[1] <- brks[1] - 1
temp <- (.bincode(train_vars$Feature_12,breaks=brks))
train_vars$Feature_12 <- temp
temp <- (.bincode(test_vars$Feature_12,breaks=brks))
test_vars$Feature_12 <- temp

train_vars$Feature_13 <- (round(train_vars$Feature_13))
train_vars$Feature_15 <- sqrt(train_vars$Feature_15)
train_vars$Feature_18 <- sign(train_vars$Feature_18) * log(abs(train_vars$Feature_18) + 0.001)
train_vars$Feature_20 <- (round(train_vars$Feature_20))
train_vars$Feature_24 <- sign(train_vars$Feature_24) * log(abs(train_vars$Feature_24) + 0.01)

test_vars$Feature_13 <- (round(test_vars$Feature_13))
test_vars$Feature_15 <- sqrt(test_vars$Feature_15)
test_vars$Feature_18 <- sign(test_vars$Feature_18) * log(abs(test_vars$Feature_18) + 0.001)
test_vars$Feature_20 <- (round(test_vars$Feature_20))
test_vars$Feature_24 <- sign(test_vars$Feature_24) * log(abs(test_vars$Feature_24) + 0.01)

km_df_main <- rbind(train_vars[,1:25], test_vars[,1:25])
km_main <- kmeans(km_df_main, centers=20, nstart=20, iter.max=50)
km_train <- as.factor(cl_predict(km_main, newdata=train_vars[,1:25]))

# Interaction and Additional Variables - train set
day_1_int <- apply(train_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_1_coeff <- apply(train_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_int <- apply(train_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_coeff <- apply(train_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_3_int <- apply(train_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])
day_3_coeff <- apply(train_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])

train_temp <- data.frame(km_train, train_vars, day_1_int, day_1_coeff, day_2_int, day_2_coeff, 
                         day_3_int, day_3_coeff, train$Ret_PlusOne, train$Ret_PlusTwo)

names(train_temp)[156:157] <- c("Ret_PlusOne", "Ret_PlusTwo")

if (parm == "eda") {
  write.table(train_temp, "W_R+.csv",sep=',',col.names=T,row.names=F)
}

# Interaction and Additional Variables - test variables
day_1_int <- apply(test_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_1_coeff <- apply(test_vars[,(28:67)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_int <- apply(test_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_2_coeff <- apply(test_vars[,(68:107)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,40,1), x))))[[1]][1])
day_3_int <- apply(test_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])
day_3_coeff <- apply(test_vars[,(108:146)], 1, function(x) lm(x ~ V1, data=(data.frame(cbind(seq(1,39,1), x))))[[1]][1])

km_test <- as.factor(cl_predict(km_main, newdata=test_vars[,1:25]))
Id <- test$Id

test_temp <- data.frame(Id, km_test, test_vars, day_1_int, day_1_coeff, day_2_int, day_2_coeff, 
                         day_3_int, day_3_coeff)

if (parm == "eda") {
  write.table(test_temp, "test_cln.csv",sep=',',col.names=T,row.names=F)
}
