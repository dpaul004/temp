library(tree)
library(clue)
library(tseries)
alternate <- "NO"

parm <- "pred"
setwd("~/Documents/Models/Kaggle/Winton")

train_temp <- read.csv('W_R+.csv', header=T)
test_temp <- read.csv('test_cln.csv', header=T)

if (alternate == "NO") {
  test_temp$Ret_IntraDay = apply(test_temp[, 30:148], 1, median)
} else {
  Ret_Intraday_Arima <- apply(test_temp[, 30:148], 1, function(x) predict(arima(x, order=c(0,0,3)), 60)$pred)
}

test_temp$Ret_PlusOne = NA
test_temp$Ret_PlusTwo = NA

for (i in (1:20)) {
  df <- train_temp[train_temp$km_train == i,]
  
  if (i == 1) {
    model_1 <- lm(Ret_PlusOne ~  Feature_18 + Feature_21 + Ret_4 + Ret_14 + Ret_19 + Ret_22 + Ret_29 + 
                    Ret_41 + Ret_49 + Ret_54 + Ret_56 + Ret_58 + Ret_62 + Ret_66 + Ret_73 + Ret_77 + 
                    Ret_82 + Ret_85 + Ret_87 + Ret_91 + Ret_94 + Ret_99 + Ret_101 + Ret_102 + Ret_103 + 
                    Ret_104 + Ret_107 + Ret_113 + Ret_120 + day_1_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~  Feature_1 + Ret_MinusTwo + Ret_9 + Ret_17 + Ret_19 + Ret_21 + Ret_23 + 
                    Ret_28 + Ret_30 + Ret_32 + Ret_44 + Ret_56 + Ret_59 + Ret_76 + Ret_77 + Ret_78 + 
                    Ret_79 + Ret_81 + Ret_88 + Ret_93 + Ret_94 + Ret_98 + Ret_99 + Ret_104 + Ret_108 + 
                    Ret_115 + Ret_118 + Ret_119 + Ret_120, data=df)
    
  } else if (i == 2) {
    model_1 <- lm(Ret_PlusOne ~ Feature_22 + Ret_27 + Ret_34 + Ret_36 + Ret_40 + Ret_42 + Ret_46 + Ret_50 + 
                    Ret_51 + Ret_69 + Ret_85 + Ret_92 + Ret_93 + Ret_103 + Ret_106, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Feature_5 + Ret_MinusTwo + Ret_5 + Ret_8 + Ret_31 + Ret_33 + Ret_34 + Ret_47 + 
                    Ret_68 + Ret_80 + Ret_98 + Ret_99 + Ret_102 + Ret_103 + Ret_106 + Ret_107 + Ret_119 + 
                    day_1_int + day_2_int, data=df)
    
  } else if (i == 3) {
    model_1 <- lm(Ret_PlusOne ~  Ret_3 + Ret_17 + Ret_25 + Ret_26 + Ret_27 + Ret_42 + Ret_47 + Ret_48 + 
                    Ret_49 + Ret_50 + Ret_53 + Ret_54 + Ret_56 + Ret_60 + Ret_68 + Ret_74 + Ret_77 + 
                    Ret_80 + Ret_88 + Ret_96 + Ret_102 + Ret_103 + Ret_115, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_8 + Ret_12 + Ret_17 + Ret_20 + Ret_22 + Ret_24 + Ret_30 + Ret_43 + 
                    Ret_47 + Ret_57 + Ret_60 + Ret_66 + Ret_82 + Ret_83 + Ret_85 + Ret_88 + Ret_91 + 
                    Ret_99 + Ret_108 + Ret_111 + Ret_117 + Ret_118 + Ret_119, data=df)
    
  } else if (i == 4) {
    model_1 <- lm(Ret_PlusOne ~  Ret_MinusOne + Ret_8 + Ret_13 + Ret_29 + Ret_37 + Ret_42 + Ret_59 + 
                    Ret_65 + Ret_79 + Ret_80 + Ret_86 + Ret_92 + Ret_97 + Ret_102 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_22 + Ret_43 + Ret_46 + Ret_49 + Ret_53 + Ret_58 + Ret_62 + Ret_71 + 
                    Ret_74 + Ret_94 + Ret_101 + Ret_105 + Ret_116 + day_1_int, data=df)
    
  } else if (i == 5) {
    model_1 <- lm(Ret_PlusOne ~  Ret_10 + Ret_13 + Ret_24 + Ret_40 + Ret_47 + Ret_73 + Ret_76 + Ret_78 + Ret_82 + 
                    Ret_89 + Ret_92 + Ret_93 + Ret_101 + Ret_102 + Ret_104 + Ret_117, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_33 + Ret_34 + Ret_35 + Ret_47 + Ret_67 + Ret_79 + Ret_82 + Ret_88 + 
                    Ret_92 + Ret_113 + Ret_117, data=df)
    
  } else if (i == 6) {
    model_1 <- lm(Ret_PlusOne ~  Ret_10 + Ret_21 + Ret_22 + Ret_27 + Ret_28 + Ret_38 + Ret_50 + Ret_54 + Ret_59 + 
                    Ret_70 + Ret_79 + Ret_94 + Ret_111 + Ret_116 + Ret_117 + Ret_118, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_14 + Ret_34 + Ret_41 + Ret_44 + Ret_49 + Ret_50 + 
                    Ret_51 + Ret_61 + Ret_65 + Ret_66 + Ret_86 + Ret_91 + Ret_94 + Ret_102 + Ret_106 + 
                    Ret_112 + Ret_113 + Ret_114 + Ret_115, data=df)
    
  } else if (i == 7) {
    model_1 <- lm(Ret_PlusOne ~  Ret_12 + Ret_25 + Ret_31 + Ret_44 + Ret_51 + Ret_54 + Ret_55 + Ret_59 + 
                    Ret_60 + Ret_70 + Ret_71 + Ret_79 + Ret_85 + Ret_87 + Ret_89 + Ret_99 + Ret_100 + 
                    Ret_104 + Ret_110 + Ret_112 + Ret_115 + Ret_116 + Ret_118 + day_1_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_4 + Ret_7 + Ret_10 + Ret_32 + Ret_33 + Ret_34 + Ret_41 + Ret_49 + 
                    Ret_64 + Ret_69 + Ret_70 + Ret_72 + Ret_76 + Ret_94 + Ret_97 + Ret_101 + Ret_105 + 
                    Ret_106 + Ret_107 + Ret_109 + Ret_110 + Ret_114, data=df)
    
  } else if (i == 8) {
    model_1 <- lm(Ret_PlusOne ~  Ret_4 + Ret_9 + Ret_34 + Ret_35 + Ret_40 + Ret_47 + Ret_51 + Ret_54 + 
                    Ret_55 + Ret_60 + Ret_63 + Ret_68 + Ret_71 + Ret_87 + Ret_90 + Ret_93 + Ret_98 + 
                    Ret_99 + Ret_104 + Ret_110 + Ret_114 + Ret_116, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_7 + Ret_14 + Ret_32 + Ret_49 + Ret_54 + Ret_61 + Ret_70 + Ret_71 + Ret_90 + 
                    Ret_91 + Ret_94 + Ret_96 + Ret_101 + Ret_106 + Ret_107 + Ret_114 + Ret_115 + Ret_116 + 
                    Ret_118 + Ret_120, data=df)
    
  } else if (i == 9) {
    model_1 <- lm(Ret_PlusOne ~  Ret_12 + Ret_29 + Ret_33 + Ret_39 + Ret_40 + Ret_86 + Ret_92 + 
                    Ret_99 + Ret_103 + Ret_106 + Ret_116 + Ret_119 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_20 + Ret_28 + Ret_34 + Ret_35 + Ret_42 + Ret_60 + Ret_61 + 
                    Ret_63 + Ret_64 + Ret_82 + Ret_88 + Ret_92 + Ret_95 + Ret_101 + Ret_111 + Ret_119 + 
                    Ret_120, data=df)
    
  } else if (i == 10) {
    model_1 <- lm(Ret_PlusOne ~  Ret_8 + Ret_17 + Ret_23 + Ret_25 + Ret_26 + Ret_30 + Ret_31 + 
                    Ret_44 + Ret_50 + Ret_54 + Ret_57 + Ret_60 + Ret_61 + Ret_65 + Ret_66 + Ret_68 + 
                    Ret_74 + Ret_93 + Ret_101 + Ret_106 + Ret_107 + Ret_120, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusTwo + Ret_2 + Ret_6 + Ret_14 + Ret_18 + Ret_25 + Ret_31 + Ret_33 + 
                    Ret_34 + Ret_35 + Ret_38 + Ret_39 + Ret_40 + Ret_41 + Ret_45 + Ret_47 + Ret_48 + Ret_54 + 
                    Ret_61 + Ret_62 + Ret_63 + Ret_70 + Ret_76 + Ret_77 + Ret_82 + Ret_83 + 
                    Ret_88 + Ret_91 + Ret_100 + Ret_108 + Ret_109 + Ret_113 + Ret_115 + Ret_120, data=df)
    
  } else if (i == 11) {
    model_1 <- lm(+ Ret_PlusOne ~  Ret_MinusOne + Ret_3 + Ret_8 + Ret_10 + Ret_23 + Ret_35 + Ret_50 + 
                    Ret_54 + Ret_65 + Ret_68 + Ret_74 + Ret_75 + Ret_77 + Ret_82 + Ret_103 + Ret_109 + 
                    Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_5 + Ret_8 + Ret_11 + Ret_26 + Ret_28 + Ret_49 + Ret_51 + Ret_52 + 
                    Ret_57 + Ret_58 + Ret_66 + Ret_72 + Ret_76 + Ret_82 + Ret_88 + Ret_94 + Ret_104 + 
                    Ret_110 + Ret_111 + Ret_114 + Ret_117 + Ret_119, data=df)
    
  } else if (i == 12) {
    model_1 <- lm(Ret_PlusOne ~  Ret_MinusTwo + Ret_14 + Ret_17 + Ret_50 + Ret_74 + Ret_79 + Ret_80 + Ret_87 + 
                    Ret_91 + Ret_99 + Ret_117 + day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusTwo + Ret_6 + Ret_12 + Ret_22 + Ret_25 + Ret_27 + Ret_38 + Ret_54 + 
                    Ret_55 + Ret_62 + Ret_66 + Ret_83 + Ret_92 + Ret_103 + Ret_111, data=df)
    
  } else if (i == 13) {
    model_1 <- lm(Ret_PlusOne ~  Feature_22 + Ret_8 + Ret_9 + Ret_10 + Ret_14 + Ret_21 + Ret_26 + Ret_27 + 
                    Ret_29 + Ret_32 + Ret_35 + Ret_39 + Ret_40 + Ret_42 + Ret_48 + Ret_49 + Ret_57 + Ret_62 + 
                    Ret_66 + Ret_77 + Ret_83 + Ret_84 + Ret_91 + Ret_93 + Ret_95 + Ret_98 + Ret_99 + Ret_101 + 
                    Ret_104 + Ret_111 + Ret_115 + Ret_116 + Ret_117 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_MinusOne + Ret_6 + Ret_7 + Ret_11 + Ret_16 + Ret_17 + Ret_21 + Ret_22 + 
                    Ret_25 + Ret_32 + Ret_40 + Ret_44 + Ret_47 + Ret_52 + Ret_53 + Ret_57 + Ret_64 + Ret_71 + 
                    Ret_73 + Ret_76 + Ret_77 + Ret_85 + Ret_89 + Ret_90 + Ret_92 + Ret_102 + 
                    Ret_109 + Ret_111, data=df)
    
  } else if (i == 14) {
    model_1 <- lm(Ret_PlusOne ~  Ret_2 + Ret_8 + Ret_14 + Ret_18 + Ret_30 + Ret_35 + Ret_36 + Ret_38 + Ret_42 + 
                    Ret_44 + Ret_45 + Ret_46 + Ret_49 + Ret_54 + Ret_57 + Ret_58 + Ret_59 + Ret_66 + Ret_71 + 
                    Ret_81 + Ret_84 + Ret_88 + Ret_89 + Ret_90 + Ret_92 + Ret_93 + Ret_100 + Ret_102 + Ret_107 + 
                    Ret_108 + Ret_109 + Ret_112 + Ret_117, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_2 + Ret_19 + Ret_23 + Ret_25 + Ret_39 + Ret_41 + Ret_47 + Ret_53 + Ret_55 + 
                    Ret_63 + Ret_64 + Ret_77 + Ret_80 + Ret_83 + Ret_90 + Ret_92 + Ret_96 + Ret_97 + Ret_101 + 
                    Ret_107 + Ret_109 + Ret_111 + Ret_112 + Ret_116 + Ret_120 + day_2_int, data=df)
    
  } else if (i == 15) {
    model_1 <- lm(Ret_PlusOne ~  Feature_25 + Ret_21 + Ret_26 + Ret_34 + Ret_41 + Ret_46 + Ret_54 + Ret_64 + 
                    Ret_72 + Ret_85 + Ret_86 + Ret_93 + Ret_95 + Ret_105 + Ret_109 + Ret_117, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Feature_15 + Ret_22 + Ret_24 + Ret_32 + Ret_34 + Ret_39 + Ret_44 + Ret_45 + 
                    Ret_57 + Ret_58 + Ret_65 + Ret_67 + Ret_70 + Ret_72 + Ret_82 + Ret_94 + Ret_97 + 
                    Ret_105 + Ret_106 + Ret_108 + Ret_113, data=df)
    
  } else if (i == 16) {
    model_1 <- lm(Ret_PlusOne ~  Ret_MinusTwo + Ret_9 + Ret_27 + Ret_40 + Ret_48 + Ret_57 + Ret_63 + 
                    Ret_71 + Ret_76 + Ret_83 + Ret_97 + Ret_107 + Ret_109 + Ret_112 + Ret_119, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_8 + Ret_15 + Ret_28 + Ret_35 + Ret_37 + Ret_40 + Ret_53 + Ret_69 + 
                    Ret_71 + Ret_79 + Ret_80 + Ret_86 + Ret_94 + Ret_107 + Ret_116 + Ret_120 + day_2_int, data=df)
    
  } else if (i == 17) {
    model_1 <- lm(Ret_PlusOne ~  Ret_MinusOne + Ret_4 + Ret_8 + Ret_15 + Ret_17 + Ret_22 + Ret_26 + 
                    Ret_37 + Ret_43 + Ret_44 + Ret_53 + Ret_55 + Ret_61 + Ret_80 + Ret_84 + Ret_98 + 
                    Ret_111 + Ret_115, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_7 + Ret_14 + Ret_19 + Ret_21 + Ret_26 + Ret_37 + Ret_41 + Ret_42 + 
                    Ret_49 + Ret_50 + Ret_58 + Ret_61 + Ret_62 + Ret_65 + Ret_67 + Ret_68 + Ret_77 + 
                    Ret_84 + Ret_89 + Ret_92 + Ret_94 + Ret_96 + Ret_106 + Ret_118 + Ret_119 + Ret_120, data=df)
    
  } else if (i == 18) {
    model_1 <- lm(Ret_PlusOne ~  Ret_22 + Ret_27 + Ret_40 + Ret_47 + Ret_54 + Ret_65 + Ret_71 + Ret_79 + 
                    Ret_86 + Ret_90 + Ret_94 + Ret_96 + Ret_98 + Ret_104 + Ret_105 + Ret_106 + Ret_112 + 
                    day_3_int, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_14 + Ret_21 + Ret_25 + Ret_39 + Ret_44 + Ret_59 + Ret_69 + 
                    Ret_77 + Ret_88 + Ret_107 + Ret_118, data=df)
    
  } else if (i == 19) {
    model_1 <- lm(Ret_PlusOne ~  Ret_MinusOne + Ret_32 + Ret_34 + Ret_43 + Ret_44 + Ret_46 + Ret_47 + 
                    Ret_59 + Ret_67 + Ret_71 + Ret_72 + Ret_80 + Ret_84 + Ret_98 + Ret_100 + Ret_101 + 
                    Ret_106 + Ret_113 + Ret_117 + Ret_118, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~ Ret_3 + Ret_15 + Ret_25 + Ret_38 + Ret_43 + Ret_54 + Ret_59 + Ret_75 + 
                    Ret_81 + Ret_84 + Ret_88 + Ret_101 + Ret_103 + Ret_107 + day_2_int, data=df)
    
  } else if (i == 20) {
    model_1 <- lm(Ret_PlusOne ~ Ret_3 + Ret_25 + Ret_29 + Ret_30 + Ret_33 + Ret_42 + Ret_46 + Ret_48 + 
                    Ret_51 + Ret_56 + Ret_58 + Ret_61 + Ret_65 + Ret_68 + Ret_86 + Ret_89 + Ret_100 + 
                    Ret_103 + Ret_115 + Ret_117, data=df)
    
    model_2 <- lm(Ret_PlusTwo ~  Ret_5 + Ret_11 + Ret_13 + Ret_18 + Ret_19 + Ret_22 + Ret_25 + Ret_36 + 
                    Ret_44 + Ret_49 + Ret_57 + Ret_58 + Ret_62 + Ret_66 + Ret_67 + Ret_72 + Ret_81 + 
                    Ret_91 + Ret_92 + Ret_110 + Ret_117, data=df)
    
  } 
  
  print(c(i, " M1: ", summary(model_1)$adj.r.squared))
  print(c(i, " M2: ", summary(model_2)$adj.r.squared))
  
  test_temp[test_temp$km_test == i, c('Ret_PlusOne')] <- predict(model_1, newdata=test_temp[test_temp$km_test == i,])
  test_temp[test_temp$km_test == i, c('Ret_PlusTwo')] <- predict(model_2, newdata=test_temp[test_temp$km_test == i,])
}

t_ids1 <- as.character(unlist(lapply(test_temp$Id,function(z) paste((rep(z,each=60)),"_",sep="",rep(1:60)))))

if (alternate == "NO") {
  t_Ret_IntraDay <- unlist(lapply(test_temp$Ret_IntraDay,function(z) rep(z,each=60)))
} else {
  #Alternate Return Intraday
  t_Ret_IntraDay <- unlist(apply(Ret_Intraday_Arima, 2, function(x) list(x)))
}

df1 <- data.frame(t_ids1, t_Ret_IntraDay)
names(df1) <- c('Id', 'Predicted')

t_ids2 <- as.character(unlist(lapply(test_temp$Id,function(z) paste((rep(z,each=2)),"_",sep="",rep(61:62)))))
dly_tgt <- unlist(apply(test_temp[,c('Ret_PlusOne',  'Ret_PlusTwo')], 1, function(z) list(t(z))))
df2 <- data.frame(t_ids2, dly_tgt)
names(df2) <- c('Id', 'Predicted')

df3 <- do.call('rbind', list(df1, df2))

write.table(df3, "submission.csv", sep=',', col.names=T, row.names=F)

### Arima Model ,..
