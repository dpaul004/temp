multipopl <- function(file, pop_n) {
  rows <- nrow(file)
  spl <- sample(x=1:pop_n, size=rows, replace=T)
  
  file$spl <- spl
  file$yhat <- NA
  
  rsq_prev <- 1
  min_rsq_reached <- "N"
  i <- 1
  
  while (min_rsq_reached == "N") {
    print(c("Iteration: ", i))
    
    file <- file[order(file$spl),]
    file$yhat <- unlist(lapply(1:pop_n, function(x) predict(lm(mpg ~ cylinders + displacement + horsepower + 
                                                weight + acceleration + year + origin, data=file[file$spl==x,]), 
                                                newdata=file[file$spl==x,])))
    
    rsq <- 1 - sum((file$mpg - file$yhat)**2)/sum((file$mpg - mean(file$mpg))**2)
    print(c('R Square: ', rsq))
    
    if ((abs(rsq - rsq_prev) < 0.02) | (i > 50))  {
      min_rsq_reached == "Y"
      break
    }
    
    x <- do.call('cbind', (lapply(1:pop_n, function(x) (file$mpg - (predict(lm(mpg ~ cylinders + displacement + horsepower + 
                                                        weight + acceleration + year + origin, data=file[file$spl==x,]), 
                                                        newdata=file)))**2)))
    
    file$spl <- apply(x, 1, function(x) which(x == min(x)))
    
    i <- i + 1
  }
  
  return(file)
}

library(ISLR)
parm <- "none"

if (parm == "eda") {
  head(Auto)
  summary(Auto)
}

out <- multipopl(Auto, 10)

