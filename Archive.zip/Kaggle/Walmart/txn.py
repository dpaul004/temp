"""
@author Dipanjan Paul
"""

## For each day, develop weather information pattern on the past 3 days
## leading to the current day and the next 3 days starting from the current day.
## This weather pattern will include 7 days of weather information.

import csv
import pandas as pd
import logging
import argparse
import numpy as np
from numpy import *

# configure logging
logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def data_cleaner(parm):
    # wrap the inputs and outputs in csv interpreters

    #keys = pd.read_csv("key.csv",header=0)

    data = pd.read_csv("train-3.csv",header=0)
    data.loc[:,"totsales"] = 0

    sales_sum_313 = (lambda m: sum(lst[(m - 3) : (m + 3)]))

    store_unq = data.store_nbr.unique().tolist()

    for store in store_unq:
        item_unq = data.loc[data.store_nbr == store,'item_nbr'].unique().tolist()

        for item in item_unq:
            lst = array(data.loc[((data.store_nbr == store) & (data.item_nbr == item)),'units'])
            data.loc[((data.store_nbr == store) & (data.item_nbr == item)),'totsales'][3:-3] = sales_sum_313(range(len(lst))[3:-3])



    data.to_csv("weather_enh.csv",index=False)

if __name__ == "__main__":
    # set up logger
    parser = argparse.ArgumentParser(description=__doc__)
    data_cleaner('test')
