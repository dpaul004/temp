__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import preprocessing
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm,forest):

    #writer = csv.writer(open("results_fin.csv", "wb"), delimiter=',')

    if (parm == 'train'):
        data=(pd.read_csv('train_enh.csv',header=0))
        units = data.units.values
        data = data.drop(["units","tot_sales"],axis=1)
    elif (parm=='test'):
        data=(pd.read_csv('test_enh.csv',header=0))
        id = data.id.values
        data = data.drop(["id"],axis=1)

    #transformer = TfidfTransformer()
    #data = transformer.fit_transform(data).toarray()

    if (parm == "train"):
        forest = RandomForestRegressor(n_jobs=-1, n_estimators=200,max_features=15)
        forest = forest.fit(data,units)
        logger.info("Completed Training")
        return forest
    elif (parm == "test"):
        output = forest.predict(data)
        pred = pd.DataFrame(output,index=id,columns=["units"])
        pred.to_csv("results.csv",index_label="id")

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('test',forest)