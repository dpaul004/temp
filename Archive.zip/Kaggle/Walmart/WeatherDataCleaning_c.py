"""
@author Dipanjan Paul
"""

## For each day, develop weather information pattern on the past 3 days
## leading to the current day and the next 3 days starting from the current day.
## This weather pattern will include 7 days of weather information.

import csv
import sys
import pandas as pd
import logging
import argparse
import numpy as np
from sklearn import datasets, linear_model
from numpy import *

# configure logging
logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

regr = linear_model.LinearRegression()


def data_cleaner(parm):
    # wrap the inputs and outputs in csv interpreters

    data = pd.read_csv("weather_cln.csv",header=0)
    stn_nbr = data.station_nbr.unique().tolist()

    data.loc[:,"tavg_c"] = 0
    data.loc[:,"tavg_i"] = 0

    data.loc[:,"wetbulb_c"] = 0
    data.loc[:,"wetbulb_i"] = 0

    data.loc[:,"dewpoint_c"] = 0
    data.loc[:,"dewpoint_i"] = 0

    data.loc[:,"snowfall_c"] = 0
    data.loc[:,"snowfall_i"] = 0

    data.loc[:,"preciptotal_c"] = 0
    data.loc[:,"preciptotal_i"] = 0


    lm_to_date_coef = (lambda m: regr.fit(lst[m - 4 : m, 1:], lst[m - 4 : m, 0:1]).coef_)
    lm_to_date_int = (lambda m: regr.fit(lst[m - 4 : m, 1:], lst[m - 4 : m, 0:1]).intercept_)

    lm_from_date = (lambda m: regr.fit(lst[m : m + 3, :], lst[m : m + 3, 0]))

    for s in stn_nbr:

        ##df = data.loc[data.station_nbr == s]
        ##m = range(5,len(df))

        m = data.loc[data.station_nbr==s,:].index[4:]

        lst = np.array(data.loc[data.station_nbr == s,'tavg'])
        lst = transpose(vstack((lst, range(len(lst)))))
        tavg_lm_c = map(lm_to_date_coef, m[:])
        tavg_lm_i = map(lm_to_date_int, m[:])

        data.loc[m,"tavg_c"] = tavg_lm_c
        data.loc[m,"tavg_i"] = tavg_lm_i

        lst = np.array(data.loc[data.station_nbr == s,'wetbulb'])
        lst = transpose(vstack((lst, range(len(lst)))))
        tavg_lm_c = map(lm_to_date_coef, m[:])
        tavg_lm_i = map(lm_to_date_int, m[:])

        data.loc[m,"wetbulb_c"] = tavg_lm_c
        data.loc[m,"wetbulb_i"] = tavg_lm_i

        lst = np.array(data.loc[data.station_nbr == s,'dewpoint'])
        lst = transpose(vstack((lst, range(len(lst)))))
        tavg_lm_c = map(lm_to_date_coef, m[:])
        tavg_lm_i = map(lm_to_date_int, m[:])

        data.loc[m,"dewpoint_c"] = tavg_lm_c
        data.loc[m,"dewpoint_i"] = tavg_lm_i

        lst = np.array(data.loc[data.station_nbr == s,'snowfall'])
        lst = transpose(vstack((lst, range(len(lst)))))
        tavg_lm_c = map(lm_to_date_coef, m[:])
        tavg_lm_i = map(lm_to_date_int, m[:])

        data.loc[m,"snowfall_c"] = tavg_lm_c
        data.loc[m,"snowfall_i"] = tavg_lm_i

        lst = np.array(data.loc[data.station_nbr == s,'preciptotal'])
        lst = transpose(vstack((lst, range(len(lst)))))
        tavg_lm_c = map(lm_to_date_coef, m[:])
        tavg_lm_i = map(lm_to_date_int, m[:])

        data.loc[m,"preciptotal_c"] = tavg_lm_c
        data.loc[m,"preciptotal_i"] = tavg_lm_i

        # Every 1000 rows send an update to the user for progress tracking.
        #if i % 1000 == 0:
        #    logger.info("Completed row %d" % i)

    data.save("weather_enh.csv")

if __name__ == "__main__":
    # set up logger
    parser = argparse.ArgumentParser(description=__doc__)
    data_cleaner('test')
