"""
@author Dipanjan Paul
"""

## For each day, develop weather information pattern on the past 3 days
## leading to the current day and the next 3 days starting from the current day.
## This weather pattern will include 7 days of weather information.

import csv
import sys
import pandas as pd
import logging
import argparse
import numpy as np
from sklearn import datasets, linear_model
from numpy import *

# configure logging
logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

regr = linear_model.LinearRegression()


def data_cleaner(parm):
    # wrap the inputs and outputs in csv interpreters

    #keys = pd.read_csv("key.csv",header=0)

    data = pd.read_csv("weather_cln.csv",header=0)
    stn_nbr = data.station_nbr.unique().tolist()

    data.loc[:,"tavg_c_to"] = 0
    data.loc[:,"tavg_c_from"] = 0

    data.loc[:,"wetbulb_c_to"] = 0
    data.loc[:,"wetbulb_c_from"] = 0

    data.loc[:,"dewpoint_c_to"] = 0
    data.loc[:,"dewpoint_c_from"] = 0

    data.loc[:,"snowfall_c_to"] = 0
    data.loc[:,"snowfall_c_from"] = 0

    data.loc[:,"preciptotal_c_to"] = 0
    data.loc[:,"preciptotal_c_from"] = 0

    lm_to_date_coef = (lambda m: regr.fit(lst[m - 3:m + 1, 1:], lst[m - 3:m + 1, 0:1]).coef_)
    lm_from_date_coef = (lambda m: regr.fit(lst[m:m + 3, 1:], lst[m:m + 3, 0:1]).coef_)

    for s in stn_nbr:

        loc_i = data.loc[data.station_nbr==s,:].index[4:]

        lst = np.array(data.loc[data.station_nbr == s,'tavg'])
        lst = transpose(vstack((lst, range(len(lst)))))

        arr = array(lst[::,1],dtype=int)[4:]

        tavg_lm_c_to = map(lm_to_date_coef, arr[:])
        tavg_lm_c_from = map(lm_from_date_coef, arr[:])

        data.loc[loc_i,"tavg_c_to"] = tavg_lm_c_to
        data.loc[loc_i,"tavg_c_from"] = tavg_lm_c_from

        lst = np.array(data.loc[data.station_nbr == s,'wetbulb'])
        lst = transpose(vstack((lst, range(len(lst)))))
        wetbulb_lm_c_to = map(lm_to_date_coef, arr[:])
        wetbulb_lm_c_from = map(lm_from_date_coef, arr[:])

        data.loc[loc_i,"wetbulb_c_to"] = wetbulb_lm_c_to
        data.loc[loc_i,"wetbulb_c_from"] = wetbulb_lm_c_from

        lst = np.array(data.loc[data.station_nbr == s,'dewpoint'])
        lst = transpose(vstack((lst, range(len(lst)))))
        dewpoint_lm_c_to = map(lm_to_date_coef, arr[:])
        dewpoint_lm_c_from = map(lm_from_date_coef, arr[:])

        data.loc[loc_i,"dewpoint_c_to"] = dewpoint_lm_c_to
        data.loc[loc_i,"dewpoint_c_from"] = dewpoint_lm_c_from

        lst = np.array(data.loc[data.station_nbr == s,'snowfall'])
        lst = transpose(vstack((lst, range(len(lst)))))
        snowfall_lm_c_to = map(lm_to_date_coef, arr[:])
        snowfall_lm_c_from = map(lm_from_date_coef, arr[:])

        data.loc[loc_i,"snowfall_c_to"] = snowfall_lm_c_to
        data.loc[loc_i,"snowfall_c_from"] = snowfall_lm_c_from

        lst = np.array(data.loc[data.station_nbr == s,'preciptotal'])
        lst = transpose(vstack((lst, range(len(lst)))))
        preciptotal_lm_c_to = map(lm_to_date_coef, arr[:])
        preciptotal_lm_c_from = map(lm_from_date_coef, arr[:])

        data.loc[loc_i,"preciptotal_c_to"] = preciptotal_lm_c_to
        data.loc[loc_i,"preciptotal_c_from"] = preciptotal_lm_c_from

        # Every 1000 rows send an update to the user for progress tracking.
        #if i % 1000 == 0:
        #    logger.info("Completed row %d" % i)

    data.to_csv("weather_enh.csv",index=False)

if __name__ == "__main__":
    # set up logger
    parser = argparse.ArgumentParser(description=__doc__)
    data_cleaner('null')
