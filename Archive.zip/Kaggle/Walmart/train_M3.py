__author__ = 'dipanjanpaul'

import pandas as pd
from datetime import *
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.feature_extraction.text import TfidfTransformer
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm):

    results = open("results.csv", "wb")
    out_file_obj = csv.writer(results)
    out_file_obj.writerow(['id','units'])

    data_trn = (pd.read_csv('train_ext.csv',header=0))
    data_tst = (pd.read_csv('test_enh.csv',header=0))

    pred = pd.DataFrame()
    transformer = TfidfTransformer()

    items = data_trn.item_nbr.unique()

    for item in items:
        stores = pd.DataFrame(data_tst.loc[data_tst.item_nbr == item,:]).store_nbr.unique()
        for store in stores:
            train = pd.DataFrame(data_trn.loc[((data_trn.item_nbr == item) & (data_trn.store_nbr == store)),:])
            units = train.units.values

            train["store_nbr"] = train["store_nbr"].astype('category')
            train["station_nbr"] = train["station_nbr"].astype('category')

            train["wkday"] = map(lambda x: datetime.strptime(x,"%Y-%m-%d").weekday(), train["date"])
            train.loc[train.wkday > 4,:]["wkday"] = "W"
            train.loc[train.wkday <= 4,:]["wkday"] = "H"
            train["wkday"] = train["wkday"].astype('category')

            train.loc[train.day < 0,"day"] = train.loc[train.day < 0,"day"] + 7
            train.loc[train.day == 0,"day"] = 7
            train.loc[train.day < 4,"day"] = abs(train.loc[train.day < 4,"day"] - 7)

            train["TS"] = train["TS"].astype('category')
            train["RA"] = train["RA"].astype('category')
            train["DZ"] = train["DZ"].astype('category')
            train["SN"] = train["SN"].astype('category')
            train["FG"] = train["FG"].astype('category')
            train["FG."] = train["FG."].astype('category')
            train["BR"] = train["BR"].astype('category')
            train["HZ"] = train["HZ"].astype('category')
            train["FZ"] = train["FZ"].astype('category')

            train["GR"] = train["GR"].astype('category')
            train["SG"] = train["SG"].astype('category')
            train["GS"] = train["GS"].astype('category')
            train["PL"] = train["PL"].astype('category')
            train["FU"] = train["FU"].astype('category')
            train["DU"] = train["DU"].astype('category')
            train["SS"] = train["SS"].astype('category')
            train["SQ"] = train["SQ"].astype('category')
            train["MI"] = train["MI"].astype('category')
            train["PR"] = train["PR"].astype('category')
            train["BC"] = train["BC"].astype('category')
            train["BL"] = train["BL"].astype('category')

            train = train.drop(["item_nbr","units", "date", "store_nbr",
                                "TS", "SQ", "SS"],axis=1)

            test = pd.DataFrame(data_tst.loc[((data_tst.item_nbr == item) & (data_tst.store_nbr == store)),:])
            test_id = test.id.values

            test["wkday"] = map(lambda x: datetime.strptime(x,"%Y-%m-%d").weekday(), test["date"])
            test.loc[test.wkday > 4,:]["wkday"] = "W"
            test.loc[test.wkday <= 4,:]["wkday"] = "H"
            test["wkday"] = test["wkday"].astype('category')

            test.loc[test.day < 0,"day"] = test.loc[test.day < 0,"day"] + 7
            test.loc[test.day == 0,"day"] = 7
            test.loc[test.day < 4,"day"] = abs(test.loc[test.day < 4,"day"] - 7)

            test["store_nbr"] = test["store_nbr"].astype('category')
            test["station_nbr"] = test["station_nbr"].astype('category')

            test["TS"] = test["TS"].astype('category')
            test["RA"] = test["RA"].astype('category')
            test["DZ"] = test["DZ"].astype('category')
            test["SN"] = test["SN"].astype('category')
            test["FG"] = test["FG"].astype('category')
            test["FG."] = test["FG."].astype('category')
            test["BR"] = test["BR"].astype('category')
            test["HZ"] = test["HZ"].astype('category')
            test["FZ"] = test["FZ"].astype('category')

            test["GR"] = test["GR"].astype('category')
            test["SG"] = test["SG"].astype('category')
            test["GS"] = test["GS"].astype('category')
            test["PL"] = test["PL"].astype('category')
            test["FU"] = test["FU"].astype('category')
            test["DU"] = test["DU"].astype('category')
            test["SS"] = test["SS"].astype('category')
            test["SQ"] = test["SQ"].astype('category')
            test["MI"] = test["MI"].astype('category')
            test["PR"] = test["PR"].astype('category')
            test["BC"] = test["BC"].astype('category')
            test["BL"] = test["BL"].astype('category')

            test = test.drop(["item_nbr", "id", "date", "store_nbr",
                                "TS", "SQ", "SS"],axis=1)

            model = GradientBoostingRegressor(n_estimators=1400, max_depth=7, loss='lad', learning_rate=0.001)
            model.fit(train,units)
            output = np.array(model.predict(test).round())

            logger.info("Completed Training")
            output = output.clip(0)

            out = pd.DataFrame()
            out["id"] = test_id
            out["units"] = output
            pred = pred.append(out,ignore_index=True)
            del(out)

    pred.columns = ["id","units"]
    pred.to_csv("results.csv",index=False)

if __name__ == "__main__":
    trainModel("none")