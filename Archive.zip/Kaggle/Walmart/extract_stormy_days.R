setwd("~/Documents/Models/Kaggle/Walmart")
data <- read.csv('train_enh.csv',header=T)

data<-data[order(data$store_nbr,data$item_nbr,data$date),]
row <- which(((data$snowfall > 2) | (data$preciptotal > 1)))

data_ext <- lapply(row,function(x) data[((as.numeric(x) - 3) : (as.numeric(x) + 3)),])

data_new <- do.call("rbind",data_ext)


write.csv(data_new, "train_ext.csv", row.names=F)
rm(data,row,data_ext)