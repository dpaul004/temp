setwd("~/Documents/Models/Kaggle/Walmart")
rm(list=ls())
parm <- c('test')

if (parm == 'train') {
  data <- read.csv('train-3.csv',header=T)
} else {
  data <- read.csv('test.csv',header=T)
}

data<-data[order(data$store_nbr,data$item_nbr,data$date),]

if (parm == 'execute') {
  data$tot_sales<-"NA"
  
  store_unq <- unique(data$store_nbr)
  
  for (store in store_unq) {
    print(c("Store #:",store),quote=F)
    item_unq <- unique(data[which(data$store_nbr == store),]$item_nbr)
    for (item in item_unq) {
      d_units<-(data[which(data$store_nbr == store & data$item_nbr == item),]$units)
      t_units<-as.numeric(d_units)
      t_units[4:(length(t_units) - 3)]<-as.numeric(lapply((4:(length(d_units)-3)),function(x) sum(as.numeric(d_units[(x-3):(x+3)]))))
      data[which(data$store_nbr == store & data$item_nbr == item),]$tot_sales <- t_units
    }
  }
}

key <- read.csv('key.csv',header=T)
data<-merge(data,key,by="store_nbr")

weather<-read.csv('weather_enh.csv',header=T)
weather$day <- 0
weather <- weather[order(weather$station_nbr,weather$date),]
row_w <- which(((weather$snowfall > 2) | (weather$preciptotal > 1)))

for (i in row_w) {
  weather[(i-3):(i+3),]$day <- -3:3
}

data<-merge(data,weather,by=c('station_nbr','date'))

if (parm=="test") {
  data$id<-paste(data$store_nbr,data$item_nbr,data$date,sep='_')
}

if (parm ==  'train') {
  write.csv(data, "train_enh.csv", row.names=F)
} else {
  write.csv(data, "test_enh.csv", row.names=F)
}