setwd("./")
library(h2o)
localH2O <- h2o.init(nthread=-1,max_mem_size="4G")

train <- read.csv("train_ext.csv")
train <- train[,-2]
train$station_nbr <- as.factor(train$station_nbr)
train$store_nbr <- as.factor(train$store_nbr)
train$item_nbr <- as.factor(train$item_nbr)
train$TS <- as.factor(train$TS)
train$GR <- as.factor(train$GR)
train$RA <- as.factor(train$RA)
train$DZ <- as.factor(train$DZ)
train$SN <- as.factor(train$SN)
train$SG <- as.factor(train$SG)
train$GS <- as.factor(train$GS)
train$PL <- as.factor(train$PL)
train$FG <- as.factor(train$FG)
train$FG. <- as.factor(train$FG.)
train$BR <- as.factor(train$BR)
train$HZ <- as.factor(train$HZ)
train$FU <- as.factor(train$FU)
train$DU <- as.factor(train$DU)
train$SS <- as.factor(train$SS)
train$SQ <- as.factor(train$SQ)
train$FZ <- as.factor(train$FZ)
train$MI <- as.factor(train$MI)
train$PR <- as.factor(train$PR)
train$BC <- as.factor(train$BC)
train$BL <- as.factor(train$BL)

test <- read.csv("test_enh.csv")
test <- test[,-2]
test$station_nbr <- as.factor(test$station_nbr)
test$store_nbr <- as.factor(test$store_nbr)
test$item_nbr <- as.factor(test$item_nbr)
test$TS <- as.factor(test$TS)
test$GR <- as.factor(test$GR)
test$RA <- as.factor(test$RA)
test$DZ <- as.factor(test$DZ)
test$SN <- as.factor(test$SN)
test$SG <- as.factor(test$SG)
test$GS <- as.factor(test$GS)
test$PL <- as.factor(test$PL)
test$FG <- as.factor(test$FG)
test$FG. <- as.factor(test$FG.)
test$BR <- as.factor(test$BR)
test$HZ <- as.factor(test$HZ)
test$FU <- as.factor(test$FU)
test$DU <- as.factor(test$DU)
test$SS <- as.factor(test$SS)
test$SQ <- as.factor(test$SQ)
test$FZ <- as.factor(test$FZ)
test$MI <- as.factor(test$MI)
test$PR <- as.factor(test$PR)
test$BC <- as.factor(test$BC)
test$BL <- as.factor(test$BL)

subm <- vector('list',111)
k <- 1

trn_data <- split(train,train$item_nbr)
tst_data <- split(test,test$item_nbr)

rm(train,test)

for (i in names(trn_data)) {
  print(c("item #: ",i),quote=F)
  trn <- trn_data[[i]]
  trn <- trn[,-which(names(trn) == 'item_nbr')]
  train.hex <- as.h2o(localH2O,trn)
  predictors <- which(names(train.hex) != "units")
  response <- which(names(train.hex) == "units")
  
  tst <- tst_data[[i]]
  tst <- tst[,-which(names(tst) == 'item_nbr')]
  test.hex <- as.h2o(localH2O,tst[,1:(ncol(tst)-1)])
  
  sub_df <- as.data.frame(tst$id)
  sub_df$units <- 0
  
  for(j in 1:1){
    print(j)
    
    if (sum((train.hex[,response]) != 0) == 0) {break}
    
    model <- h2o.deeplearning(x=predictors,
                              y=response,
                              data=train.hex,
                              classification=F,
                              activation="RectifierWithDropout",
                              hidden=c(512,256,128),
                              hidden_dropout_ratio=c(0.5,0.5,0.5),
                              input_dropout_ratio=0.05,
                              epochs=10,
                              l1=1e-5,
                              l2=1e-5,
                              rho=0.99,
                              epsilon=1e-8,
                              train_samples_per_iteration=500,
                              max_w2=10,
                              seed=1)
    sub_df$units <- sub_df$units + as.data.frame(h2o.predict(model,test.hex))
    print(j)
  }
  sub_df$units <- round(sub_df$units/1)
  subm[[k]] <- sub_df
  k <- k+1
}

for (i in (1:111)) {
  names(subm[[i]]) <- c('id','units')
  subm[[i]][,2] <- unclass(subm[[i]][,2])
}

submission <- do.call('rbind',subm)
names(submission) <- c('id','units')

write.csv(submission,file="submission.csv",row.names=FALSE)     