## This program will clean the weather data provided in the Walmart Sales Kaggle competition. For each field that 
## is marked with M, it imputes the value with the mean of the previous 4 values of the same field for the same station.

setwd("~/Documents/Models/Kaggle/Walmart")
data <- read.csv('weather.csv',header=T,colClasses="character")
data <- data[order(data$station_nbr,data$date),]

data[which((as.character(data$tmax) != 'M') & (as.character(data$tmin) != 'M') 
           & (as.character(data$tavg) == 'M')),c('tavg')] <-
  rowMeans(apply((data[which((as.character(data$tmax) != 'M') & (as.character(data$tmin) != 'M')
                             & (as.character(data$tavg) == 'M')),][,c('tmax','tmin')]),2,as.numeric))

l <- unique(data$station_nbr)

for (itm in l) {
  print(c('item:',itm),quote=F)
  row_nm <- as.numeric(row.names(data[which(((as.character(data$tmax) == 'M') | 
                                              (as.character(data$tmin) == 'M')) & (as.character(data$tavg) == 'M'
                                                    & data$station_nbr == itm)),]))
  for (r in row_nm) {
    data[r,c('tavg')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('tavg')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$dewpoint) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('dewpoint')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('dewpoint')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$wetbulb) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('wetbulb')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('wetbulb')]))
  }
  
  row_nm <- as.numeric(row.names(data[which((as.character(data$preciptotal) == '  T') | 
                                              (as.character(data$preciptotal) == 'M') & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('preciptotal')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('preciptotal')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$stnpressure) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('stnpressure')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('stnpressure')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$sealevel) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('sealevel')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('sealevel')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$avgspeed) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('avgspeed')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('avgspeed')]))
  }
  
  row_nm <- as.numeric(row.names(data[which(as.character(data$resultdir) == 'M' & data$station_nbr == itm),]))
  for (r in row_nm) {
    data[r,c('resultdir')] <- mean(as.numeric(data[((r-4) : (r - 1)),c('resultdir')]))
  }
}  

data[data$tmax == "M",]$tmax <- data[data$tmax == "M",]$tavg
data[data$tmin == "M",]$tmin <- data[data$tmin == "M",]$tavg

data[which(as.character(data$snowfall) == 'M'),]$snowfall <- 0.00
data[which(as.character(data$snowfall) == '  T'),]$snowfall <- 0.00
data[which(as.character(data$preciptotal) == '  T'),]$preciptotal <- 0.00


t<-table(data$codesum)
c_df<-data.frame(names(t))
names(c_df) <- c('codesum')

c_df[,c('+FC')]<-0
c_df[,c('FC')]<-0
c_df[,c('TS')]<-0
c_df[,c('GR')]<-0
c_df[,c('RA')]<-0
c_df[,c('DZ')]<-0
c_df[,c('SN')]<-0
c_df[,c('SG')]<-0
c_df[,c('GS')]<-0
c_df[,c('PL')]<-0
c_df[,c('IC')]<-0
c_df[,c('FG')]<-0
c_df[,c('FG+')]<-0
c_df[,c('BR')]<-0
c_df[,c('HZ')]<-0
c_df[,c('FU')]<-0
c_df[,c('VA')]<-0
c_df[,c('DU')]<-0
c_df[,c('DS')]<-0
c_df[,c('PO')]<-0
c_df[,c('SA')]<-0
c_df[,c('SS')]<-0
c_df[,c('PY')]<-0
c_df[,c('SQ')]<-0
c_df[,c('DR')]<-0
c_df[,c('SH')]<-0
c_df[,c('FZ')]<-0
c_df[,c('MI')]<-0
c_df[,c('PR')]<-0
c_df[,c('BC')]<-0
c_df[,c('BL')]<-0


c_df[grep("FC",c_df[,1],fixed=T),c('FC')] <- 1
c_df[grep("TS",c_df[,1],fixed=T),c('TS')] <- 1
c_df[grep("GR",c_df[,1],fixed=T),c('GR')] <- 1
c_df[grep("RA",c_df[,1],fixed=T),c('RA')] <- 1
c_df[grep("DZ",c_df[,1],fixed=T),c('DZ')] <- 1
c_df[grep("SN",c_df[,1],fixed=T),c('SN')] <- 1
c_df[grep("SG",c_df[,1],fixed=T),c('SG')] <- 1
c_df[grep("GS",c_df[,1],fixed=T),c('GS')] <- 1
c_df[grep("PL",c_df[,1],fixed=T),c('PL')] <- 1
c_df[grep("IC",c_df[,1],fixed=T),c('IC')] <- 1
c_df[grep("FG",c_df[,1],fixed=T),c('FG')] <- 1
c_df[grep("FG+",c_df[,1],fixed=T),c('FG+')] <- 1
c_df[grep("BR",c_df[,1],fixed=T),c('BR')] <- 1
c_df[grep("HZ",c_df[,1],fixed=T),c('HZ')] <- 1
c_df[grep("FU",c_df[,1],fixed=T),c('FU')] <- 1
c_df[grep("VA",c_df[,1],fixed=T),c('VA')] <- 1
c_df[grep("DU",c_df[,1],fixed=T),c('DU')] <- 1
c_df[grep("DS",c_df[,1],fixed=T),c('DS')] <- 1
c_df[grep("PO",c_df[,1],fixed=T),c('PO')] <- 1
c_df[grep("SA",c_df[,1],fixed=T),c('SA')] <- 1
c_df[grep("SS",c_df[,1],fixed=T),c('SS')] <- 1
c_df[grep("PY",c_df[,1],fixed=T),c('PY')] <- 1
c_df[grep("SQ",c_df[,1],fixed=T),c('SQ')] <- 1
c_df[grep("DR",c_df[,1],fixed=T),c('DR')] <- 1
c_df[grep("SH",c_df[,1],fixed=T),c('SH')] <- 1
c_df[grep("FZ",c_df[,1],fixed=T),c('FZ')] <- 1
c_df[grep("MI",c_df[,1],fixed=T),c('MI')] <- 1
c_df[grep("PR",c_df[,1],fixed=T),c('PR')] <- 1
c_df[grep("BC",c_df[,1],fixed=T),c('BC')] <- 1
c_df[grep("BL",c_df[,1],fixed=T),c('BL')] <- 1

rm_cols <- which(colSums(c_df[,] != 0) == 0)
c_df<-c_df[,-rm_cols]

data <- merge(data,c_df,sort=F)
data <- data[order(data$station_nbr,data$date),]

nam<-names(data)
rm_cols <- c(which(nam=='codesum'),which(nam=='depart'),which(nam=='heat'),
             which(nam=='cool'),which(nam=='resultspeed'),which(nam=='sunrise'),which(nam=='sunset'))
data<-data[,-rm_cols]
data[is.na(data)]<-0

rm("c_df","nam","r","rm_cols","row_nm","t")

write.csv(data, "weather_cln.csv", row.names=F)