__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import preprocessing
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm):

    results = open("results.csv", "wb")
    out_file_obj = csv.writer(results)
    out_file_obj.writerow(['id','units'])

    data_trn = (pd.read_csv('train_new.csv',header=0))
    data_tst = (pd.read_csv('test_enh.csv',header=0))

    pred = pd.DataFrame()

    items = data_trn.item_nbr.unique()

    for item in items:
        train = data_trn.loc[data_trn.item_nbr == item,:]
        units = train.units.values
        train = train.drop(["station_nbr", "date", "item_nbr","units","tot_sales",
                            "TS","GR","SG","GS","PL","FG.","HZ","FU","DU",
                            "SS", "SQ", "FZ", "MI", "PR", "BC", "BL"],axis=1)

        train["store_nbr"] = train["store_nbr"].astype('category')

        test = data_tst.loc[data_tst.item_nbr == item,:]
        test_id = test.id.values
        test = test.drop(["station_nbr", "date", "item_nbr","id",
                          "TS","GR","SG","GS","PL","FG.","HZ","FU","DU",
                            "SS", "SQ", "FZ", "MI", "PR", "BC", "BL"],axis=1)

        test["store_nbr"] = test["store_nbr"].astype('category')

        ## Let's train the model,.. This model will be trained for each item
        forest = RandomForestRegressor(n_jobs=-1, n_estimators=400,max_features=20)
        forest = forest.fit(train,units)
        logger.info("Completed Training")

        ## Predict sales for each item
        output = forest.predict(test).round()

        out = pd.DataFrame(transpose([test_id,output]))
        pred = pred.append(out,ignore_index=True)


    pred.columns = ["id","units"]
    pred.to_csv("results.csv",index=False)

if __name__ == "__main__":
    trainModel("none")