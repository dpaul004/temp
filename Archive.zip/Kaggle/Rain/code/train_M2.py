__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import preprocessing
from numpy import *
import numpy as np
import csv

def trainModel(parm,forest):

    writer = csv.writer(open("results_fin.csv", "wb"), delimiter=',')

    if (parm == 'train'):
        data=(pd.read_csv('train.csv',header=0))
        labels = data.Expected.values
        data = data.drop(["Id","Expected"],axis=1)
    elif (parm=='test'):
        data=(pd.read_csv('test_cln.csv',header=0))
        id = data.Id.values
        data = data.drop(["Id"],axis=1)

    data = data.drop(['HydrometeorType'],axis=1)

    #transformer = TfidfTransformer()
    #data = transformer.fit_transform(data).toarray()

    if (parm == "train"):
        forest = RandomForestClassifier(n_jobs=-1, n_estimators=200,max_features=15)
        forest = forest.fit(data,labels)
        return forest
    elif (parm == "test"):
        output = forest.predict_proba(data)
        hdr = ['Id']
        hdr.extend(['Predicted{0}'.format(t) for t in forest.classes_])
        pred = pd.DataFrame(pd.concat([pd.DataFrame(id),pd.DataFrame(output)],axis=1))
        pred.columns = hdr

        out_row = pred.columns
        writer.writerow(out_row)

        for i in np.unique(pred.Id):
            out_row = average(pred.ix[pred.Id==i,:],axis=0)
            writer.writerow(out_row)

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('test',forest)