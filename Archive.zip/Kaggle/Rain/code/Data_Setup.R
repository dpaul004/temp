setwd("/Users/dipanjanpaul/Documents/Models/Kaggle/Rain")
data = read.csv('train_enh_f.csv',header=T)

## Find rows with missing values that require imputation
##head(trn[which(length(grep('-99900',trn$Composite)) > 0),])
##head(trn[(which(sum(grepl('nan',trn$LogWaterVolume)) > 0)),])

data<-data[(data$Expected >= 79) == F,][,]

exp_fac <- data$Expected 
data$Expected <- factor(NA,levels=rep(0:69))
for (i in rep(0:59)) {
  data$Expected[exp_fac >= i - 0.5 & exp_fac < i + 0.5 ] <- i
}

j <- 60
for (i in seq(61,80,2)) {
  data$Expected[exp_fac >= i - 1 & exp_fac < i + 1 ] <- j
  j <- j+1
}

#data$Expected <- as.numeric(data$Expected)

write.csv(data, "train.csv", row.names=F)