__author__ = 'dipanjanpaul'

## This model is training on the GBM provided by GraphLab

import pandas as pd
import graphlab as gl
##from sklearn.feature_extraction.text import TfidfTransformer
from numpy import *

def trainModel(parm,forest):

    if (parm=='train'):
        data=(pd.read_csv('train.csv',header=0))
        labels = data['Expected']
        data=data.drop(['Id','Expected'],axis=1)
    elif (parm=='test'):
        data=(pd.read_csv('test.csv',header=0))
##      data=(gl.SFrame.read_csv('test-2.csv'))
        Id = data['Id']
        data=data.drop(["Id"],axis=1)

    #x = asmatrix(data)
    #y = matrix(range(93)) + 1
    #data['feat_94'] = x*transpose(y)

    #transformer = TfidfTransformer()
    #data = transformer.fit_transform(data).toarray()

    data = data.drop(['HydrometeorType'],axis=1)

    if (parm == "train"):
        data = gl.SFrame(data)
        data['Expected'] = labels
        forest = gl.boosted_trees_classifier.create(data,target='Expected',max_iterations=400,max_depth=8,
                                                    step_size=.025,min_loss_reduction=1)
        return forest
    elif (parm == "cv"):
        output = forest.predict(data)
        cv_error = sum(map(lambda i:int(output[i]==labels[i]),range(len(output))))/float(len(labels))
        print 'Cross Validation Error %f' %cv_error
    elif (parm == "test"):
        data = gl.SFrame(data)
        output = forest.predict_topk(data,output_type='probability',k=70)
        output['Id'] = Id
        ##output['id'] = output['id'].astype(int) + 1
        output = output.unstack(['class','probability'],'probs').unpack('probs','')
        output = output.sort('Id')
        output.save("results.csv")

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('test',forest)





