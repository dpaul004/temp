setwd("/Users/dipanjanpaul/Documents/Models/Kaggle/Rain")
data = read.csv('results.csv',header=T)

fac <- factor(data$Id)

data_c <- tapply(data[2:71],fac,colMeans)
data_fin <- data.frame(unique(data$Id))
data_fin[,2:71]<-data_c


write.csv(data, "results_fin.csv", row.names=F)
             
             


