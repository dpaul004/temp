__author__ = 'dipanjanpaul'

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn import preprocessing
from numpy import *
import numpy as np
import csv
import logging
import sys

logger = logging.getLogger("example")

handler = logging.StreamHandler(sys.stderr)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s %(name)s: %(message)s'))

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

def add(prob_c,prob,i):
        if i == 0:
            prob_c[i] = prob[i]
            return prob_c[i]
        else:
            prob_c[i] = (prob[i] + add(prob_c,prob,i-1))
            return prob_c[i]

def trainModel(parm,forest):

    writer = csv.writer(open("results_fin.csv", "wb"), delimiter=',')

    if (parm == 'train'):
        data=(pd.read_csv('train_cln.csv',header=0))
        labels = data.Expected.values
        data = data.drop(["Id","Expected"],axis=1)
    elif (parm=='test'):
        data=(pd.read_csv('test_cln.csv',header=0))
        id = data.Id.values
        data = data.drop(["Id"],axis=1)

    data = data.drop(['HydrometeorType'],axis=1)

    #transformer = TfidfTransformer()
    #data = transformer.fit_transform(data).toarray()

    if (parm == "train"):
        forest = RandomForestClassifier(n_jobs=-1, n_estimators=400,max_features=15)
        forest = forest.fit(data,labels)
        logger.info("Completed Training")
        return forest
    elif (parm == "test"):
        output = forest.predict_proba(data)
        hdr = ['Id']
        hdr.extend(['Predicted{0}'.format(t) for t in forest.classes_])
        pred = array(pd.concat([pd.DataFrame(id),pd.DataFrame(output)],axis=1))

        out_row = hdr
        writer.writerow(out_row)

        print 'total rec', len(np.unique(pred[:,0]))

        for i in np.unique(pred[:,0]):
            out_row = [i]
            prob = (average(pred[where(pred[:,0]==i),1:71],axis=1)[0])
            prob_c = {}
            add(prob_c,prob,69)
            out_row.extend(prob_c.values())
            writer.writerow(out_row)
            del prob_c

            if i % 1000 == 0:
                logger.info("Completed row %d" % i)

if __name__ == "__main__":
    forest=trainModel('train',NaN)
    trainModel('test',forest)