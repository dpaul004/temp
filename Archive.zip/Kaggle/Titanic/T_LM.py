def model(mode,forest):
    if (mode=='train'):
        data=(pd.read_csv('train.csv',header=0))
    elif (mode=='test'):
        data=(pd.read_csv('test.csv',header=0))
     
    if len(data.Embarked[data.Embarked.isnull()]) > 0:
        data.Embarked[data.Embarked.isnull()]=data.Embarked.dropna().mode().values          
        
    data['Gender']=data['Sex'].map({'female':0,'male':1}).astype(int)
    Ports=list(enumerate(np.unique(data.Embarked)))
    Ports_dict={name:i for i,name in Ports}
    data.Embarked=data.Embarked.map(lambda x:Ports_dict[x]).astype(int)
    
    data.Age[data.Age.isnull()]=data.Age.dropna().median()
    
    med_fare=np.zeros(3)
    for f in range(0,3):
        med_fare[f]=data[data.Pclass==f+1]['Fare'].dropna().median()
    for i in range(0,3):
        data.loc[(data.Fare.isnull()) & (data.Pclass==f+1),'Fare']=med_fare[f]
    
    if mode == 'train':
        data=data.drop(['Name','Sex','Ticket','Cabin','PassengerId'],axis=1)

    elif mode == 'test':
        ids=data.PassengerId.values
        data=data.drop(['Name','Sex','Ticket','Cabin','PassengerId'],axis=1)
        
    data_v=data.values
    
    if (mode=='train'):
        forest=RandomForestClassifier(n_estimators=100)
        forest=forest.fit(data_v[0::,1::],data_v[0::,0])
        return forest
    elif (mode=='test'):
        output=forest.predict(data_v).astype(int)
        
        out_file=open('Titanic_out.csv','wb')
        out_file_obj=csv.writer(out_file)
        out_file_obj.writerow(['PassengerId','Survived'])
        out_file_obj.writerows(zip(ids,output))
        out_file.close()     

##    type(train_X)  
##    size(train_X), gives the total number of elements in an array

##    train_X.size gives total element in the array  
##    train_X.describe() works for DataFrames etc.
  
##    y=np.ravel(train_Y)

    
if __name__ == "__main__":
    print "DL 400 Session 2 Module 1"
    import pandas as pd
    from pandas import DataFrame
    import csv
    from sklearn import datasets, linear_model
    from sklearn.ensemble import RandomForestClassifier
    import sys
    from numpy import *
    import numpy as np
    
	
##    parm = sys.argv[1]
##    mode=parm[0:1]
    forest=model('train',NaN)
    model('test',forest)