clstregr <- function(file, iter) {
  parm <- "eda"
  if (parm == "debug") {
    library(caret)
    load(GermanCredit)
    file <- GermanCredit
    iter <- 1
  }
  
  rows <- nrow(file)
  
  spl <- rbinom(rows, 1, .9)
  train <- file[spl==1,][,]
  test <- file[spl==0,][,]
  
  for (k in 1:iter) {
    if (parm == "debug") {
      print(c("Iter #: ", k))
    }
    
    fit <- lm(Amount ~ ., data=train)
    rsq_train[k] <- 1 - sum((train$Amount - fit$fitted.values)**2)/sum((train$Amount - mean(train$Amount))**2)
    test_yhat <- predict(fit, newdata=test)
    rsq_test[k] <- 1 - sum((test$Amount - test_yhat)**2)/sum((test$Amount - mean(test$Amount))**2)
    
    
    
    file$yhat <- NA
    rsq_prev <- 0
    min_rsq_reached <- "N"
    i <- 1
    
    while (min_rsq_reached == "N") {
      file <- file[order(file$spl),]
      file$yhat <- unlist(lapply(1:pop_n, function(x) predict(lm(mpg ~ cylinders + displacement + horsepower + 
                                                                   weight + acceleration + year + origin, data=file[file$spl==x,]), 
                                                              newdata=file[file$spl==x,])))
      
      rsq <- 1 - sum((file$mpg - file$yhat)**2)/sum((file$mpg - mean(file$mpg))**2)
      
      if (i == 1) {
#        print(c('Startig R Square: ', rsq))
        rsq_monitor[k, c('rsq')] <- rsq
      }
      
      if (((rsq - rsq_prev) < tolerance) | (i > 50))  {
        min_rsq_reached == "Y"
#        print(c('Ending R Square: ', rsq))
        if (rsq > rsq_monitor[k, c('rsq')]) {
          rsq_monitor[k, c('rsq')] <- rsq
        }
        break
      }
      
      rsq_prev <- rsq
      
      x <- do.call('cbind', (lapply(1:pop_n, function(x) (file$mpg - (predict(lm(mpg ~ cylinders + displacement + horsepower + 
                                                                                   weight + acceleration + year + origin, data=file[file$spl==x,]), 
                                                                              newdata=file)))**2)))
      
      file$spl <- apply(x, 1, function(x) which(x == min(x)))
      
      i <- i + 1
    }
    
    df[1:nrow(file),k] <- file$spl
    
  }

  print(c('Best R Square: ', max(rsq_monitor$rsq)))
  file$spl <- (df[,which(rsq_monitor$rsq == max(rsq_monitor$rsq))])
  return(file)
}

library(caret)
data(GermanCredit)
parm <- "none"

init_model <- lm(Amount ~ ., data=GermanCredit)


if (parm == "eda") {
  head(Auto)
  summary(Auto)
}

out <- list(10)
for (j in 1:10) {
#  print(c('Nr. of splits: ', j))
  out[[j]] <- multipopl(Auto, j, 0.001, 50, 12345)
}


