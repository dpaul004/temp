library(boot)
set.seed(3)

train = sample(392,196)

lm.fit <- lm(mpg ~ poly(horsepower,1), data=Auto, subset=train)
mean((mpg - predict(lm.fit, newdata=Auto))[-train]**2)

lm.fit2 <- lm(mpg ~ poly(horsepower,2), data=Auto, subset=train)
mean((mpg - predict(lm.fit2, newdata=Auto))[-train]**2)

lm.fit3 <- lm(mpg ~ poly(horsepower,3), data=Auto, subset=train)
mean((mpg - predict(lm.fit3, newdata=Auto))[-train]**2)

cv.err <- rep(0,5)
for (i in 1:5) {
  glm.fit <- glm(mpg ~ poly(horsepower, i), data=Auto)
  cv.err[i] <- cv.glm(Auto, glm.fit)$delta[1]
}
cv.err

set.seed(17)
cv.err.10 <- rep(0,10)
for (i in 1:10) {
  glm.fit <- glm(mpg ~ poly(horsepower, i), data=Auto)
  cv.err.10[i] <- cv.glm(Auto, glm.fit, K=5)$delta[1]
}
cv.err.10

boot_fn <- function(data, index) {
#  return(coef(lm(mpg ~ horsepower + I(horsepower**2), data=data, subset=index)))
  return(coef(lm(mpg ~ poly(horsepower, 2, raw=T), data=data, subset=index)))
}
set.seed(2)
boot(Auto, boot_fn, R=1000)


alpha_fn <- function(data, index) {
  X <- data$X[index]
  Y <- data$Y[index]
  return ((var(Y) - cov(X,Y))/(var(X) + var(Y) - 2*cov(X,Y)))
}

alpha_fn(Portfolio, 1:100)

set.seed(1)
boot(Portfolio, alpha_fn, R=1000)