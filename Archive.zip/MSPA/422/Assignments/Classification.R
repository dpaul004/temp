library(ISLR)
library(leaps)
library(splines)
library(gam)

cor(Smarket[,-9])
attach(Smarket)

glm.fit <- glm(Direction ~ Lag1 + Lag2 + Lag3 + Lag4 + Lag5 + Volume, data=Smarket, family="binomial")
summary(glm.fit)
coef(glm.fit)

glm.prob <- predict(glm.fit, type="response")
head(glm.prob)

contrasts(Direction)
glm.pred <- rep("Down", 1250)
glm.pred[glm.prob > .5] <- "Up"

table(glm.pred, Direction)
mean(glm.pred == Direction)

train <- (Year < 2005)
Smarket.2005 <- Smarket[!train,]
dim(Smarket.2005)

Direction.2005 <- Direction[!train]

glm.fit <- glm(Direction ~ Lag1 + Lag2 + Lag3 + Lag4 + Lag5 + Volume, data=Smarket, subset=train, family="binomial")
glm.prob <- predict(glm.fit, newdata=Smarket.2005, type="response")
glm.pred <- rep("Down", 252)
glm.pred[glm.prob > .5] <- "Up"
table(glm.pred, Direction.2005)
mean(glm.pred == Direction.2005)
mean(glm.pred != Direction.2005)

glm.fit <- glm(Direction ~ Lag1 + Lag2, data=Smarket, subset=train, family="binomial")
glm.prob <- predict(glm.fit, newdata=Smarket.2005, type="response")
glm.pred <- rep("Down", 252)
glm.pred[glm.prob > .5] <- "Up"
table(glm.pred, Direction.2005)
mean(glm.pred == Direction.2005)
mean(glm.pred != Direction.2005)

predict(glm.fit, newdata=data.frame(Lag1=c(1.2, 1.5), Lag2=c(1.1, -0.8)), type="response")

library(MASS)
lda.fit <- lda(Direction ~ Lag1 + Lag2, data=Smarket, subset=train)
lda.pred <- predict(lda.fit, newdata=Smarket.2005)
mean(lda.pred$class == Direction.2005)

sum(lda.pred$posterior[,1] >= .5)
sum(lda.pred$posterior[,1] < .5)

qda.fit <- qda(Direction ~ Lag1 + Lag2, data=Smarket, subset=train)
qda.pred <- predict(qda.fit, newdata=Smarket.2005)
mean(qda.pred$class == Direction.2005)

sum(qda.pred$posterior[,1] >= .5)
sum(qda.pred$posterior[,1] < .5)

library(class)

train.X <- cbind(Lag1, Lag2)[train,]
test.X <- cbind(Lag1, Lag2)[!train,]
train.Direction <- Direction[train]

set.seed(1)
knn.pred <- knn(train.X, test.X, train.Direction, k=3)
table(knn.pred, Direction.2005)


dim(Caravan)

attach(Caravan)
standardized.X=scale(Caravan [,-86])

test =1:1000
train.X=standardized.X[-test ,]
test.X=standardized.X[test ,]
train.Y=Purchase [-test]
test.Y=Purchase [test]
set . seed (1)
knn.pred=knn(train.X,test.X,train.Y,k=1)



lda.fit=lda(Purchase~.,data=Caravan,subset=-test)

lda.probs=predict(lda.fit, Caravan[test,])$posterior[,2]

lda.pred=rep("No",1000)

lda.pred[lda.probs>.25]="Yes"

table(lda.pred,test.Y)

