mutate <- function(file, iter) {
  parm <- "eda"
  if (parm == "debug") {
    library(caret)
    data(GermanCredit)
    file <- GermanCredit
    iter <- 2
  }
  
  rows <- nrow(file)
  
  rsq_train <- rep(0,iter)
  rsq_test <- rep(0,iter)
  coeff_df <- data.frame()
  
  for (k in 1:iter) {
    if (parm == "debug") {
      print(c("Iter #: ", k))
    }
    
    spl <- rbinom(rows, 1, .8)
    train <- file[spl==1,][,]
    test <- file[spl==0,][,]
    
#    feature.names <- names(train)[3:(ncol(train))]
#    for (f in feature.names) {
#      if (class(train[[f]])=="factor") {
#        levels <- unique(c(as.character(train[[f]]), as.character(test[[f]])))
#        train[[f]] <- as.integer(factor(train[[f]], levels=levels))
#        test[[f]]  <- as.integer(factor(test[[f]],  levels=levels))
#      }
#    }
    
    fit <- lm(Amount ~ Duration + InstallmentRatePercentage + 
                NumberPeopleMaintenance + Telephone + Class + CheckingAccountStatus.lt.0 + 
                CheckingAccountStatus.gt.200 + CreditHistory.NoCredit.AllPaid + 
                Purpose.NewCar + Purpose.Furniture.Equipment + Purpose.Radio.Television + 
                Purpose.DomesticAppliance + Purpose.Education + Purpose.Retraining + 
                Purpose.Business + SavingsAccountBonds.lt.100 + SavingsAccountBonds.100.to.500 + 
                SavingsAccountBonds.500.to.1000 + EmploymentDuration.gt.7 + 
                Personal.Male.Single + Property.RealEstate + Property.Insurance + 
                Property.CarOther + Job.UnemployedUnskilled + Job.UnskilledResident + 
                Job.SkilledEmployee, data=train)

    coeff_df[1:27,k] <- coefficients(fit)

    rsq_train[k] <- 1 - sum((train$Amount - fit$fitted.values)**2)/sum((train$Amount - mean(train$Amount))**2)

    test_yhat <- predict(fit, newdata=test)
    rsq_test[k] <- 1 - sum((test$Amount - test_yhat)**2)/sum((test$Amount - mean(test$Amount))**2)
  }  
   
  coeff_df <- as.data.frame(t(coeff_df))
  names(coeff_df) <- names(coefficients(fit))
  
  return(list(rsq_train, rsq_test, coeff_df))
}

# Program Flow Starts Here
library(caret)
data(GermanCredit)
parm <- "none"

if (parm=="eda") {
  init_model <- lm(Amount ~ ., data=GermanCredit)
  step(init_model, direction="both")
}

out_ls <- mutate(GermanCredit, 1000)

coeff_mean <- apply(out_ls[[3]], 2, mean)
coeff_sd <- apply(out_ls[[3]], 2, sd)
coeff_full <- coefficients(lm(Amount ~ Duration + InstallmentRatePercentage + 
                                NumberPeopleMaintenance + Telephone + Class + CheckingAccountStatus.lt.0 + 
                                CheckingAccountStatus.gt.200 + CreditHistory.NoCredit.AllPaid + 
                                Purpose.NewCar + Purpose.Furniture.Equipment + Purpose.Radio.Television + 
                                Purpose.DomesticAppliance + Purpose.Education + Purpose.Retraining + 
                                Purpose.Business + SavingsAccountBonds.lt.100 + SavingsAccountBonds.100.to.500 + 
                                SavingsAccountBonds.500.to.1000 + EmploymentDuration.gt.7 + 
                                Personal.Male.Single + Property.RealEstate + Property.Insurance + 
                                Property.CarOther + Job.UnemployedUnskilled + Job.UnskilledResident + 
                                Job.SkilledEmployee, data=GermanCredit))
op <-par()
par(mfrow=c(1,3))
hist(out_ls[[1]], breaks=50, main="Train R Sq", col="lightblue")
hist(out_ls[[2]], breaks=50, main="Test R Sq", col="lightgreen")
hist(out_ls[[1]] - out_ls[[2]], breaks=50, main="Diff in R Sq", col="lightyellow")
par(op)

barplot((t(data.frame(coeff_full,coeff_mean))), col=c('red', 'green'), beside=T, las=2, cex.axis=0.6)

print(c("Train RSQ - Test RSQ: ", round(mean(out_ls[[1]] - mean(out_ls[[2]])),2)), sep="", quote=F)

# The following dataframe contains the mean of the coefficients and their SD from the mutat function. 
# The 3rd column shows the coefficients from running the model once on the full data
data.frame(coeff_mean, coeff_sd, coeff_full)