library(ISLR)
library(leaps)
data(Hitters)
Hitters <- na.omit(Hitters)

x <- model.matrix(Salary ~ ., data=Hitters)[,-1]
y <- Hitters$Salary

library(glmnet)
grid <- 10^seq(10, -2, length=100)
ridge.mod <- glmnet(x,y,alpha=0,lambda=grid)
plot(ridge.mod, xvar="lambda", label=T)

ridge.mod$lambda[50]
sqrt(sum(coef(ridge.mod)[-1,50]**2))

predict(ridge.mod, s=50, type="coefficients")[1:20]

set.seed(1)
train <- sample(1:nrow(x), nrow(x)/2)
test <- -train
y.test <- y[test]

# Ridge
ridge.mod <- glmnet(x[train,],y[train],alpha=0,lambda=grid, thresh=1e-12)
pred <- predict(ridge.mod, s=50, newx=x[test,])
mean((pred - y.test)**2)

pred <- predict(ridge.mod, s=0, newx=x[test,], exact=T)
mean((pred - y.test)**2)

set.seed(1)
cv.out <- cv.glmnet(x[train,],y[train],alpha=0)
plot(cv.out)
bestlam <- cv.out$lambda.min
maxlam <- cv.out$lambda.1se

pred <- predict(ridge.mod, s=maxlam, newx=x[test,])
mean((pred - y.test)**2)

out <- glmnet(x, y, alpha=0)
predict(out, s=bestlam, type="coefficients")[1:20]

## Lasso
lasso.mod <- glmnet(x[train,],y[train],alpha=1,lambda=grid)
plot(lasso.mod)

set.seed(1)
cv.out <- cv.glmnet(x[train,],y[train],alpha=1)
plot(cv.out)
bestlam <- cv.out$lambda.min
maxlam <- cv.out$lambda.1se

pred <- predict(lasso.mod, s=maxlam, newx=x[test,])
mean((pred - y.test)**2)

out <- glmnet(x, y, alpha=1)
predict(out, s=bestlam, type="coefficients")[1:20]
predict(out, s=maxlam, type="coefficients")[1:20]
