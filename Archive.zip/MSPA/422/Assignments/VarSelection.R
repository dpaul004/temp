library(ISLR)
library(leaps)
data(Hitters)

Hitters <- na.omit(Hitters)
model <- regsubsets(Salary ~ ., data=Hitters, nvmax=19)
summary(model)

opar <- par()
par(mfrow=c(1,2))
plot(summary(model)$rsq, type="l")
dm <- which.max(summary(model)$rsq)
points(dm, summary(model)$rsq[dm], col="red", pch=20)
plot(summary(model)$adjr2, type="l")
dm <- which.max(summary(model)$adjr2)
points(dm, summary(model)$adjr2[dm], col="red", pch=20)
par(opar)


plot(model, scale="r2")
plot(model, scale='adjr2')
plot(model, scale="Cp")
plot(model, scale="bic")

coef(model, 6)

model_fwd <- regsubsets(Salary ~ ., data=Hitters, nvmax=19, method="forward")
summary(model_fwd)
model_bwd <- regsubsets(Salary ~ ., data=Hitters, nvmax=19, method="backward")
summary(model_bwd)
model_seq <- regsubsets(Salary ~ ., data=Hitters, nvmax=19, method="seqrep")
summary(model_seq)

set.seed(1)
train <- sample(c(TRUE, FALSE), nrow(Hitters), rep=TRUE)
test <- (!train)

model.best <- regsubsets(Salary ~ ., data=Hitters[train,], nvmax=19)
test.mat <- model.matrix(Salary ~ ., data=Hitters[test,])

val.error <- rep(NA, 19)

for (i in 1:19) {
  coeff_i <- coef(model.best, id=i)
  pred <- test.mat[, names(coeff_i)] %*% coeff_i
  val.error[i] <- mean((Hitters$Salary[test] - pred)**2)
}

predict.regsubsets <- function(model, newdata, id) {
  form <- as.formula(model$call[[2]])
  mat <- model.matrix(form, newdata)
  coeff_i <- coef(model, id=i)
  mat[, names(coeff_i)] %*% coeff_i
}

k=5
set.seed(1)
folds <- sample(1:k, nrow(Hitters), rep=TRUE)
cv.errors <- matrix(NA, k, 19, dimnames=list(NULL, paste(1:19)))

for (j in 1:k) {
  best.folds <- regsubsets(Salary ~ ., data=Hitters[folds !=j, ], nvmax=19)
  
  for (i in 1:19) {
    pred <- predict.regsubsets(best.folds, Hitters[folds == j,], i)
    cv.errors[j,i] <- mean((Hitters$Salary[folds == j] - pred)**2)
  }
}

mean.cv.errors <- apply(cv.errors, 2, mean)
plot(mean.cv.errors, type="l")
best_m <- which.min(mean.cv.errors)

best_model <- regsubsets(Salary ~ ., data=Hitters, nvmax=19)
coef(best_model, id=11)
