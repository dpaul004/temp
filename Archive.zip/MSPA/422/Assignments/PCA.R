library(ISLR)
library(pls)
data(Hitters)

Hitters <- na.omit(Hitters)

set.seed(2)
pcr.mod <- pcr(Salary ~ ., data=Hitters, scale=T, validation="CV")

summary(pcr.mod)
validationplot(pcr.mod, val.type="MSEP")
MSEP(pcr.mod)

set.seed(1)
train <- sample(1:nrow(Hitters), nrow(Hitters)/2)
test <- -train
pcr.mod <- pcr(Salary ~ ., data=Hitters, subset=train, scale=T, validation="CV")

pcr.pred <- predict(pcr.mod, Hitters[test,], ncomp=7)
mean((Hitters$Salary[test] - pcr.pred)**2)

pcr_final <- (pcr(Salary ~ ., data=Hitters, scale=T, ncomp=7))
plot(pcr_final, ncomp=1:7)

## PLS
set.seed(1)
pls.mod <- plsr(Salary ~ ., data=Hitters, scale=T, validation="CV")

summary(pls.mod)
validationplot(pls.mod, val.type="MSEP")

set.seed(1)
train <- sample(1:nrow(Hitters), nrow(Hitters)/2)
test <- -train
set.seed(1)
pls.mod <- plsr(Salary ~ ., data=Hitters, subset=train, scale=TRUE, validation="CV")

pls.pred <- predict(pls.mod, Hitters[test,], ncomp=3)
mean((Hitters$Salary[test] - pls.pred)**2)

summary(plsr(Salary ~ ., data=Hitters, scale=T, ncomp=2))

