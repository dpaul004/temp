from matplotlib.pyplot import *
import numpy
from numpy import linspace
from numpy import *

def MatInv(parm):
    
    if (parm=='na'):
        x1=[1,0,1]
        y1=[2,-2,1]
        z1=[3,0,0]
    else:
        x1=map(float,array(parm.split(',')[0:3]))
        y1=map(float,array(parm.split(',')[3:6]))
        z1=map(float,array(parm.split(',')[6:9]))
    
    m=matrix([x1,y1,z1])
       
    print 'Inverse of matrix is'
    print '\n'
    print np.linalg.inv(m)  
    print m*np.linalg.inv(m)  
    return np.linalg.inv(m)

def SolveLM(parm):
    if (parm=='na'):
        x1=[3.0,1.0,2.0]
        y1=[3.0,2.0,1.0]
        z1=[2.0,1.0,2.0]
        
        Y=matrix([100.0,110.0,90.0])
    else:
        x1=map(float,array(parm.split(',')[0:3]))
        y1=map(float,array(parm.split(',')[3:6]))
        z1=map(float,array(parm.split(',')[6:9]))
    
    m=matrix([x1,y1,z1])
    
    res=map(round,np.linalg.solve(m,transpose(Y)))
    print np.allclose(np.dot(m,res),Y)
    print res
##    print ('A total of %d Type 1 and %d Type 2 and %d Type 3 cakes are made') %(res[0,0], res[1,0], res[2,0])
    
        
if __name__ == "__main__":
    import sys

    parm = sys.argv[1]
    mode=parm[0:1]
	
    if mode == "1":
        MatInv(parm[1:len(parm)])
    elif mode == "2":
    	SolveLM(parm[1:len(parm)])
    else:
    	print 'Bad Choice'
