def SlopeCal(parm):
##    from matplotlib.pyplot import *
##    import numpy
##    from numpy import linspace
    
    if (parm=='na'):
        x1=5.0
        y1=4.0
        x2=-10.0
        y2=-2.0
    else:
        x1=float(parm.split(',')[0])
        y1=float(parm.split(',')[1])
        x2=float(parm.split(',')[2])
        y2=float(parm.split(',')[3])
    
    slope=(y2-y1)/(x2-x1)
    
    print ('\nSlope Line %s') %slope
    
    return slope
    
def yCal(parm):
##    from matplotlib.pyplot import *
##    import numpy
##    from numpy import linspace
    
    x1=5.0
    y1=4.0
    x2=-10.0
    y2=-2.0
    
    slope=SlopeCal(str(x1)+','+str(y1)+','+str(x2)+','+str(y2))
    
    y=y1+slope*(float(parm)-x1)
        
    print 'The value of y when x is ' + str(parm) + ' is ' + str(y)
    
def WaterMelonPlot():
##    from matplotlib.pyplot import *
##    import numpy
##    from numpy import linspace
    
    x=linspace(1,10,25)
    y=9-(0.75*x)
    z=(0.75*x)
    
    figure()
    plot(x,y)
    plot(x,z)
    legend (('cost','revenue'),loc=2)
    title ('Breakeven Analysis')
    show()
    
def DeathRate(parm):
    
    x=array([10,20,30,40,50,60,70,80,90,100])
    y=array([84.4,71.2,80.5,73.4,60.3,52.1,56.2,46.5,36.9,34.0])
   
    m=(len(x)*sum(x*y) - sum(x)*sum(y))/(len(x)*(sum(x**2)) - (sum(x))**2)
    b=(sum(y) - m*sum(x))/len(x)
    
    x1 = (float(parm) - b)/m
    
    print 'The answer is: ', int(round(x1 + 1900))
    
if __name__ == "__main__":
    print "DL 400 Session 1 Module 2"
    import sys
    from matplotlib.pyplot import *
    import numpy
    from numpy import linspace
    from numpy import *

	
    parm = sys.argv[1]
    mode=parm[0:1]
	
    if mode == "1":
        SlopeCal(parm[1:len(parm)])
    elif mode == "2":
    	yCal(parm[1:len(parm)])
    elif mode == "3":
    	WaterMelonPlot()
    elif mode == "4":
    	DeathRate(parm[1:len(parm)])
    else:
    	print 'Bad Choice'
