import pandas as pd
from pandas import DataFrame
import csv
from sklearn import datasets, linear_model
import sys
from numpy import *
import numpy as np
import random
import mmap

def r_read(parm):
    if ((parm  == 'na') | (parm > 1)):
        parm=0.01
    else:
        parm=int(parm)
        
    with open("test.csv", "rb") as source:
        lines = [line for line in source]
        
    random_choice = random.sample(lines, int(parm*int(size(lines))))
        
    with open("out.csv", "wb") as out:
        out.write("\n".join(random_choice))    
        
def r_read_rand(parm):
    if ((parm  == 'na') | (parm > 1)):
        parm=0.01
    else:
        parm=int(parm)

    with open('test.csv') as f:        
        f_len=sum(1 for _ in f)
        
    f.close() 
    
    out = open("out.csv", "wb")   
    
    r_s = sort(random.sample(range(1,f_len),int(parm*f_len)))
        
    with open("test.csv", "r+b") as infile:
        inf_map=mmap.mmap(infile.fileno(),0)
        
        for i in range(0,len(r_s)):
            inf_map.seek(r_s[i])
            out.write(inf_map.readline())
          
    out.close()  
    infile.close()
    inf_map.close()  

if __name__ == "__main__":    
	
##    parm = sys.argv[1]
##    mode=parm[0:1]
    r_read_rand(10000)
    