mem={0:0,1:1}

def fib(n):
    if (n==0):
        return 0
    elif (n==1):
        return 1
    else:
        if n in mem:
            return mem[n]
        else:
            mem[n] = (fib(n-1) + fib(n-2))
            return mem[n]

if __name__ == "__main__":
    import sys
    print fib(int(sys.argv[1]))
