__author__ = 'dipanjanpaul'

import csv
import numpy as np

def extract_auth(infile, outfile):
    infile = csv.reader(open(infile,"r"))
    outfile = csv.writer(open(outfile, "w"))

    outfile.writerow(['Time', 'SrcMC', 'SrcDom', 'DstMC', 'DstDom', 'SrcPort', 'DstPort', 'AuthType',
                      'LogonType', 'AuthOrnt', 'Status'])

    for i, row in enumerate(infile):
        srcusr = np.array(row[1].split("@"))[0]
        srcdom = np.array(row[1].split("@"))[1]

        dstusr = np.array(row[2].split("@"))[0]
        dstdom = np.array(row[2].split("@"))[1]
        if ((srcusr == "ANONYMOUS LOGON") | (srcusr == "NETWORK SERVICE") | (srcusr == "LOCAL SERVICE") |
                (dstusr == "ANONYMOUS LOGON") | (dstusr == "NETWORK SERVICE") | (dstusr == "LOCAL SERVICE") |
                (dstusr == "SYSTEM")):
            pass
        else:
            newrow = []
            newrow.append(row[0])
            newrow.append(srcusr.replace('$',''))
            newrow.append(srcdom)
            newrow.append(dstusr.replace('$',''))
            newrow.append(dstdom)
            for i in range(3,9):
                newrow.append(row[i])

            outfile.writerow(newrow)


def extract_proc(infile, outfile):
    infile = csv.reader(open(infile,"r"))
    outfile = csv.writer(open(outfile, "w"))

    for i, row in enumerate(infile):
        srcusr = np.array(row[1].split("@"))[0]
        if ((srcusr == "ANONYMOUS LOGON") | (srcusr == "NETWORK SERVICE") | (srcusr == "LOCAL SERVICE")):
            pass
        else:
            outfile.writerow(row)

if __name__ == "__main__":
#    extract_proc("proc.d5_1.txt", "proc.d5_1_cln.csv")
#    print("Completed Extracting Proc File")

    extract_auth("auth.d5_1.txt", "auth.d5_1_cln.csv")
#    extract_auth("test.txt", "tmp")
    print("Completed Auth Proc File")
