__author__ = 'dipanjanpaul'

import csv
from numpy import *
import random

def enhance_auth():

    with open("auth.d5_1_cln.csv", "rb") as inp:
        f_len = sum(1 for _ in inp)

    all = range(1,(f_len-1))
    r_s_trn = sort(random.sample(all,int(.3 * len(all))))
    tmp = set(all) - set(r_s_trn)
    r_s_val = sort(random.sample(tmp,int(.2 * len(tmp))))
    tmp = set(tmp) - set(r_s_val)
    r_s_tst = sort(random.sample(tmp,int(.2 * len(tmp))))

    #r_s_trn_d = dict(zip(r_s_trn, r_s_trn.T))
    #r_s_val_d = dict(zip(r_s_val, r_s_val.T))
    #r_s_tst_d = dict(zip(r_s_tst, r_s_tst.T))

    r_s_trn_d = {}
    for i in range(len(r_s_trn)):
        r_s_trn_d[r_s_trn[i]] = i

    r_s_val_d = {}
    for i in range(len(r_s_val)):
        r_s_val_d[r_s_val[i]] = i

    r_s_tst_d = {}
    for i in range(len(r_s_tst)):
        r_s_tst_d[r_s_tst[i]] = i


    del(all, r_s_trn, r_s_val, r_s_tst)

    print("Completed Random Nr Generation")

    outfile1 = csv.writer(open("cons_trn.csv", "w"))
    outfile2 = csv.writer(open("cons_val.csv", "w"))
    outfile3 = csv.writer(open("cons_tst.csv", "w"))

    infile = csv.reader(open("auth.d5_1_cln.csv","r"))
    row = infile.next()
    header = ['Id', 'Time', 'SrcMC', 'DstMC', 'SrcPort', 'DstPort', 'AuthType', 'LogonType', 'AuthOrnt', 'Hit_Cnt',
              'Hit_Max', 'Score', 'FlowCnt_DstMC',
              'FlowCnt_DstPort', 'FlowMed_Duration', 'FlowMAD_Duration', 'FlowMed_PkCnt', 'FlowMAD_PkCnt', 'RedTeam_Ir', 'Status']

    dns = csv.reader(open('dns_enh.csv', "r"))
    dns_dic = {}
    for i, row in enumerate(dns):
        dns_dic[row[0]] = [row[1], row[2]]

    uscore = csv.reader(open('U.Score.csv', 'r'))
    uscore_dic = {}
    for i, row in enumerate(uscore):
        uscore_dic[row[0]] = row[1]

    flow = csv.reader(open('flow_enh.csv', 'r'))
    flow_dic = {}
    for i, row in enumerate(flow):
        flow_dic[row[0]] = [row[1], row[2], row[3], row[4], row[5], row[6]]

    redteam = csv.reader(open('redteam_enh.csv', 'r'))

    redteam_dic = {}
    for i, row in enumerate(redteam):
        redteam_dic[row[0], row[1], row[2]] = "Y"

    Id_ix = header.index("Id")
    Time_ix = header.index("Time")
    SrcMC_ix = header.index("SrcMC")
    DstMC_ix = header.index("DstMC")
    SrcPort_ix = header.index("SrcPort")
    DstPort_ix = header.index("DstPort")
    AuthType_ix = header.index("AuthType")
    LogonType_ix = header.index("LogonType")
    AuthOrnt_ix = header.index("AuthOrnt")
    HitCnt_ix = header.index("Hit_Cnt")
    HitMax_ix = header.index("Hit_Max")
    Score_ix = header.index("Score")
    FlowCnt_DstMC_ix = header.index("FlowCnt_DstMC")
    FlowCnt_DstPort_ix = header.index("FlowCnt_DstPort")
    FlowAvg_Duration_ix = header.index("FlowMed_Duration")
    FlowSD_Duration_ix = header.index("FlowMAD_Duration")
    FlowAvg_PkCnt_ix = header.index("FlowMed_PkCnt")
    FlowSD_PkCnt_ix = header.index("FlowMAD_PkCnt")
    Redteam_Ir_Ix = header.index("RedTeam_Ir")
    Status_ix = header.index("Status")

    outfile1.writerow(header)
    outfile2.writerow(header)
    outfile3.writerow(header)

    print("Starting Main Process")
    for i, row in enumerate(infile):

        rec_proc = i%100000
        if (rec_proc == 1):
            print('Records Pocessed:', i)

        outdata = list(range(len(header)))

        outdata[Id_ix] = row[1] + '_' + row[0] # Concatenate the Src Machine and Src Domain
        outdata[Time_ix] = ceil((int(row[0])%(58*24*3600))/3600.0)
        outdata[SrcMC_ix] = row[1]
        outdata[DstMC_ix] = row[3]
        outdata[SrcPort_ix] = row[5]
        outdata[DstPort_ix] = row[6]
        outdata[AuthType_ix] = row[7]
        outdata[LogonType_ix] = row[8]
        outdata[AuthOrnt_ix] = row[9]

        if (row[1] in dns_dic):
            outdata[HitCnt_ix] = int(dns_dic[row[1]][0])
            outdata[HitMax_ix] = int(dns_dic[row[1]][1])
        else:
            if (row[5] in dns_dic):
                outdata[HitCnt_ix] = int(dns_dic[row[5]][0])
                outdata[HitMax_ix] = int(dns_dic[row[5]][1])
            else:
                outdata[HitCnt_ix] = 'NA'
                outdata[HitMax_ix] = 'NA'

        if (row[1] in uscore_dic):
            outdata[Score_ix] = int(uscore_dic[row[1]][0])
        else:
            if (row[5] in uscore_dic):
                outdata[Score_ix] = int(uscore_dic[row[5]][0])
            else:
                outdata[Score_ix] = 'NA'

        if (row[1] in flow_dic):
            outdata[FlowCnt_DstMC_ix] = round(float(flow_dic[row[1]][0]),4)
            outdata[FlowCnt_DstPort_ix] = round(float(flow_dic[row[1]][1]),4)
            outdata[FlowAvg_Duration_ix] = round(float(flow_dic[row[1]][2]),4)
            outdata[FlowSD_Duration_ix] = round(float(flow_dic[row[1]][3]),4)
            outdata[FlowAvg_PkCnt_ix] = round(float(flow_dic[row[1]][4]),4)
            outdata[FlowSD_PkCnt_ix] = round(float(flow_dic[row[1]][5]),4)
        else:
            if (row[5] in flow_dic):
                outdata[FlowCnt_DstMC_ix] = round(float(flow_dic[row[5]][0]),4)
                outdata[FlowCnt_DstPort_ix] = round(float(flow_dic[row[5]][1]),4)
                outdata[FlowAvg_Duration_ix] = round(float(flow_dic[row[5]][2]),4)
                outdata[FlowSD_Duration_ix] = round(float(flow_dic[row[5]][3]),4)
                outdata[FlowAvg_PkCnt_ix] = round(float(flow_dic[row[5]][4]),4)
                outdata[FlowSD_PkCnt_ix] = round(float(flow_dic[row[5]][5]),4)
            else:
                outdata[FlowCnt_DstMC_ix] = 'NA'
                outdata[FlowCnt_DstPort_ix] = 'NA'
                outdata[FlowAvg_Duration_ix] = 'NA'
                outdata[FlowSD_Duration_ix] = 'NA'
                outdata[FlowAvg_PkCnt_ix] = 'NA'
                outdata[FlowSD_PkCnt_ix] = 'NA'

        if ((row[0], row[5], row[6]) in redteam_dic):
            outdata[Redteam_Ir_Ix] = 'Y'
        else:
            outdata[Redteam_Ir_Ix] = 'N'

        ## Populate the Status Flag
        outdata[Status_ix] = row[10]

        if i in r_s_trn_d:
            outfile1.writerow(outdata)
        elif i in r_s_val_d:
            outfile2.writerow(outdata)
        elif i in r_s_tst_d:
            outfile3.writerow(outdata)

if __name__ == "__main__":
    enhance_auth()
    print("Completed Auth Enhancement Process")
