__author__ = 'dipanjanpaul'
import csv
import numpy as np

def summary(file_name):

    sourceUser_dic = {}
    sourceDomain_dic = {}
    
    destUser_dic = {}
    destDomain_dic = {}

    reader=csv.reader(open(file_name,"r"), delimiter=',')
    s_user=csv.writer(open("srcusr.csv","w"))
    s_domain=csv.writer(open("srcdom.csv","w"))
    d_user=csv.writer(open("dstusr.csv","w"))
    d_domain=csv.writer(open("dstdom.csv","w"))

    for i, row in enumerate(reader):
        sourceUserDomain = np.array(row[1].split('@'), dtype="string")
        user = sourceUserDomain[0]
        domain=sourceUserDomain[1]

        if (user in sourceUser_dic):
            sourceUser_dic[user] += 1
        else:
            sourceUser_dic[user] = 1

        if (domain in sourceDomain_dic):
            sourceDomain_dic[domain] += 1
        else:
            sourceDomain_dic[domain] = 1
            
        destUserDomain = np.array(row[1].split('@'), dtype="string")
        user = destUserDomain[0]
        domain=destUserDomain[1]

        if (user in destUser_dic):
            destUser_dic[user] += 1
        else:
            destUser_dic[user] = 1

        if (domain in destDomain_dic):
            destDomain_dic[domain] += 1
        else:
            destDomain_dic[domain] = 1

    for key, val in sourceUser_dic.items():
        if (val > 5):
            s_user.writerow([key,val])
            
    for key, val in sourceDomain_dic.items():
        s_domain.writerow([key,val])

    for key, val in destUser_dic.items():
        if (val > 5):
            d_user.writerow([key,val])

    for key, val in destDomain_dic.items():
        d_domain.writerow([key,val])

if __name__ == "__main__":
    file_n = "auth.d5_1.txt"
    summary(file_n)


