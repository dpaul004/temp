#!/bin/bash
#PBS -j oe
#PBS -l walltime=12:00:00
#PBS -l mem=8gb
#PBS -l ncpus=2

cd ~/cyber

in1='auth.txt'
echo $in1
out1='auth.d5_1.txt'
echo $out1

in2='proc.txt'
echo $in2
out2='proc.d_1.txt'
echo $out2

in3='flows.txt'
echo $in3
out3='flows.d5_1.txt'
echo $out3

in4='dns.txt'
echo $in4
out4='dns.d5_1.txt'
echo $out4

declare -a day
declare -a uniq_day
declare -a st
declare -a nd

day[0]=0
for i in {1..20}
do
   day[i]=$(( $RANDOM%58 ))
done

#echo ${day[@]}

uniq_day=($(echo ${day[@]} | tr ' ' '\012' | sort -u))
#echo ${uniq_day[@]}

st0=$(( ${uniq_day[0]}*3600*22 ))
nd0=$(( (${uniq_day[0]}+1)*(3600*24-1) ))

st1=$(( ${uniq_day[1]}*3600*22 ))
nd1=$(( (${uniq_day[1]}+1)*(3600*24-1) ))

st2=$(( ${uniq_day[2]}*3600*22 ))
nd2=$(( (${uniq_day[2]}+1)*(3600*24-1) ))

st3=$(( ${uniq_day[3]}*3600*22 ))
nd3=$(( (${uniq_day[3]}+1)*(3600*24-1) ))

st4=$(( ${uniq_day[4]}*3600*22 ))
nd4=$(( (${uniq_day[4]}+1)*(3600*24-1) ))

#st5=$(( ${uniq_day[5]}*3600*22 ))
#nd5=$(( (${uniq_day[5]}+1)*(3600*24-1) ))

#st6=$(( ${uniq_day[6]}*3600*22 ))
#nd6=$(( (${uniq_day[6]}+1)*(3600*24-1) ))

#st7=$(( ${uniq_day[7]}*3600*22 ))
#nd7=$(( (${uniq_day[7]}+1)*(3600*24-1) ))

#st8=$(( ${uniq_day[8]}*3600*22 ))
#nd8=$(( (${uniq_day[8]}+1)*(3600*24-1) ))

#st9=$(( ${uniq_day[9]}*3600*22 ))
#nd9=$(( (${uniq_day[9]}+1)*(3600*24-1) ))

echo $st0
echo $nd0

echo $st1
echo $nd1

echo $st2
echo $nd2

echo $st3
echo $nd3

echo $st4
echo $nd4

echo $st5
echo $nd5


awk -v var_s0="$st0" -v var_n0="$nd0" \
	-v var_s1="$st1" -v var_n1="$nd1" \
	-v var_s2="$st2" -v var_n2="$nd2" \
	-v var_s3="$st3" -v var_n3="$nd3" \
	-v var_s4="$st4" -v var_n4="$nd4" \
	'BEGIN{FS=",";OFS=","} 
	{if ((($1 >= var_s0) && ($1 <= var_n0)) || \
             (($1 >= var_s1) && ($1 <= var_n1)) || \
	     (($1 >= var_s2) && ($1 <= var_n2)) || \
	     (($1 >= var_s3) && ($1 <= var_n3)) || \
	     (($1 >= var_s4) && ($1 <= var_n4))) print}' $in1 > $out1

awk -v var_s0="$st0" -v var_n0="$nd0" \
        -v var_s1="$st1" -v var_n1="$nd1" \
        -v var_s2="$st2" -v var_n2="$nd2" \
        -v var_s3="$st3" -v var_n3="$nd3" \
        -v var_s4="$st4" -v var_n4="$nd4" \
        'BEGIN{FS=",";OFS=","}
        {if ((($1 >= var_s0) && ($1 <= var_n0)) || \
             (($1 >= var_s1) && ($1 <= var_n1)) || \
             (($1 >= var_s2) && ($1 <= var_n2)) || \
             (($1 >= var_s3) && ($1 <= var_n3)) || \
             (($1 >= var_s4) && ($1 <= var_n4))) print}' $in2 > $out2

awk -v var_s0="$st0" -v var_n0="$nd0" \
        -v var_s1="$st1" -v var_n1="$nd1" \
        -v var_s2="$st2" -v var_n2="$nd2" \
        -v var_s3="$st3" -v var_n3="$nd3" \
        -v var_s4="$st4" -v var_n4="$nd4" \
        'BEGIN{FS=",";OFS=","}
        {if ((($1 >= var_s0) && ($1 <= var_n0)) || \
             (($1 >= var_s1) && ($1 <= var_n1)) || \
             (($1 >= var_s2) && ($1 <= var_n2)) || \
             (($1 >= var_s3) && ($1 <= var_n3)) || \
             (($1 >= var_s4) && ($1 <= var_n4))) print}' $in3 > $out3

awk -v var_s0="$st0" -v var_n0="$nd0" \
        -v var_s1="$st1" -v var_n1="$nd1" \
        -v var_s2="$st2" -v var_n2="$nd2" \
        -v var_s3="$st3" -v var_n3="$nd3" \
        -v var_s4="$st4" -v var_n4="$nd4" \
        'BEGIN{FS=",";OFS=","}
        {if ((($1 >= var_s0) && ($1 <= var_n0)) || \
             (($1 >= var_s1) && ($1 <= var_n1)) || \
             (($1 >= var_s2) && ($1 <= var_n2)) || \
             (($1 >= var_s3) && ($1 <= var_n3)) || \
             (($1 >= var_s4) && ($1 <= var_n4))) print}' $in4 > $out4

