library(tree)

parm <- "none"
setwd("/sscc/home/d/dpk543/cyber")

######################################################################################
## Initial Analysis Done Here
d_main <- read.csv("test.txt", header=F, colClasses="character")

x<- (strsplit(d_main$V2, split="@", fixed=T))
srcusr <- unlist(lapply(x, function(x) x[1]))
srcdom <- unlist(lapply(x, function(x) x[2]))

x<- (strsplit(d_main$V3, split="@", fixed=T))

destusr <- unlist(lapply(x, function(x) x[1]))
destdom <- unlist(lapply(x, function(x) x[2]))

######################################################################################
# Analyze the PROC Dataset
# ###############The following was done in SAS due to memory issues in R #################
#df <- read.csv("proc.srt.csv",header=F)
#df_wide <- reshape(df[1:10,], v.names=c('Time'), 
#           idvar=c('SrcMC', 'SrcPort', 'Process'), timevar=c('Status'),
#           direction='wide')
##########################################################################################
df_wide <- read.csv("proc.wide.csv", header=T)

x<- (strsplit(as.character(df_wide$SrcMC), split="$@", fixed=T))
MC <- as.character(unlist(lapply(x, function(x) x[1])))
df_wide$SrcMC <- MC

df_wide$SrcPort <- as.character(df_wide$SrcPort)
df_wide$Process <- as.character(df_wide$Process)

TimeDiff <- df_wide$End - df_wide$Start
SrcEQPrt <- as.factor((I(df_wide$SrcMC == df_wide$SrcPort)))

df_wide <- cbind(df_wide[,which(names(df_wide) %in% c('SrcMC', 'SrcPort', 'Process'))],
                 TimeDiff, SrcEQPrt)

## Analysis and Stats for PROC Dataset
table(df_wide[which((df_wide$TimeDiff > 5000) & (df_wide$TimeDiff < 40000)),]$SrcEQPrt)

tmp <- df_wide[which((df_wide$TimeDiff > 1000) & (df_wide$TimeDiff < 60000)),c('TimeDiff', 'SrcEQPrt')]
tmp$t_slot <- as.integer(factor(cut(tmp$TimeDiff,50)))
barplot((table(tmp$SrcEQPrt, tmp$t_slot)), legend=levels(tmp$SrcEQPrt),
        bg=c('red', 'green')[unclass(tmp$SrcEQPrt)], main="Source MC Eq. Src Port: TimeDiff (1000 - 60000)")

tmp <- df_wide[which((df_wide$TimeDiff > 0) & (df_wide$TimeDiff < 1000)),c('TimeDiff', 'SrcEQPrt')]
tmp$t_slot <- as.integer(factor(cut(tmp$TimeDiff,10)))
barplot((table(tmp$SrcEQPrt, tmp$t_slot)), legend=levels(tmp$SrcEQPrt),
        bg=c('red', 'green')[unclass(tmp$SrcEQPrt)], main="Source MC Eq. Src Port: TimeDiff (0 - 1000)")

tmp <- df_wide[which((df_wide$TimeDiff > 60000) & (df_wide$TimeDiff < 1000000)),c('TimeDiff', 'SrcEQPrt')]
tmp$t_slot <- as.integer(factor(cut(tmp$TimeDiff,10)))
barplot((table(tmp$SrcEQPrt, tmp$t_slot)), legend=levels(tmp$SrcEQPrt),
        bg=c('red', 'green')[unclass(tmp$SrcEQPrt)], main="Source MC Eq. Src Port: TimeDiff (60000 - 1000000)")

# Create a User Score Metrics
# Impute missing TimeDiff 

tmp <-df_wide
tmp$TimeDiff[tmp$TimeDiff < 0] <- -1
tmp$TimeDiff[tmp$TimeDiff > 36000] <- 36000

proc_median <- with(tmp, tapply(TimeDiff, Process, function(x) median(x, na.rm=T))) 
proc_stat <- data.frame(names(proc_median), proc_median)
names(proc_stat) <- c('Process', 'p_TimeDiff_Median')

SrcMC_median <- with(tmp, tapply(TimeDiff, SrcMC, function(x) median(x, na.rm=T))) 
SrcMC_stat <- data.frame(names(SrcMC_median), SrcMC_median)
names(SrcMC_stat) <- c('SrcMC', 'SrcMC_TimeDiff_Median')

all_median <- median(tmp$TimeDiff, na.rm=T)

proc_stat <- proc_stat[complete.cases(proc_stat),]
SrcMC_stat <- SrcMC_stat[complete.cases(SrcMC_stat),]
tmp <- merge(tmp, proc_stat, by.x='Process', by.y='Process', all.x=T)
tmp <- merge(tmp, SrcMC_stat, by.x='SrcMC', by.y='SrcMC', all.x=T)
tmp[which(is.na(tmp$TimeDiff)), c('TimeDiff')] <- tmp[which(is.na(tmp$TimeDiff)), c('SrcMC_TimeDiff_Median')]
tmp[which(is.na(tmp$TimeDiff)), c('TimeDiff')] <- tmp[which(is.na(tmp$TimeDiff)), c('p_TimeDiff_Median')]
tmp[which(is.na(tmp$TimeDiff)), c('TimeDiff')] <- all_median

tmp$all_median <- all_median
tmp$U_Score <- rep(0, nrow(tmp))
tmp$U_Score <- as.numeric((!is.na(tmp$p_TimeDiff_Median) & (tmp$TimeDiff > tmp$p_TimeDiff_Median)) + 
                          (!is.na(tmp$SrcMC_TimeDiff_Median) & (tmp$TimeDiff > tmp$SrcMC_TimeDiff_Median)) +
                          (tmp$TimeDiff > tmp$all_median))  

write.csv(tmp, "proc.wide.upd.csv", row.names=F)

# Create a User Score Dataset
tmp <- tmp[order(tmp$SrcMC),]
SrcMC <- unique(tmp$SrcMC)
u_score_cnt <- tapply(tmp$U_Score, tmp$SrcMC, sum)
U.Score <- data.frame(SrcMC, u_score_cnt)
names(U.Score) <- c('SrcMC', 'Score')
write.csv(U.Score, "U.Score.csv", row.names=F)
##################################################################################

##################################################################################
## Analyze the Flow Dataset
df <- read.csv("flows.d5_1.txt", header=F)
names(df) <- c('Time', 'Duration', 'SrcMC', 'SrcPort', 'DstMC', 'DstPort', 'Protocol', 'PkCnt', 'BytCnt')
#apply(df, 2, function(x) sum(is.na(x)))
df$Protocol <- as.factor(df$Protocol)

tapply(df$PkCnt, df$Protocol, length)
#boxplot(PkCnt ~ Protocol, data=df)

tapply(df$PkCnt, df$Protocol, summary)
#$`1`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.000   1.000   2.000   4.126   2.000 932.000 
# 
# $`6`
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 1.0       1.0       5.0     309.2       9.0 1753000.0 
# 
# $`17`
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 1.00      1.00      1.00      2.25      2.00 175400.00 
# 
# $`41`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.000   1.000   1.000   2.909   3.000  10.000 

tapply(df$BytCnt, df$Protocol, summary)
# $`1`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 46.0   120.0   120.0   286.6   166.0 55920.0 
# 
# $`6`
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 4.600e+01 5.200e+01 4.810e+02 2.705e+05 2.640e+03 2.303e+09 
# 
# $`17`
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 46       180       193       719       343 254600000 
# 
# $`41`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 92.0    92.0    92.0   266.7   272.0   916.0 

tapply(df$Duration, df$Protocol, summary)
# $`1`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.000   0.000   0.000   3.008   1.000  67.000 
# 
# $`6`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.0     0.0     0.0    10.3    11.0    73.0 
# 
# $`17`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.00    0.00    0.00   10.36    0.00   70.00 
# 
# $`41`
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.00    0.00    0.00   13.43    9.50   52.00 

barplot(table(cut(df[df$Protocol == '6', c('PkCnt')], 10)))

library(corrplot)
mcor <- cor(df[,which(names(df) %in% c('Duration', 'PkCnt', 'BytCnt'))])
dev.off()
corrplot(mcor, method=c("shade"), tl.col="black", tl.cex=0.8)

x <- cut(df$Duration,5)
y <- cut(df$BytCnt,5)
table(x,y)

# Additional Fields,
df <- df[order(df$SrcMC),]
SrcMC <- unique(df$SrcMC)

FlowCnt_DstMC <- tapply(df$DstMC, df$SrcMC, function(x) max(table(x)))
FlowCnt_DstPort <- tapply(df$DstPort, df$SrcMC, function(x) max(table(x)))
FlowMed_Duration <- tapply(df$Duration, df$SrcMC, median)
FlowMAD_Duration <- tapply(df$Duration, df$SrcMC, mad)

FlowMed_PkCnt <- tapply(df$PkCnt, df$SrcMC, median)
FlowMAD_PkCnt <- tapply(df$PkCnt, df$SrcMC, mad)

flow_df <- data.frame(SrcMC, FlowCnt_DstMC, FlowCnt_DstPort, FlowMed_Duration, 
                      FlowMAD_Duration, FlowMed_PkCnt, FlowMAD_PkCnt)

write.csv(flow_df, "flow_enh.csv", row.names=F)
##################################################################################

##################################################################################
## Analyze the DNS Dataset
df <- read.csv("dns.txt", header=F)
names(df) <- c('Time', 'SrcMC', 'DstMC')
df$SrcMC <- as.character(df$SrcMC)
df$DstMC <- as.character(df$DstMC)

# Add fields
df <- df[order(df$SrcMC),]
SrcMC <- unique(df$SrcMC)
Hit_Max <- tapply(df$DstMC, df$SrcMC, function(x) max(table(x)))
Hit_Cnt <- tapply(df$DstMC, df$SrcMC, function(x) length(table(x)))
dns_df <- data.frame(SrcMC, Hit_Cnt, Hit_Max)

x <- cut(dns_df$Hit_Cnt,20)
y <- cut(dns_df$Hit_Max,20)
table(x,y)

hist(log(dns_df$Hit_Cnt), 100)
hist(log(dns_df$Hit_Max), 100)

write.csv(dns_df, "dns_enh.csv", row.names=F)

##################################################################################

##################################################################################
## Analyze the Redteam Dataset
df <- read.csv("redteam.txt", header=F)
names(df) <- c('Time', 'User', 'SrcMC', 'DstMC')
write.csv(df, "redteam_enh.csv", row.names=F)

##################################################################################

##################################################################################
## Analyze the Auth Dataset
df <- read.csv("auth.d5_1_cln.csv", header=T, nrows=1000000)
apply(df, 2, function(x) sum(x == '?'))
apply(df, 2, function(x) sum(is.na(x)))

dev.off()
barplot((table(df$AuthType)), col='lightblue', main="AuthType (Auth Dataset)", names.arg=names(table(df$AuthType)),
        cex.names=0.8, width=1, las=1)

dev.off()
barplot((table(df$AuthType)), col='lightblue', main="AuthType (Auth Dataset)", 
        names.arg=names(table(df$AuthType)),
        cex.names=0.8, width=1, las=1, pos=0)

barplot((table(df$LogonType)), col='lightblue', main="AuthType (Auth Dataset)", 
        names.arg=names(table(df$LogonType)),
        cex.names=0.8, width=1, las=1)

##################################################################################