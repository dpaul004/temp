library(ROSE)

parm <- "none"
setwd("/sscc/home/d/dpk543/cyber")

######################################################################################
## Initial Analysis Done Here
d_main <- read.csv("cons_val.csv", header=T)
summary(d_main)
d_main <- d_main[, -which(names(d_main) %in% c('AuthType', 'LogonType'))]
d_main_comp <- d_main[complete.cases(d_main),]

## Data Summary
summary(d_main_comp)

## Resample data to create a 80/20 split of Success/Fail Transactions
d_final <- ovun.sample(Status ~ ., data=d_main_comp, method="both", N=10000000, p=0.2)$data

d_final$Hit_Cnt  = log(d_final$Hit_Cnt + 0.001)          
d_final$Hit_Max  = log(d_final$Hit_Max + 0.001)
d_final$FlowCnt_DstMC = log(d_final$FlowCnt_DstMC + 0.001)
d_final$FlowCnt_DstPort = log(d_final$FlowCnt_DstPort + 0.001)
d_final$FlowMed_Duration = log(d_final$FlowMed_Duration + 0.001)
d_final$FlowMAD_Duration = log(d_final$FlowMAD_Duration + 0.001)
d_final$FlowMed_PkCnt = log(d_final$FlowMed_PkCnt + 0.001)
d_final$FlowMAD_PkCnt = log(d_final$FlowMAD_PkCnt + 0.001)

d_final$Ir1 = I(as.character(d_final$SrcMC) == as.character(d_final$SrcPort))
d_final$Ir2 = I(as.character(d_final$DstMC) == as.character(d_final$DstPort))

d_final <- d_final[, -which(names(d_final) %in% c('SrcMC', 'DstMC', 'SrcPort', 'DstPort'))]

d_final <- d_final[,c("Id", "Time", "AuthOrnt", "Hit_Cnt", "Hit_Max", "Score", "FlowCnt_DstMC", "FlowCnt_DstPort",
                  "FlowMed_Duration", "FlowMAD_Duration", "FlowMed_PkCnt", "FlowMAD_PkCnt",   
                  "Ir1", "Ir2", "Status")]

write.csv(d_final, "d_final.csv", row.names=F)