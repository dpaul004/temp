#!/bin/bash
#PBS -j oe
#PBS -l walltime=12:00:00
#PBS -l mem=8gb
#PBS -l ncpus=4

cd ~/cyber

sas proc_anal.sas

