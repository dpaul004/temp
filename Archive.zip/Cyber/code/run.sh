#!/bin/bash
#PBS -j oe
#PBS -l walltime=23:00:00
#PBS -l mem=32gb
#PBS -l ncpus=4

cd ~/cyber

module load/anaconda

#python extrCleanData.py

python merge_2.py
