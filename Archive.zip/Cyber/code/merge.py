__author__ = 'dipanjanpaul'

import csv
import pandas as pd
from math import *
from numpy import *
import random

def enhance_auth():

    with open("auth.d5_1_cln.csv", "rb") as inp:
        f_len = sum(1 for _ in inp)

    all = range(1,(f_len-1))
    r_s_trn = sort(random.sample(all,int(.4 * len(all))))
    tmp = set(all) - set(r_s_trn)
    r_s_val = sort(random.sample(tmp,int(.5 * len(tmp))))
    r_s_tst = array(list((set(tmp) - set(r_s_val))))

    r_s_trn_d = dict(zip(r_s_trn, r_s_trn.T))
    r_s_val_d = dict(zip(r_s_val, r_s_val.T))
    r_s_tst_d = dict(zip(r_s_tst, r_s_tst.T))

    outfile1 = csv.writer(open("cons_trn.csv", "w"))
    outfile2 = csv.writer(open("cons_val.csv", "w"))
    outfile3 = csv.writer(open("cons_tst.csv", "w"))

    infile = csv.reader(open("auth.d5_1_cln.csv","r"))
    row = infile.next()
    header = list()
    header.append("Id")
    header.extend(row[0:2])
    header.append(row[3])
    header.extend(row[5:10])

    dns = pd.read_csv('dns_enh.csv',header=0)
    dns_dic = dns.set_index('SrcMC').T.to_dict('list')
    dns.header = list(dns.columns.values)

    uscore = pd.read_csv('U.Score.csv',header=0)
    uscore_dic = uscore.set_index('SrcMC').T.to_dict('list')
    uscore.header = list(uscore.columns.values)

    flow = pd.read_csv('flow_enh.csv',header=0)
    flow_dic = flow.set_index('SrcMC').T.to_dict('list')
    flow.header = list(flow.columns.values)

    redteam = pd.read_csv('redteam_enh.csv',header=0)
    redteam.header = list(redteam.columns.values)

    redteam_dic = {}
    for i in range(redteam.shape[0]):
        redteam_dic[redteam.Time[i], redteam.SrcMC[i],redteam.DstMC[i]] = "Y"

    header.extend(dns.header[1:3])
    header.append(uscore.header[1])
    header.extend(flow.header[1:len(flow.header)])
    header.append("RedTeam_Ir")
    header.append(row[(len(row) - 1)])

    Id_ix = header.index("Id")
    Time_ix = header.index("Time")
    SrcMC_ix = header.index("SrcMC")
    DstMC_ix = header.index("DstMC")
    SrcPort_ix = header.index("SrcPort")
    DstPort_ix = header.index("DstPort")
    AuthType_ix = header.index("AuthType")
    LogonType_ix = header.index("LogonType")
    AuthOrnt_ix = header.index("AuthOrnt")
    HitCnt_ix = header.index("Hit_Cnt")
    HitMax_ix = header.index("Hit_Max")
    Score_ix = header.index("Score")
    FlowCnt_DstMC_ix = header.index("FlowCnt_DstMC")
    FlowCnt_DstPort_ix = header.index("FlowCnt_DstPort")
    FlowAvg_Duration_ix = header.index("FlowMed_Duration")
    FlowSD_Duration_ix = header.index("FlowMAD_Duration")
    FlowAvg_PkCnt_ix = header.index("FlowMed_PkCnt")
    FlowSD_PkCnt_ix = header.index("FlowMAD_PkCnt")
    Redteam_Ir_Ix = header.index("RedTeam_Ir")
    Status_ix = header.index("Status")

    outfile1.writerow(header)
    outfile2.writerow(header)
    outfile3.writerow(header)

    for i, row in enumerate(infile):

        outdata = list(range(len(header)))

        outdata[Id_ix] = row[1] + '_' + row[0] # Concatenate the Src Machine and Src Domain
        outdata[Time_ix] = ceil((int(row[0])%(58*24*3600))/3600.0)
        outdata[SrcMC_ix] = row[1]
        outdata[DstMC_ix] = row[3]
        outdata[SrcPort_ix] = row[5]
        outdata[DstPort_ix] = row[6]
        outdata[AuthType_ix] = row[7]
        outdata[LogonType_ix] = row[8]
        outdata[AuthOrnt_ix] = row[9]

        if (row[1] in dns_dic):
            outdata[HitCnt_ix] = int(dns_dic[row[1]][0])
            outdata[HitMax_ix] = int(dns_dic[row[1]][1])
        else:
            if (row[5] in dns_dic):
                outdata[HitCnt_ix] = int(dns_dic[row[5]][0])
                outdata[HitMax_ix] = int(dns_dic[row[5]][1])
            else:
                outdata[HitCnt_ix] = 'NA'
                outdata[HitMax_ix] = 'NA'

        if (row[1] in uscore_dic):
            outdata[Score_ix] = int(uscore_dic[row[1]][0])
        else:
            if (row[5] in uscore_dic):
                outdata[Score_ix] = int(uscore_dic[row[5]][0])
            else:
                outdata[Score_ix] = 'NA'

        if (row[1] in flow_dic):
            outdata[FlowCnt_DstMC_ix] = round(float(flow_dic[row[1]][0]),4)
            outdata[FlowCnt_DstPort_ix] = round(float(flow_dic[row[1]][1]),4)
            outdata[FlowAvg_Duration_ix] = round(float(flow_dic[row[1]][2]),4)
            outdata[FlowSD_Duration_ix] = round(float(flow_dic[row[1]][3]),4)
            outdata[FlowAvg_PkCnt_ix] = round(float(flow_dic[row[1]][4]),4)
            outdata[FlowSD_PkCnt_ix] = round(float(flow_dic[row[1]][5]),4)
        else:
            if (row[5] in flow_dic):
                outdata[FlowCnt_DstMC_ix] = round(float(flow_dic[row[5]][0]),4)
                outdata[FlowCnt_DstPort_ix] = round(float(flow_dic[row[5]][1]),4)
                outdata[FlowAvg_Duration_ix] = round(float(flow_dic[row[5]][2]),4)
                outdata[FlowSD_Duration_ix] = round(float(flow_dic[row[5]][3]),4)
                outdata[FlowAvg_PkCnt_ix] = round(float(flow_dic[row[5]][4]),4)
                outdata[FlowSD_PkCnt_ix] = round(float(flow_dic[row[5]][5]),4)
            else:
                outdata[FlowCnt_DstMC_ix] = 'NA'
                outdata[FlowCnt_DstPort_ix] = 'NA'
                outdata[FlowAvg_Duration_ix] = 'NA'
                outdata[FlowSD_Duration_ix] = 'NA'
                outdata[FlowAvg_PkCnt_ix] = 'NA'
                outdata[FlowSD_PkCnt_ix] = 'NA'

        if ((row[0], row[5], row[6]) in redteam_dic):
            outdata[Redteam_Ir_Ix] = 'Y'
        else:
            outdata[Redteam_Ir_Ix] = 'N'

        ## Populate the Status Flag
        outdata[Status_ix] = row[10]

        if i in r_s_trn_d:
            outfile1.writerow(outdata)
        elif i in r_s_val_d:
            outfile2.writerow(outdata)
        elif i in r_s_tst_d:
            outfile3.writerow(outdata)

if __name__ == "__main__":
    enhance_auth()
    print("Completed Auth Enhancement Process")
