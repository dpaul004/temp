library(pROC)
library(tree)
library(rpart)
library(rpart.plot)
library(gam)

parm <- "none"
setwd("/sscc/home/d/dpk543/cyber")

## Model Code
df <- read.csv("d_final.csv", header=T)
summary(df)

df$Time <- as.factor(ceiling(df$Time/24))
df$Status <- as.factor(ifelse((as.character(df$Status) == 'Success'), 0, 1))
str(df)

ix <- rbinom(nrow(df), 1, 0.7)
trn <- df[ix == 1,][,]
val <- df[ix == 0,][,]
rm(df, ix)

## Base Model with GLM
model_glm <- glm(Status ~ ., data=trn[,-1], family=binomial("logit"))
pred <- predict(model_glm, newdata=val[,-1], type="response")

## Tree Model
rpart_model <- rpart(Status ~ ., data=trn[,-1])
dev.off()
rpart.plot(rpart_model)
text(rpart_model, pretty=0)

## GAM Model with DF = 3
gam_model <- gam(Status ~ Time + AuthOrnt + s(Hit_Cnt, 3) + s(Hit_Max, 3) + s(Score, 3) +
                 s(FlowCnt_DstMC, 3) + s(FlowCnt_DstPort, 3) + s(FlowMed_Duration, 3) +
                   s(FlowMAD_Duration, 3) + s(FlowMed_PkCnt, 3) + s(FlowMAD_PkCnt, 3) +
                   Ir1 + Ir2, data=trn, family='binomial')

pred <- predict(gam_model, newdata=val[,-1], type="response")
true <- val$Status

## Profit function for model comparison
profit <- cumsum(10 * as.numeric(as.character(true[order(pred, decreasing=T)])) - 3)
n.cutoff.valid <- which.max(profit) 

if (prt == "Y") {
  plot(profit, xlab = "Number of Recs", ylab="profit") # see how profits change
  abline(v=which.max(profit), lty = 2, col = "red")
  legend ("bottomright", legend = c(paste("Total Rec: ", n.cutoff.valid, sep=""),
                                    paste("Profit: ", max(profit), sep="")), col = c('black', "blue"), pch = c(19, 2))
  
  #roc1 <- roc(true, pred)
  #plot(roc1, main=c(paste("AUC: ", round(roc1$auc,4), sep="")))
} else {
  print(c(n.cutoff.valid, max(profit))) # 
}

cutoff <- sort(pred, decreasing=T)[n.cutoff.valid+1] # set cutoff based on n.cutoff.valid
pred <- ifelse(pred > cutoff, 1, 0) # 
addmargins(table(pred, true))

# Loss Function
-(1/nrow(val)) * sum(as.integer(as.character(true)) * log(pred) + 
                       (1 - as.integer(as.character(true))) * log(1 - pred))