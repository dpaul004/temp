parm <- "none"
setwd("~/Documents/Models/UPS/Dups")

# Feature Derivation Functions
# This function computes the median of the time range of the various scanners that scanned a tck
time_diff_cal <- function(x) {
  median(tapply(x$Scan.TimeStamp, x$Serial.., function(z) as.numeric(max(z)) - as.numeric(min(z))))
}

# This function computes the median of the max number of scans by each scanner per minute 
scan_in_a_min_by_scanner <- function(x) {
  median(tapply(x$Scan.TimeStamp, x$Serial.., function(z) max(table(as.character(z)))))
}

# This function computes the max number of scanners seen by a pkg in a minute
number_of_scanners_per_min <- function(x) {
  max(tapply(x$Serial.., as.character(x$Scan.TimeStamp), function(z) length(unique(z))))
}

# Computes the sd of the weights by within a scanner. If there are more than one scanner, the median sd is returned
weight_variance <- function(x) {
  median(tapply(x$Weight, x$Serial.., function(z) sd(z)))
}

# Computes the range of the weights by within a scanner. Takes the median
wgt_range_by_scanner <- function(x) {
  median(tapply(x$Weight, x$Serial.., function(z) (max(z) - min(z))))
}

# Computes the number of distinct size packages by a scanner. Takes the median
unique_wgt_count_by_scanner <- function(x) {
  median(tapply(x$Weight, x$Serial.., function(z) length(unique(z))))
}

# Finds the number of packages having exactly the same weight (by within a scanner). Takes the median
same_wgt_count_by_scanner <- function(x) {
  median(tapply(x$Weight, x$Serial.., function(z) max(table(z))))
}

# Main logic starts here
df <- read.csv('WE051516.csv', header=T)
names(df) <- c("Tracking.Number", "Scan.Type.Code", "Tbl.entry.Seq..", "Actual.Scan.Date", "Actual.Scan.Time",
               "EQP.NR", "Port..", "Serial..", "Auth.ID..", "Scan.Center", "Prc.Typ.Code", "ADL.HDL.IR", "WGT.MS.UNT.CD",
               "Act.Weight", "Scan.Error.Code", "Actual.Length", "Actual.Width", "Actual.Height", "REC.CRT.DT", 
               "DMN.MS.UNT.CD", "ERR.CGY.CD", "ERR.CD", "SN.DAT.UL.DT" )

df$Weight <- round((df$Actual.Length * df$Actual.Width * df$Actual.Height)/166, 1)
df$Weight <- ifelse(df$Weight == 0, df$Act.Weight, df$Weight)
df <- df[-(df$Act.Weight == 0 & df$Weight == 0),]

df <- df[order(df$Tracking.Number),]
df$Tracking.Number <- (gsub(" ", "", df$Tracking.Number))
df$Scan.TimeStamp <- strptime(paste(df$Actual.Scan.Date, df$Actual.Scan.Time), "%Y-%m-%d %H.%M.%S")

# Develop Features
tck_nr <- unique(df$Tracking.Number)

# The following features aggregates the ports
total_ports <- tapply(df$Port.., df$Tracking.Number, function(x) length(unique(x)))
total_devices <- tapply(df$Serial.., df$Tracking.Number, function(x) length(unique(x)))
max_scans_on_a_port <- tapply(df$Serial.., df$Tracking.Number, function(x) max(table(x)))
avg_itms_scanned <- tapply(df$Serial.., df$Tracking.Number, function(x) median(table(x)))

# The following aggregates the scan times
# 1. Median time range
time_diff_median <- tapply(1:nrow(df), df$Tracking.Number, function(x) time_diff_cal(df[x,c("Serial..", "Scan.TimeStamp")]))

# 2. Unique scanner count count by min 
max_unq_scanners <- tapply(1:nrow(df), df$Tracking.Number, function(x) 
                          number_of_scanners_per_min(df[x,c("Serial..", "Scan.TimeStamp")]))

# 3. Max Scans in a minute by a scanner
scans_in_a_min <- tapply(1:nrow(df), df$Tracking.Number, function(x) 
                        scan_in_a_min_by_scanner(df[x,c("Serial..", "Scan.TimeStamp")]))

# The following aggregates the pkg weight,. The weight has been derived from the scans (lbh/166),.. In case, there aren't any dimensions
# the actual weight was used,.. All weights from scans were rounded to 1 decimeal point.
# 1. Calculate weight varince
weight_var <- round(tapply(1:nrow(df), df$Tracking.Number, function(x) weight_variance(df[x,c("Serial..", "Weight")])), 2)
weight_rng <- tapply(1:nrow(df), df$Tracking.Number, function(x) wgt_range_by_scanner(df[x,c("Serial..", "Weight")]))
weight_unq_cnt <- tapply(1:nrow(df), df$Tracking.Number, function(x) unique_wgt_count_by_scanner(df[x,c("Serial..", "Weight")]))
same_wgt_cnt <- tapply(1:nrow(df), df$Tracking.Number, function(x) same_wgt_count_by_scanner(df[x,c("Serial..", "Weight")]))

agg_data <- data.frame(tck_nr, total_ports, total_devices, max_scans_on_a_port, avg_itms_scanned, 
                       time_diff_median, max_unq_scanners, scans_in_a_min,
                       weight_var, weight_rng, weight_unq_cnt, same_wgt_cnt)

write.table(agg_data,"agg_data.csv",sep=',',col.names=T,row.names=F)

rm(list=ls())
gc()