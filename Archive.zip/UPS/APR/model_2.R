## And there we go,.. from good to great,.. Learn machine learn
##----------------------------------------------##
## Better start swimmin'
## Or'll sink like a stone
## For the times they are a-changin'
##----------------------------------------------##

parm <- "none"
setwd("~/Documents/Models/UPS/APR")

train <- read.csv('train.csv', header=T, colClasses='character')
train$pkg_qy <- as.numeric(train$pkg_qy)
train$ln_pkg_qy <- as.numeric(train$ln_pkg_qy)
train$x_pkg_qy <- as.numeric(train$x_pkg_qy)

train$svc_typ <- as.factor(train$svc_typ)
train$zn_nr <- as.factor(train$zn_nr)
train$adj_trs_typ <- as.factor(train$adj_trs_typ)

test <- read.csv('test.csv',header=T, colClasses='character')
test$pkg_qy <- as.numeric(test$pkg_qy)
test$ln_pkg_qy <- as.numeric(test$ln_pkg_qy)
test$x_pkg_qy <- as.numeric(test$x_pkg_qy)

test$svc_typ <- as.factor(test$svc_typ)
test$zn_nr <- as.factor(test$zn_nr)
test$adj_trs_typ <- as.factor(test$adj_trs_typ)

##l <- list(train$rec_typ, train$trs_dat, train$inf_src, train$dat_src_cd, train$ctnr_typ,
##          train$svc_typ, train$acq_mth, train$bil_ter, train$zn_nr, train$svc_f_or, train$wday)

l <- list(train$rec_typ, train$trs_dat, train$inf_src, train$adj_trs_typ)
train_ms <- split(train,l,drop=T)

out_d <- data.frame()
d_idx <- 1

for (i in 1 : length(train_ms)) {
  trn <- train_ms[[i]]
  idf <- unlist(strsplit(names(train_ms)[i], '[.]'))
  wks <- unique(trn$w_nr)
  
  out_d[d_idx,c('rec_typ')] <- idf[1]
  out_d$trs_dat[d_idx] <- idf[2]
  out_d$inf_src[d_idx] <- idf[3]
  out_d$adj_trs_typ[d_idx] <- idf[4]
  
  tst <- test[((test$rec_typ == idf[1]) & (test$trs_dat == idf[2]) & 
                 (test$inf_src == idf[3]) & (test$adj_trs_typ == idf[4])),]
  
  if (idf[1] == 'FRT') {
    micro_lst <- list(trn$svc_f_or, trn$zn_nr)
  } else {
    micro_lst <- list(trn$svc_f_or, trn$svc_typ)
  }
  
  trn_micro_seg <- split(trn, micro_lst, drop=T)
  
  out_d$zero_vol_ms[d_idx] <- 'OK'
  for (m in (1:length(trn_micro_seg))) {
    ids <- unlist(strsplit(names(trn_micro_seg)[m], '[.]'))
    if (idf[1] == 'FRT') {
      if ((nrow(tst[((tst$svc_f_or == ids[1]) & (tst$zn_nr == ids[2])),]) == 0) & 
            (mean(table(trn_micro_seg[[m]]$w_nr)) > 10) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 6)) {
        print(paste(c('Error ZERO_VOL_MS: Zero volume for ', idf, ids, round(mean(table(trn_micro_seg[[m]]$w_nr)),1)), collapse=","))
        out_d$zero_vol_ms[d_idx] <- 'Check Logs'
      } 
    } else {
      if ((nrow(tst[((tst$svc_f_or == ids[1]) & (tst$svc_typ == ids[2])),]) == 0) & 
            (mean(table(trn_micro_seg[[m]]$w_nr)) > 10) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 6)) {
        print(paste(c('Error ZERO_VOL_MS: Zero volume for ', idf, ':', ids, round(mean(table(trn_micro_seg[[m]]$w_nr))),1), collapse=","))
        out_d$zero_vol_ms[d_idx] <- 'Check Logs'
      } 
    }
  }
  
  out_d$aov_ms[d_idx] <- 'OK'
  for (m in (1:length(trn_micro_seg))) {
    ids <- unlist(strsplit(names(trn_micro_seg)[m], '[.]'))
    
    if (idf[1] == 'FRT') {
      tst_ms <- tst[((tst$svc_f_or == ids[1]) & (tst$zn_nr == ids[2])),]
    } else {
      tst_ms <- tst[((tst$svc_f_or == ids[1]) & (tst$svc_typ == ids[2])),]
    }  
    
#    print(c(dim(trn_micro_seg[[m]]), dim(tst_ms)))
    
    if ((length(unique(trn_micro_seg[[m]]$w_nr)) > 1) & (nrow(tst_ms) > 0) & (min(table(trn_micro_seg[[m]]$w_nr)) > 1) &
          (median(tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, sum)) > 10)){
      aov_hist <- summary(aov(pkg_qy ~ w_nr,data=trn_micro_seg[[m]]))[[1]][[5]][1]
      
      comb_data <- do.call(rbind,list(trn_micro_seg[[m]],tst_ms))
      aov_comb <- summary(aov(pkg_qy ~ w_nr,data=comb_data))[[1]][[5]][1]
      
      if ((aov_comb <= 0.05) & (aov_hist > 4 * aov_comb) & (aov_hist > .5)
          & (is.na(aov_comb) == F) & (is.na(aov_hist) == F)) {
        print(paste(c('Error AOV_MS: Checkout what is going on with ',idf, ids, aov_hist, aov_comb), collapse=","))
        out_d$aov_ms[d_idx] <- 'Check Logs'
      }  
    } 
  }
  
  if ((length(wks) > 3) & (median(tapply(trn$pkg_qy, trn$w_nr, sum)) > 5) & (dim(tst)[1] < 0.2*mean(table(trn$w_nr)))) {
    print(paste(c('Error VOL_OUT_OF_WHACK: Current week less than 20% of normal vol for ', idf), collapse=","))
    out_d$vol_out_of_whack[d_idx] <- round((dim(tst)[1] / mean(table(trn$w_nr))),2)
  } else {
    out_d$vol_out_of_whack[d_idx] <- "OK"
  }
  
  if ((length(table(trn$w_nr)) > 2) & (sd(trn$pkg_qy) > 0) & (nrow(tst) > 5)) {
    pool <- (combn(wks, 2, function(x) (mean(trn[(trn$w_nr == x[[1]]),]$pkg_qy) - mean(trn[(trn$w_nr == x[[2]]),]$pkg_qy))))
    mu <- mean(pool)
    se <- sd(pool)
    zv <- median(sapply(wks,function(itm) ((mean(trn[(trn$w_nr == itm),]$pkg_qy) - mean(tst$pkg_qy)) - mu)/se))
    if (zv > 2) {
      out_d$zval[d_idx] <- zv
    } else {
      out_d$zval[d_idx] <- "OK"
    }
  } else {
    out_d$zval[d_idx] <- "LH"
  }

  d_idx <- d_idx + 1
}

out_d$status <- "OK"
out_d$status <- ifelse(((out_d$zero_vol_ms == "OK") & (out_d$vol_out_of_whack == "OK") &
                         (out_d$aov_ms == "OK")), "OK", "Alert")
out_d$status <- ifelse(((out_d$zval != "OK") & (out_d$zval != "LH")), "Alert", out_d$status)

names(out_d) <- c("rec_typ", "trs_dat", "inf_src", "adj_trs_typ", "zero_vol_ms", "aov_ms", "vol_out_of_whack", "zval", "status")


#m1 <- lm(pkg_qy ~ rec_typ + trs_dat + inf_src + dat_src_cd + ctnr_typ + svc_typ + 
#           acq_mth + bil_ter + zn_nr + svc_f_or + wday, data=train)
#m2 <- lm(ln_pkg_qy ~ rec_typ + trs_dat + inf_src + dat_src_cd + ctnr_typ + 
#           acq_mth + bil_ter + zn_nr + svc_f_or + wday, data=train)