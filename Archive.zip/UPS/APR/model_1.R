## And there we go,.. from good to great,.. Learn machine learn
##----------------------------------------------##
## Better start swimmin'
## Or'll sink like a stone
## For the times they are a-changin'
##----------------------------------------------##

parm <- "none"
setwd("~/Documents/Models/UPS/APR")

out_d <- data.frame()

train <- read.csv('train.csv', header=T)
#train$pkg_qy <- as.numeric(train$pkg_qy)
#train$ln_pkg_qy <- as.numeric(train$ln_pkg_qy)
#train$x_pkg_qy <- as.numeric(train$x_pkg_qy)

train$svc_typ <- as.factor(train$svc_typ)
train$zn_nr <- as.factor(train$zn_nr)

test <- read.csv('test.csv',header=T)
test$svc_typ <- as.factor(test$svc_typ)
test$zn_nr <- as.factor(test$zn_nr)

##l <- list(train$rec_typ, train$trs_dat, train$inf_src, train$dat_src_cd, train$ctnr_typ,
##          train$svc_typ, train$acq_mth, train$bil_ter, train$zn_nr, train$svc_f_or, train$wday)

l <- list(train$rec_typ, train$trs_dat, train$inf_src)
#idx <- split(seq(train),l)
train_ms <- split(train,l,drop=T)

for (i in 1 : length(train_ms)) {
  trn <- train_ms[[i]]
  idf <- unlist(strsplit(names(train_ms)[i], '[.]'))
  
  out_d$rec_typ <- idf[1]
  out_d$trs_dat <- idf[2]
  out_d$inf_src <- idf[3]
  
  tst <- test[((test$rec_typ == idf[1]) & (test$trs_dat == idf[2]) & (test$inf_src == idf[3])),]
  lt <- nrow(tst)
  
  if (dim(tst)[1] < 0.2*mean(table(trn$w_nr))) {
    print(c('Checkout, current week less than 20% of normal vol for ', idf))
    out_d$vol_out_of_whack <- (dim(tst)[1] / mean(table(trn$w_nr)))
  }
  
  wks <- unique(trn$w_nr)
  N <- 10^3
  diff.mean <- numeric(N)
  diff.t <- numeric(N)
  diff.p <- numeric(N)
  pval <- numeric(length(wks))
  
  k <- 1
  
  pool <- (combn(wks, 2, function(x) (mean(trn[(trn$w_nr == x[[1]]),]$pkg_qy) - mean(trn[(trn$w_nr == x[[2]]),]$pkg_qy))))
  mu <- mean(pool)
  se <- sd(pool)
  
  for (itm in wks) {
    hist <- trn[(trn$w_nr == itm),]
    lh <- nrow(hist)
    
    for (j in (1:N)) {
      hist.sample <- sample(hist$pkg_qy, lh, replace=T)
      tst.sample <- sample(tst$pkg_qy, lt, replace=T)
      
      mu_hat <- mean(hist.sample) - mean(tst.sample)
      diff.mean[j] <- mu_hat
      std <- sqrt(var(hist.sample)/lh + var(tst.sample)/lt)
      tval <- (mu_hat - mu)/se
      diff.t[j] <- tval
##      diff.p[j] <- dt(tval,df=lt+lh-2)
    }
    print(c(mean(diff.t), ":::", mean(diff.mean)))
  }
  
  if (mean(table(trn$w_nr)) > 50) {
    aov_hist <- summary(aov(pkg_qy ~ w_nr,data=trn))[[1]][[5]][1]
    
    comb_data <- do.call(rbind,list(trn,tst))
    aov_comb <- summary(aov(pkg_qy ~ w_nr,data=comb_data))[[1]][[5]][1]
    
    if (((aov_comb < 0.15) & (aov_hist > 4 * aov_comb) & (aov_hist > .25)) | 
          ((aov_comb < .2) & (aov_hist - aov_comb) > 0.5)) {
      print(c('Hmmm,.. Checkout whats going on with ',idf, aov_hist, aov_comb), quote=F)
    } 
  }
}
#m1 <- lm(pkg_qy ~ rec_typ + trs_dat + inf_src + dat_src_cd + ctnr_typ + svc_typ + 
#           acq_mth + bil_ter + zn_nr + svc_f_or + wday, data=train)
#m2 <- lm(ln_pkg_qy ~ rec_typ + trs_dat + inf_src + dat_src_cd + ctnr_typ + 
#           acq_mth + bil_ter + zn_nr + svc_f_or + wday, data=train)