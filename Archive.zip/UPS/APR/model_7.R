## And there we go,.. from good to great,.. Learn machine learn
##----------------------------------------------##
## Better start swimmin'
## Or'll sink like a stone
## For the times they are a-changin'
##----------------------------------------------##

parm <- "none"
setwd("~/Documents/Models/UPS/APR")

train <- read.csv('train.csv', header=T, colClasses='character')
train$pkg_qy <- as.numeric(train$pkg_qy)
train$ln_pkg_qy <- as.numeric(train$ln_pkg_qy)
train$x_pkg_qy <- as.numeric(train$x_pkg_qy)

train$svc_typ <- as.factor(train$svc_typ)
train$zn_nr <- as.factor(train$zn_nr)
train$adj_trs_typ <- as.factor(train$adj_trs_typ)

test <- read.csv('test.csv',header=T, colClasses='character')
test$pkg_qy <- as.numeric(test$pkg_qy)
test$ln_pkg_qy <- as.numeric(test$ln_pkg_qy)
test$x_pkg_qy <- as.numeric(test$x_pkg_qy)

test$svc_typ <- as.factor(test$svc_typ)
test$zn_nr <- as.factor(test$zn_nr)
test$adj_trs_typ <- as.factor(test$adj_trs_typ)

##l <- list(train$rec_typ, train$trs_dat, train$inf_src, train$dat_src_cd, train$ctnr_typ,
##          train$svc_typ, train$acq_mth, train$bil_ter, train$zn_nr, train$svc_f_or, train$wday)

l <- list(train$txn_typ, train$rec_typ, train$trs_dat, train$inf_src, train$adj_trs_typ)
train_ms <- split(train,l,drop=T)

out_d <- data.frame()
d_idx <- 1

for (i in 1 : length(train_ms)) {
  trn <- train_ms[[i]]
  idf <- unlist(strsplit(names(train_ms)[i], '[.]'))
  wks <- unique(trn$w_nr)
  
  out_d[d_idx,c('txn_typ')] <- idf[1]
  out_d$rec_typ[d_idx] <- idf[2]
  out_d$trs_dat[d_idx] <- idf[3]
  out_d$inf_src[d_idx] <- idf[4]
  out_d$adj_trs_typ[d_idx] <- idf[5]
  
  tst <- test[((test$txn_typ == idf[1]) & (test$rec_typ == idf[2]) & (test$trs_dat == idf[3]) & 
                 (test$inf_src == idf[4]) & (test$adj_trs_typ == idf[5])),]
  
  out_d$vol_out_of_whack[d_idx] <- "OK"
  out_d$zero_vol_ms[d_idx] <- 'OK'
  out_d$ireg_vol_ms[d_idx] <- 'OK'
  
  if ((length(wks) > 3) & (median(tapply(trn$pkg_qy, trn$w_nr, sum)) > 100) & 
        ((sum(tst$pkg_qy) < 0.2*median(tapply(trn$pkg_qy, trn$w_nr, sum))))) {
    print(paste(c('Error VOL_OUT_OF_WHACK: Current week less than 20% of normal vol for', 
                  idf, median(tapply(trn$pkg_qy, trn$w_nr, sum))), collapse=" "))
    #    out_d$vol_out_of_whack[d_idx] <- round((dim(tst)[1] / mean(table(trn$w_nr))),2)
    out_d$vol_out_of_whack[d_idx] <- median(tapply(trn$pkg_qy, trn$w_nr, sum))
    out_d$zero_vol_ms[d_idx] <- 'Bypassed'
    out_d$ireg_vol_ms[d_idx] <- 'Bypassed'
    
  } else {
    if (idf[2] == 'FRT') {
      micro_lst <- list(trn$svc_f_or, trn$zn_nr)
    } else {
      micro_lst <- list(trn$svc_f_or, trn$svc_typ)
    }
    
    trn_micro_seg <- split(trn, micro_lst, drop=T)
    
    for (m in (1:length(trn_micro_seg))) {
      ids <- unlist(strsplit(names(trn_micro_seg)[m], '[.]'))
      
      if (idf[2] == 'FRT') {
        if ((nrow(tst[((tst$svc_f_or == ids[1]) & (tst$zn_nr == ids[2])),]) == 0) & 
              (mean(table(trn_micro_seg[[m]]$w_nr)) > 4) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 4)
            & mean(tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, mean)) > 25) {
          print(paste(c('Error ZERO_VOL_MS: Zero volume for ', idf, ids, round(mean(table(trn_micro_seg[[m]]$w_nr)),1)), collapse=","))
          print(paste(c('Weekly Counts:',tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, sum)),collapse=","))
          print(paste(c('Weekly Rows:',table(trn_micro_seg[[m]]$w_nr)),collapse=","))
          out_d$zero_vol_ms[d_idx] <- 'Check Logs'
          
        } 
      } else {
        if ((nrow(tst[((tst$svc_f_or == ids[1]) & (tst$svc_typ == ids[2])),]) == 0) & 
              (mean(table(trn_micro_seg[[m]]$w_nr)) > 10) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 6)) {
          print(paste(c('Error ZERO_VOL_MS: Zero volume for ', idf, ids, round(mean(table(trn_micro_seg[[m]]$w_nr)),1)), collapse=","))
          print(paste(c('Weekly Counts:',tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, sum)),collapse=","))
          print(paste(c('Weekly Rows:',table(trn_micro_seg[[m]]$w_nr)),collapse=","))
          out_d$zero_vol_ms[d_idx] <- 'Check Logs'
          
        } 
      }
      
      if (idf[2] == 'FRT') {
        tst_ms <- tst[((tst$svc_f_or == ids[1]) & (tst$zn_nr == ids[2])),]
       
        thsld <- (tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, sum))
        
        if (((sum(tst_ms$pkg_qy) < 0.2*min(thsld)) | (sum(tst_ms$pkg_qy) > 2*max(thsld))) & (min(thsld) > 100) & 
              (median(thsld) > 200) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 6)) {
          print(paste(c('Error IREG_VOL_MS: Irregular volume for ', idf, ids, median(thsld)), collapse=","))
          print(paste(c(thsld,'//',sum(tst_ms$pkg_qy)), collapse=","))
          
          out_d$ireg_vol_ms[d_idx] <- round(sum(tst_ms$pkg_qy)/median(thsld),4)
        } 
      } else {
        tst_ms <- tst[((tst$svc_f_or == ids[1]) & (tst$svc_typ == ids[2])),]
        
        thsld <- (tapply(trn_micro_seg[[m]]$pkg_qy, trn_micro_seg[[m]]$w_nr, sum))
        
        if (((sum(tst_ms$pkg_qy) < 0.2*min(thsld)) | (sum(tst_ms$pkg_qy) > 2*max(thsld))) & (min(thsld) > 100) & 
              (median(thsld) > 200) & (length(unique(trn_micro_seg[[m]]$w_nr)) > 6)) {
          print(paste(c('Error IREG_VOL_MS: Irregular volume for ', idf, ids, median(thsld)), collapse=","))
          print(paste(c(thsld,'//',sum(tst_ms$pkg_qy)), collapse=","))
          out_d$ireg_vol_ms[d_idx] <- round(sum(tst_ms$pkg_qy)/median(thsld),4)
        } 
      }
    }
  }
  
  if ((length(table(trn$w_nr)) > 2) & (sd(trn$pkg_qy) > 0) & (nrow(tst) > 5)) {
    pool <- (combn(wks, 2, function(x) abs(sum(trn[(trn$w_nr == x[[1]]),]$pkg_qy) - sum(trn[(trn$w_nr == x[[2]]),]$pkg_qy))))
    wkly_mean <- mean(tapply(trn$pkg_qy, trn$w_nr, sum))
    mu <- mean(pool)
    se <- sd(pool)
    zv <- (median(sapply(wks,function(itm) (abs(sum(trn[(trn$w_nr == itm),]$pkg_qy) - sum(tst$pkg_qy))))) - mu)/se
    if (((zv > 6) & !(is.na(zv))) & (wkly_mean > 1000) &(mu < 1000)) {
      print(paste(c('ZVAL Error: ', 'pool:', pool, 'mu:', mu, 'se:', se, 'zv:', zv, 'i:', i, 'idf:', idf), collapse=","))
      out_d$zval[d_idx] <- round(zv,2)
    } else {
      out_d$zval[d_idx] <- "OK"
    }
  } else {
    out_d$zval[d_idx] <- "LH"
  }

  d_idx <- d_idx + 1
}

out_d$status <- "OK"

out_d$status <- ifelse(((out_d$zero_vol_ms == "OK") &
                          (out_d$vol_out_of_whack == "OK") & (out_d$ireg_vol_ms == "OK")), "OK", "Alert")
out_d$status <- ifelse(((out_d$zval != "OK") & (out_d$zval != "LH")), "Alert", out_d$status)

names(out_d) <- c("txn_typ", "rec_typ", "trs_dat", "inf_src", "adj_trs_typ", "vol_out_of_whack", "zero_vol_ms", "ireg_vol_ms",
                  "zval", "status")

write.table(out_d,"volprof.csv",sep=",",col.names=T,row.names=F)
