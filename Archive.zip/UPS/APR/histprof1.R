## This program will take multiple weeks of historical billing test. And prep them. And then we will figure out things

parm <- "none"
setwd("~/Documents/Models/UPS/APR")

inf <- list.files(pattern='*.txt')
inf<-inf[grep("satyan6",inf)]
lst <- vector("list", length(inf))

i <- 1

for (item in inf) {
  d <- read.csv(item, sep=';', header=F, colClasses="character")
#  d <- read.csv('w1.txt', sep=';', header=F, colClasses="character")
  names(d) <- c("REC_TYP", "CNY_CD", "REC_MTH", "TRS_DAT", "RR", "DD", "ORG_PSL", "DTN_PSL", "CTR_NR",
               "AC_NR", "WND_DT", "RT_DT", "NCV_DT", "TCK_NR", "INF_SRC", "CUS_CLS_CD", "RCH_TYP_CD", 
               "RA_SHO_IR", "FRS_STS_CD", "DAT_SRC_CD","SBB_IR","MIN_CHG", "SVC_FEA","CTNR_TYP", "SVC_TYP",
               "ACQ_MTH", "BIL_TER", "INI_SVC", "ZN_NR", "PKG_QY", "SVC_F_OR", "CTNR_TYP_OR", "SVC_TYP_OR",
               "ACQ_MTH_OR", "ZN_NR_OR", "PKG_WT", "CCY_CD", "RET_SHP_CD", "AJ_TRS_TYP", "ADJ_TRS_RSN", "TRS_DAT_ORG",
               "MVM_DRC", "PMT_MDA", "CHG_CRD", "CRD_CAT", "TAX_CSF_CD", "ASY_TYP", "ASY_UNT", "CHG_TYP_CD", 
               "GRS_RVN","NET_FST","NET_FNA")
  
  if (parm == "dcheck") {
    colSums(apply(d1,2,is.na))
  }
  
  nam <- names(d)
  rmcols <- c(which(nam == "CNY_CD"), which(nam == "REC_MTH"), which(nam == "RR"), which(nam == "DD"), 
              which(nam == "ORG_PSL"), which(nam == "DTN_PSL"), which(nam == "CTR_NR"), which(nam == "AC_NR"), 
              which(nam == "NCV_DT"), which(nam == "TCK_NR"), which(nam == "RA_SHO_IR"), 
              which(nam == "FRS_STS_CD"), which(nam == "SBB_IR"), which(nam == "MIN_CHG"), which(nam == "INI_SVC"), 
              which(nam == "CTNR_TYP_OR"), which(nam == "SVC_TYP_OR"), which(nam == "ACQ_MTH_OR"), which(nam == "ZN_NR_OR"), 
              which(nam == "CCY_CD"), which(nam == "RET_SHP_CD"), which(nam == "ADJ_TRS_RSN"), 
              which(nam == "TRS_DAT_ORG"), which(nam == "MVM_DRC"), which(nam == "PMT_MDA"), which(nam == "CHG_CRD"), 
              which(nam == "CRD_CAT"), which(nam == "TAX_CSF_CD"), which(nam == "GRS_RVN"), which(nam == "NET_FST"),
              which(nam == "NET_FNA"),
              which(nam == "CUS_CLS_CD"), which(nam == "CHG_TYP_CD")
  )
  
  d <- d[,-rmcols]
#  d[which(is.na(d$ZN_NR)),]$ZN_NR <- ' '
  
  d <- d[(d$WND_DT == max(d$WND_DT)),]
  d$wday <- as.POSIXlt(d$RT_DT)$wday
  d$wnr <- (as.POSIXlt(d$WND_DT)$yday %/% 7) + 1

  d <- within(d, {
    REC_TYP <- ifelse((REC_TYP == 'ACC'), as.character(ASY_TYP), as.character(REC_TYP))
    SVC_F_OR<-ifelse((RCH_TYP_CD=='02' | SVC_F_OR == ""), as.character(SVC_FEA), as.character(SVC_F_OR))
  })
  
  if (sum(grep("[A-Z{}]", d$ASY_UNT)) != 0) {
    d <- d[-intersect(grep("[A-Z{}]", d$ASY_UNT),  which(d$REC_TYP != 'FRT')),]
  }
  
  d$PKG_QY <- ifelse((d$REC_TYP != "FRT"), d$ASY_UNT, d$PKG_QY)
  
  d <- d[,-c(which(names(d) == 'ASY_TYP'), which(names(d) == 'RCH_TYP_CD'), which(names(d) == 'WND_DT'), 
             which(names(d) == 'SVC_FEA'), which(names(d) == 'ASY_UNT'),
             which(names(d) == 'RT_DT'), which(names(d) == 'PKG_WT'))]
  
  lst[[i]] <- d
  i <- i + 1
  
}


test <- do.call("rbind",lst[(i-1)])
rm(lst)


test$PKG_QY <- as.numeric(test$PKG_QY)
test$REC_TYP <- as.factor(test$REC_TYP)
test$TRS_DAT <- as.factor(test$TRS_DAT)
test$INF_SRC <- as.factor(test$INF_SRC)
test$DAT_SRC_CD <- as.factor(test$DAT_SRC_CD)
test$CTNR_TYP <- as.factor(test$CTNR_TYP)
test$SVC_TYP <- as.factor(test$SVC_TYP)
test$ACQ_MTH <- as.factor(test$ACQ_MTH)
test$BIL_TER <- as.factor(test$BIL_TER)
test$ZN_NR <- as.factor(test$ZN_NR)
test$SVC_F_OR <- as.factor(test$SVC_F_OR)
test$AJ_TRS_TYP <- as.factor(test$AJ_TRS_TYP)
test$x_pkg_qy <- ifelse((test$PKG_QY != 0), (1/test$PKG_QY), 0)
test$ln_pkg_qy <- ifelse((test$PKG_QY > 0), log(test$PKG_QY), ifelse((test$PKG_QY < 0), (1/test$PKG_QY), 0))


names(test) <- c("rec_typ", "trs_dat", "inf_src", "dat_src_cd", "ctnr_typ", "svc_typ", "acq_mth",
                 "bil_ter", "zn_nr", "pkg_qy", "svc_f_or", "adj_trs_typ",  "wday", "w_nr", "x_pkg_qy", "ln_pkg_qy")

#spl <- rbinom(nrow(test),size=1,prob=0.7)
#train <- test[spl == 1,][,]
#test <- test[spl == 0,][,]


write.table(test,"test.csv",sep=",",col.names=T,row.names=F)

## And we have data now ##