pair_trade<-function(file1,file2) {
  setwd("/Users/dipanjanpaul/Documents/Models/Gilad/C S W 1 min 2010-to-day")
  r_df<-data.frame()
  r_df_temp<-data.frame()
  r_df_f<-data.frame()
  
  data1<-read.csv(file1,strip.white=TRUE,header=F)
  data2<-read.csv(file2,strip.white=TRUE,header=F)
  
  names(data1)<-c("X","High","Low","Open","Close","Volume")
  names(data2)<-c("X","High","Low","Open","Close","Volume")

  data<-merge(data1,data2,by.x='X',by.y='X')
  rm(data1,data2)
  
##  data$X<-as.Date(data1$X)
  
##  cor<-array()
##  cor[1]<-cor(data$High.x,data$High.y)
##  cor[2]<-cor(data$Low.x,data$Low.y)l
##  cor[3]<-cor(data$Open.x,data$Open.y)
  
  cor_cl<-cor(data$Close.x,data$Close.y)
  cor_vol<-cor(data$Volume.x,data$Volume.y)

  if ((mean(c(cor_cl,cor_vol))) > 0.75) {
    data$Close_Dif<-data$Close.x-data$Close.y
    Close_otlr<-which(abs(data$Close_Dif - mean(data$Close_Dif)) > 1.5*sd(data$Close_Dif))
    Close_otlr_seq<-rle(unlist(sapply((1:length(Close_otlr)), function(a) ((Close_otlr[a] - Close_otlr[a-1]))))==1)
    Close_otlr_beg<-c(0, cumsum(Close_otlr_seq$lengths))[which(Close_otlr_seq$values)] + 1 
    Close_otlr_end<-cumsum(Close_otlr_seq$lengths)[which(Close_otlr_seq$values)]
    
    r_df<-data[Close_otlr[Close_otlr_beg],][,]
    r_df[,13:24]<-data[Close_otlr[Close_otlr_end],][,]
    r_df$X.time_diff <- difftime(as.POSIXct(r_df$X.1),as.POSIXct(r_df$X),units="min")
    r_df_temp<-r_df[(which(r_df$X.time_diff > 0.9*max(r_df$X.time_diff))),]
    
    if (row.names(r_df_temp)[(dim(r_df_temp)[1])] == row.names(data)[(dim(data)[1])]) {
      r_df_f = r_df_temp[(dim(r_df_temp)[1]),]
    }
        
##    write.table(r_df_f,"C1S1_Rep.csv",sep=",",col.names=T,row.names=F)
  }

  return(r_df_f)
}