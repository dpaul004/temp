amznprof<-function(file1) {
  setwd("~/UPS General/Analytics/Amazon")
  
  r_df<-data.frame()
#  r_df2<-data.frame()
  
#  r_l1<-list()
#  r_l2<-list()
  
  sh1<-read.csv("shprprof.txt",sep=";",colClasses="character",strip.white=TRUE)
  names(sh1)<-c("AC_NR","WND_DT","INF_SRC","PKG_QY","FIL","SVC_FEA","CTNR_TYP",
                "SVC_TYP","ACQ_MTH","BIL_TER","ZN_NR","SVC_F_OR","PKG_WT","GRS_RVN",
                "NET_FST","NET_FNA")
  
  sh1[,12]<-ifelse(sh1[,12]=="",sh1[,6],sh1[,12])
  sh1$GRS_RVN<-as.numeric(sh1$GRS_RVN)
  sh1$NET_FST<-as.numeric(sh1$NET_FST)
  sh1$NET_FNA<-as.numeric(sh1$NET_FNA)
  sh1$PKG_QY<-as.numeric(sh1$PKG_QY)
  sh1$PKG_WT<-as.numeric(sh1$PKG_WT)

  l<-list(sh1$AC_NR,sh1$INF_SRC,sh1$SVC_F_OR,sh1$CTNR_TYP,sh1$SVC_TYP,sh1$ACQ_MTH,sh1$BIL_TER,sh1$ZN_NR)

  pitem<-c("AC_NR","INF_SRC","SVC_F_OR","CTNR_TYP","SVC_TYP","ACQ_MTH",
          "BIL_TER","ZN_NR")

  p_len<-length(pitem)
  
  pdata<-split(sh1,l,drop=T)
  
  for (i in 1:length(pdata)) {
  #for (i in 1:28) {

    if (nrow(r_df) == 0) {
      r_df<-(pdata[[i]][1,pitem][1:8])
    } else {
      r_df[i,pitem]<-(pdata[[i]][1,pitem][1:8])
    }

# The following will give the quantile, mean and SD for each profile for the entire duration wrt the First and Final Net amounts   
    
    qtle<-quantile((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FST)/pdata[[i]]$GRS_RVN)
    
    r_df[i,p_len + 1]<-qtle[1]
    r_df[i,p_len + 2]<-qtle[2]
    r_df[i,p_len + 3]<-qtle[3]
    r_df[i,p_len + 4]<-qtle[4]
    r_df[i,p_len + 5]<-qtle[5]
    
    r_df[i,p_len + 6]<-mean((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FST)/pdata[[i]]$GRS_RVN)
    r_df[i,p_len + 7]<-sd((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FST)/pdata[[i]]$GRS_RVN)
    
    r_df[i,p_len + 8]<-mean((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FNA)/pdata[[i]]$GRS_RVN)
    r_df[i,p_len + 9]<-sd((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FNA)/pdata[[i]]$GRS_RVN)

# The following will give the mean and SD for each profile for the weekly means   

    fac<-pdata[[i]]$WND_DT
    
    r_df[i,p_len + 10]<-mean(tapply(((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FST)/pdata[[i]]$GRS_RVN),fac,mean))
    r_df[i,p_len + 11]<-sd(tapply(((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FST)/pdata[[i]]$GRS_RVN),fac,mean))
    
    r_df[i,p_len + 12]<-mean(tapply(((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FNA)/pdata[[i]]$GRS_RVN),fac,mean))
    r_df[i,p_len + 13]<-sd(tapply(((pdata[[i]]$GRS_RVN - pdata[[i]]$NET_FNA)/pdata[[i]]$GRS_RVN),fac,mean))

    r_df[i,p_len + 14]<-mean(tapply(pdata[[i]]$GRS_RVN,fac,sum))
    r_df[i,p_len + 15]<-sd(tapply(pdata[[i]]$GRS_RVN,fac,sum))
    
    r_df[i,p_len + 16]<-mean(tapply(pdata[[i]]$NET_FST,fac,sum))
    r_df[i,p_len + 17]<-sd(tapply(pdata[[i]]$NET_FST,fac,sum))
    
    r_df[i,p_len + 18]<-mean(tapply(pdata[[i]]$NET_FNA,fac,sum))
    r_df[i,p_len + 19]<-sd(tapply(pdata[[i]]$NET_FNA,fac,sum))
                           
    r_df[i,p_len + 20]<-mean(tapply(pdata[[i]]$PKG_QY,fac,sum))
    r_df[i,p_len + 21]<-sd(tapply(pdata[[i]]$PKG_QY,fac,sum))
                           
    pwkly<-split(pdata[[i]],pdata[[i]]$WND_DT)

    r_dfw<-array(list(), dim=c(8,length(pwkly)))
    
    for (j in 1:length(pwkly)) {
      f_wt<-factor(pwkly[[j]]$PKG_WT)
      
      r_dfw[[1,j]]<-tapply(pwkly[[j]]$PKG_QY,f_wt,sum)
      r_dfw[[2,j]]<-tapply(pwkly[[j]]$GRS_RVN,f_wt,sum)
      r_dfw[[3,j]]<-tapply(pwkly[[j]]$NET_FST,f_wt,sum)
      r_dfw[[4,j]]<-tapply(pwkly[[j]]$NET_FNA,f_wt,sum)
      
      r_dfw[[5,j]]<-tapply(((pwkly[[j]]$GRS_RVN - pwkly[[j]]$NET_FST)/pwkly[[j]]$GRS_RVN),f_wt,mean)
      r_dfw[[6,j]]<-tapply(((pwkly[[j]]$GRS_RVN - pwkly[[j]]$NET_FST)/pwkly[[j]]$GRS_RVN),f_wt,sd)
                           
      r_dfw[[7,j]]<-tapply(((pwkly[[j]]$GRS_RVN - pwkly[[j]]$NET_FNA)/pwkly[[j]]$GRS_RVN),f_wt,mean)
      r_dfw[[8,j]]<-tapply(((pwkly[[j]]$GRS_RVN - pwkly[[j]]$NET_FNA)/pwkly[[j]]$GRS_RVN),f_wt,sd)
    
    }
    
    if (length(pwkly) > 1) {
        r_df[i,p_len + 22]<-mean(as.numeric(combn((r_dfw[1,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 23]<-mean(as.numeric(combn((r_dfw[2,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 24]<-mean(as.numeric(combn((r_dfw[3,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 25]<-mean(as.numeric(combn((r_dfw[4,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 26]<-mean(as.numeric(combn((r_dfw[5,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 27]<-mean(as.numeric(combn((r_dfw[6,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 28]<-mean(as.numeric(combn((r_dfw[7,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
        r_df[i,p_len + 29]<-mean(as.numeric(combn((r_dfw[8,]),2,function(x) ifelse(((sum(is.na(x[[1]])) > 0) | (sum(is.na(x[[2]]) > 0))), 0, ks.test(x[[1]],x[[2]])[1]))))
    } else {
      r_df[i,p_len + 22]<-c('NA')
      r_df[i,p_len + 23]<-c('NA')
      r_df[i,p_len + 24]<-c('NA')
      r_df[i,p_len + 25]<-c('NA')
      r_df[i,p_len + 26]<-c('NA')
      r_df[i,p_len + 27]<-c('NA')
      r_df[i,p_len + 28]<-c('NA')
      r_df[i,p_len + 29]<-c('NA')
    }

    r_df[i,p_len + 30]<-length(pwkly)
    r_df[i,p_len + 31]<-i


  }
  

  
  names(r_df)<-c("AC_NR","INF_SRC","SVC_F_OR","CTNR_TYP","SVC_TYP","ACQ_MTH","BIL_TER","ZN_NR",
                 "F_Q0","F_Q25","F_Q50","F_Q75","F_Q100","F_M_INC_FST","F_SD_INC_FST","F_M_INC_FNA",
                 "F_SD_INC_FNA","W_M_INC_FST","W_SD_INC_FST","W_M_INC_FNA","W_SD_INC_FNA","W_M_GRS",
                 "W_SD_GRS","W_M_FST","W_SD_FST","W_M_FNA","W_SD_FNA","W_M_VOL","W_SD_VOL",
                 "KS_M_W_V_WT","KS_M_W_GRS_WT","KS_M_W_FST_WT","KS_M_W_FNA_WT","KS_M_W_I1_WT",
                 "KS_SD_W_I1_WT","KS_M_W_I2_WT","KS_SD_W_I2_WT","WK_CNT","SPL_NR")           
  
#  r_list<-list(r_df)
  return(r_df)
}
